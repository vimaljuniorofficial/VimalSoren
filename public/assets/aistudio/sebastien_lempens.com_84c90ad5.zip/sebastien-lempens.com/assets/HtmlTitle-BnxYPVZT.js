import {
    ab as c,
    aK as r,
    aI as v,
    aM as f,
    a as h,
    am as E,
    aN as b
} from "./index-DjXkBzPf.js";
import {
    B as j
} from "./Billboard-BFaQTabQ.js";
import {
    H as g
} from "./Html-DewR4ynt.js";
import "./Scene-CdCGEhkU.js";
const y = ({
        arrayOfString: i,
        className: l = null,
        transitionDelay: o = 0
    }) => {
        const [n, p] = c.useState(null);
        let u = 1;
        const m = i.map((s, e) => s.split("").map((t, a) => (u++, r.jsxs(v.Fragment, {
            children: [r.jsx("span", {
                className: `letter-${e}-${a}`,
                style: {
                    transitionDelay: `${u*o}ms`
                },
                children: t
            }), a >= s.length - 1 && r.jsx("pre", {
                children: " "
            })]
        }, "word-" + e + "-word-" + a))));
        return c.useEffect(() => {
            n ? document.dispatchEvent(new CustomEvent("eventSpans", {
                detail: n
            })) : p([...m.flat()])
        }, [n]), l ? r.jsx("div", {
            className: l,
            children: n
        }) : n
    },
    R = () => {
        const {
            mobile: i
        } = f.getState(), l = c.useRef(null), [o, n] = c.useState(null), p = i ? new h(15, 28, 25) : new h(22, 20, 5), u = i ? 11 : 10;
        let m = 0;
        return c.useEffect(() => {
            document.addEventListener("eventSpans", s => {
                if (m) {
                    const e = l.current ? .querySelectorAll("span") || [];
                    [...e].forEach((t, a) => {
                        t.dataset.random = .2 + Math.random()
                    }), setTimeout(() => {
                        n(e)
                    }, 1e3)
                }
                m++
            })
        }, []), c.useEffect(() => f.subscribe(s => s.country, s => {
            const e = document.querySelector(".main-title");
            ["fr", "befr2"].includes(s) ? (e.classList.add("active"), e.querySelectorAll("span").forEach((a, d) => {
                a.removeAttribute("style")
            })) : (e.classList.remove("active"), o && o.forEach(t => {
                t.style.opacity = 1, t.style.transform = "perspective(200px) rotateX(0rad)"
            }))
        }), []), E((s, e) => {
            if (!l.current || !o) return;
            const {
                scroll: t
            } = b.getState(), {
                country: a
            } = f.getState();
            if (a !== "fr" || t > .3) return;
            let d = t / .25;
            o.forEach((S, x) => {
                S.style.opacity = `${1-d}`, S.style.transform = `perspective(200px) rotateX(${Math.PI/2*x*d*.5}rad)`
            })
        }), r.jsx(j, {
            follow: !0,
            children: r.jsxs(g, {
                ref: l,
                position: p,
                wrapperClass: "__html main-title",
                distanceFactor: u,
                transform: !0,
                center: !0,
                children: [r.jsx("h1", {
                    children: r.jsx(y, {
                        arrayOfString: ["Sébastien", "Lempens"]
                    })
                }), r.jsx("h2", {
                    children: r.jsx(y, {
                        arrayOfString: ["creative", "web", "engineer"]
                    })
                })]
            })
        })
    };
export {
    y as BuildSpans, R as
    default
};