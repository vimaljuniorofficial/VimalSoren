const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/Buildings-DkZBUUm6.js", "assets/index-DjXkBzPf.js", "assets/index-CaPdr700.css", "assets/Scene-CdCGEhkU.js", "assets/Portal-D-4n91i4.js", "assets/Cloud-qp0Oh7DW.js", "assets/deprecated-yOBBLatR.js", "assets/Skills-DFKl31g5.js", "assets/HtmlTitle-BnxYPVZT.js", "assets/Billboard-BFaQTabQ.js", "assets/Html-DewR4ynt.js", "assets/Clone-DlEjDv1t.js", "assets/SkeletonUtils-bL-kYfaA.js", "assets/Portfolio-CRbW23xQ.js"]))) => i.map(i => d[i]);
import {
    aM as t,
    ab as r,
    aK as a,
    aT as c,
    ac as L,
    aN as g,
    am as S
} from "./index-DjXkBzPf.js";
import {
    a as b,
    l as C,
    s as P,
    b as d,
    c as h,
    d as j
} from "./Scene-CdCGEhkU.js";
import {
    u as v
} from "./useAnimation-CGFVWVoT.js";
const F = r.lazy(() => c(() =>
        import ("./Buildings-DkZBUUm6.js"), __vite__mapDeps([0, 1, 2, 3]))),
    T = r.lazy(() => c(() =>
        import ("./Portal-D-4n91i4.js"), __vite__mapDeps([4, 1, 2, 3, 5, 6]))),
    A = r.lazy(() => c(() =>
        import ("./Skills-DFKl31g5.js"), __vite__mapDeps([7, 1, 2, 3, 8, 9, 10, 11, 12]))),
    I = r.lazy(() => c(() =>
        import ("./Portfolio-CRbW23xQ.js"), __vite__mapDeps([13, 1, 2, 3, 10]))),
    x = .924,
    R = () => {
        const i = L(e => e.scene),
            {
                currentCamera: l,
                fr_cameras_animations: m
            } = t.getState(),
            u = l,
            [y] = m ? .filter(({
                name: e
            }) => e === "cameraFranceLuxembourg"),
            [o, _] = v("cameraFranceLuxembourg", u, y);
        r.useEffect(() => t.subscribe(e => e.country, e => {
            if (e === "frlux" && (o.reset().play().paused = !0, P(i, ["countryFrance", "countryLuxembourg"], ["countryBelgium"])), e === "lux") {
                const s = u.position.clone(),
                    n = u.rotation.clone();
                o.stop(), u.position.set(...s.toArray()), u.rotation.set(n.x, n.y, n.z)
            }
        }, {
            fireImmediately: !0
        }), []), r.useEffect(() => t.subscribe(e => e.teleportation, e => {
            const {
                country: s
            } = t.getState();
            e && s === "frlux" && (d(!1), h(i, "sunrise"), o.reset().play().paused = !0, o.time = o.getClip().duration, _.update(0))
        }), []), r.useEffect(() => g.subscribe(e => e.scroll, e => {
            const {
                country: s
            } = t.getState();
            s === "frlux" && (e < x && (o.time = o.getClip().duration * e), e > .01 && e < .1 && d())
        }), []);
        let f = !1;
        return S((e, s) => {
            const {
                scroll: n
            } = g.getState(), {
                country: E,
                fog: p
            } = t.getState();
            E === "frlux" ? f ? (n > .1 && p && j(p.color, "hsl(222,12%,51%)", .999, s), n < x && (o.time = o.getClip().duration * n, _ && _.update(s))) : f = !0 : f = !1
        }), !1
    },
    V = () => {
        const i = t(m => m.lu_component_preload),
            {
                animations: l
            } = b(t.getState().lu_glb_path);
        return r.useEffect(() => {
            console.log("%c Luxembourg Component Loaded", C.log), t.setState({
                lu_cameras_animations: l,
                lu_component_loaded: !0
            })
        }, []), a.jsx(r.Suspense, {
            fallback: null,
            children: i && a.jsx(a.Fragment, {
                children: a.jsxs("group", {
                    name: "countryLuxembourg",
                    visible: !1,
                    children: [a.jsx(F, {}), a.jsx(T, {}), a.jsx(I, {}), a.jsx(A, {}), a.jsx(R, {})]
                })
            })
        })
    };
b.preload(t.getState().lu_glb_path);
export {
    V as
    default
};