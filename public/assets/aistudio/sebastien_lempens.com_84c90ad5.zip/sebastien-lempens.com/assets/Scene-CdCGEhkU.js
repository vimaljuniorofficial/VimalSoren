const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/CountryFrance-CABRcqX6.js", "assets/index-DjXkBzPf.js", "assets/index-CaPdr700.css", "assets/useMouse-CXoH0j_u.js", "assets/HtmlTitle-BnxYPVZT.js", "assets/Billboard-BFaQTabQ.js", "assets/Html-DewR4ynt.js", "assets/useAnimation-CGFVWVoT.js", "assets/deprecated-yOBBLatR.js", "assets/shapes-B93sfIzn.js", "assets/CountryLuxembourg-B78eat4a.js", "assets/CountryBelgium-BSndXaUR.js", "assets/Cloud-qp0Oh7DW.js", "assets/Model-CftzVF03.js"]))) => i.map(i => d[i]);
import {
    V as Z,
    C as ve,
    E as Pn,
    a as Pe,
    R as fi,
    T as Hr,
    b as oi,
    c as Gn,
    L as Hn,
    d as Jt,
    F as ms,
    M as Ie,
    S as Nr,
    P as kr,
    D as Jr,
    e as zt,
    I as Kr,
    Q as pi,
    f as zr,
    O as Nn,
    g as vs,
    h as Yr,
    B as ot,
    i as Xr,
    j as kn,
    N as jr,
    k as Qr,
    l as Vr,
    m as Ve,
    n as Yt,
    o as ai,
    p as Wr,
    q as Zr,
    r as qr,
    s as Kt,
    t as $r,
    u as Jn,
    v as Nt,
    w as kt,
    x as eo,
    y as mi,
    z as to,
    A as Kn,
    G as so,
    H as io,
    J as no,
    K as ro,
    U as Fs,
    W as zn,
    X as Ai,
    Y as Yn,
    Z as oo,
    _ as ao,
    $ as co,
    a0 as lo,
    a1 as Xn,
    a2 as ho,
    a3 as at,
    a4 as zi,
    a5 as Yi,
    a6 as Xi,
    a7 as jn,
    a8 as uo,
    a9 as Qn,
    aa as Vn,
    ab as x,
    ac as X,
    ad as fo,
    ae as ct,
    af as po,
    ag as Ne,
    ah as mo,
    ai as Be,
    aj as Wn,
    ak as ps,
    al as gi,
    am as Fe,
    an as ci,
    ao as Ao,
    ap as go,
    aq as vi,
    ar as vo,
    as as Bo,
    at as Eo,
    au as Qe,
    av as ne,
    aw as Co,
    ax as _o,
    ay as To,
    az as Ct,
    aA as Bi,
    aB as Zn,
    aC as qn,
    aD as ji,
    aE as ns,
    aF as lt,
    aG as G,
    aH as yo,
    aI as ae,
    aJ as bo,
    aK as L,
    aL as Ei,
    aM as I,
    aN as he,
    aO as $n,
    aP as Qi,
    aQ as So,
    aR as Ci,
    aS as Vi,
    aT as Bs
} from "./index-DjXkBzPf.js";

function Xt() {
    return Xt = Object.assign ? Object.assign.bind() : function(s) {
        for (var e = 1; e < arguments.length; e++) {
            var t = arguments[e];
            for (var i in t)({}).hasOwnProperty.call(t, i) && (s[i] = t[i])
        }
        return s
    }, Xt.apply(null, arguments)
}
new Z;
new Z;

function _i(s, e, t) {
    return Math.max(e, Math.min(t, s))
}

function Mo(s, e) {
    return _i(s - Math.floor(s / e) * e, 0, e)
}

function Ro(s, e) {
    var t = Mo(e - s, Math.PI * 2);
    return t > Math.PI && (t -= Math.PI * 2), t
}
var xo = function(e) {
        return 1 / (1 + e + .48 * e * e + .235 * e * e * e)
    },
    Pl = { in: function(e) {
            return 1 - Math.cos(e * Math.PI / 2)
        },
        out: function(e) {
            return Math.sin(e * Math.PI / 2)
        },
        inOut: function(e) {
            return -(Math.cos(Math.PI * e) - 1) / 2
        }
    },
    Wi = { in: function(e) {
            return 1 - Math.sqrt(1 - Math.pow(e, 2))
        },
        out: function(e) {
            return Math.sqrt(1 - Math.pow(e - 1, 2))
        },
        inOut: function(e) {
            return e < .5 ? (1 - Math.sqrt(1 - Math.pow(2 * e, 2))) / 2 : (Math.sqrt(1 - Math.pow(-2 * e + 2, 2)) + 1) / 2
        }
    };

function ge(s, e, t) {
    var i = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : .25,
        n = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : .01,
        r = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : 1 / 0,
        o = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : xo,
        a = arguments.length > 7 && arguments[7] !== void 0 ? arguments[7] : .001,
        c = "velocity_" + e;
    if (s.__damp === void 0 && (s.__damp = {}), s.__damp[c] === void 0 && (s.__damp[c] = 0), Math.abs(s[e] - t) <= a) return s[e] = t, !1;
    i = Math.max(1e-4, i);
    var l = 2 / i,
        u = o(l * n),
        f = s[e] - t,
        p = t,
        A = r * i;
    f = Math.min(Math.max(f, -A), A), t = s[e] - f;
    var v = (s.__damp[c] + l * f) * n;
    s.__damp[c] = (s.__damp[c] - l * v) * u;
    var _ = t + (f + v) * u;
    return p - s[e] > 0 == _ > p && (_ = p, s.__damp[c] = (_ - p) / n), s[e] = _, !0
}

function Us(s, e, t, i, n, r, o, a) {
    return ge(s, e, s[e] + Ro(s[e], t), i, n, r, o, a)
}
var dt = new Pe,
    Zi, qi, $i;

function Gl(s, e, t, i, n, r, o) {
    return typeof e == "number" ? dt.setScalar(e) : Array.isArray(e) ? dt.set(e[0], e[1], e[2]) : dt.copy(e), Zi = ge(s, "x", dt.x, t, i, n, r, o), qi = ge(s, "y", dt.y, t, i, n, r, o), $i = ge(s, "z", dt.z, t, i, n, r, o), Zi || qi || $i
}
var Ot = new Pn,
    en, tn, sn;

function Hl(s, e, t, i, n, r, o) {
    return Array.isArray(e) ? Ot.set(e[0], e[1], e[2], e[3]) : Ot.copy(e), en = Us(s, "x", Ot.x, t, i, n, r, o), tn = Us(s, "y", Ot.y, t, i, n, r, o), sn = Us(s, "z", Ot.z, t, i, n, r, o), en || tn || sn
}
var ft = new ve,
    nn, rn, on;

function Nl(s, e, t, i, n, r, o) {
    return e instanceof ve ? ft.copy(e) : Array.isArray(e) ? ft.setRGB(e[0], e[1], e[2]) : ft.set(e), nn = ge(s, "r", ft.r, t, i, n, r, o), rn = ge(s, "g", ft.g, t, i, n, r, o), on = ge(s, "b", ft.b, t, i, n, r, o), nn || rn || on
}
let It;

function Do() {
    var s;
    if (It !== void 0) return It;
    try {
        let e;
        const t = document.createElement("canvas");
        return It = !!(window.WebGL2RenderingContext && (e = t.getContext("webgl2"))), e && ((s = e.getExtension("WEBGL_lose_context")) == null || s.loseContext()), It
    } catch {
        return It = !1
    }
}
const Oo = parseInt(fi.replace(/\D+/g, ""));

function an(s, e) {
    if (e === Hr) return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."), s;
    if (e === oi || e === Gn) {
        let t = s.getIndex();
        if (t === null) {
            const o = [],
                a = s.getAttribute("position");
            if (a !== void 0) {
                for (let c = 0; c < a.count; c++) o.push(c);
                s.setIndex(o), t = s.getIndex()
            } else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."), s
        }
        const i = t.count - 2,
            n = [];
        if (t)
            if (e === oi)
                for (let o = 1; o <= i; o++) n.push(t.getX(0)), n.push(t.getX(o)), n.push(t.getX(o + 1));
            else
                for (let o = 0; o < i; o++) o % 2 === 0 ? (n.push(t.getX(o)), n.push(t.getX(o + 1)), n.push(t.getX(o + 2))) : (n.push(t.getX(o + 2)), n.push(t.getX(o + 1)), n.push(t.getX(o)));
        n.length / 3 !== i && console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");
        const r = s.clone();
        return r.setIndex(n), r.clearGroups(), r
    } else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:", e), s
}

function As(s) {
    if (typeof TextDecoder < "u") return new TextDecoder().decode(s);
    let e = "";
    for (let t = 0, i = s.length; t < i; t++) e += String.fromCharCode(s[t]);
    try {
        return decodeURIComponent(escape(e))
    } catch {
        return e
    }
}
const rt = "srgb",
    Ge = "srgb-linear",
    cn = 3001,
    Io = 3e3;
class Ti extends Hn {
    constructor(e) {
        super(e), this.dracoLoader = null, this.ktx2Loader = null, this.meshoptDecoder = null, this.pluginCallbacks = [], this.register(function(t) {
            return new Po(t)
        }), this.register(function(t) {
            return new Go(t)
        }), this.register(function(t) {
            return new jo(t)
        }), this.register(function(t) {
            return new Qo(t)
        }), this.register(function(t) {
            return new Vo(t)
        }), this.register(function(t) {
            return new No(t)
        }), this.register(function(t) {
            return new ko(t)
        }), this.register(function(t) {
            return new Jo(t)
        }), this.register(function(t) {
            return new Ko(t)
        }), this.register(function(t) {
            return new wo(t)
        }), this.register(function(t) {
            return new zo(t)
        }), this.register(function(t) {
            return new Ho(t)
        }), this.register(function(t) {
            return new Xo(t)
        }), this.register(function(t) {
            return new Yo(t)
        }), this.register(function(t) {
            return new Uo(t)
        }), this.register(function(t) {
            return new Wo(t)
        }), this.register(function(t) {
            return new Zo(t)
        })
    }
    load(e, t, i, n) {
        const r = this;
        let o;
        if (this.resourcePath !== "") o = this.resourcePath;
        else if (this.path !== "") {
            const l = Jt.extractUrlBase(e);
            o = Jt.resolveURL(l, this.path)
        } else o = Jt.extractUrlBase(e);
        this.manager.itemStart(e);
        const a = function(l) {
                n ? n(l) : console.error(l), r.manager.itemError(e), r.manager.itemEnd(e)
            },
            c = new ms(this.manager);
        c.setPath(this.path), c.setResponseType("arraybuffer"), c.setRequestHeader(this.requestHeader), c.setWithCredentials(this.withCredentials), c.load(e, function(l) {
            try {
                r.parse(l, o, function(u) {
                    t(u), r.manager.itemEnd(e)
                }, a)
            } catch (u) {
                a(u)
            }
        }, i, a)
    }
    setDRACOLoader(e) {
        return this.dracoLoader = e, this
    }
    setDDSLoader() {
        throw new Error('THREE.GLTFLoader: "MSFT_texture_dds" no longer supported. Please update to "KHR_texture_basisu".')
    }
    setKTX2Loader(e) {
        return this.ktx2Loader = e, this
    }
    setMeshoptDecoder(e) {
        return this.meshoptDecoder = e, this
    }
    register(e) {
        return this.pluginCallbacks.indexOf(e) === -1 && this.pluginCallbacks.push(e), this
    }
    unregister(e) {
        return this.pluginCallbacks.indexOf(e) !== -1 && this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e), 1), this
    }
    parse(e, t, i, n) {
        let r;
        const o = {},
            a = {};
        if (typeof e == "string") r = JSON.parse(e);
        else if (e instanceof ArrayBuffer)
            if (As(new Uint8Array(e.slice(0, 4))) === er) {
                try {
                    o[k.KHR_BINARY_GLTF] = new qo(e)
                } catch (u) {
                    n && n(u);
                    return
                }
                r = JSON.parse(o[k.KHR_BINARY_GLTF].content)
            } else r = JSON.parse(As(new Uint8Array(e)));
        else r = e;
        if (r.asset === void 0 || r.asset.version[0] < 2) {
            n && n(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));
            return
        }
        const c = new ua(r, {
            path: t || this.resourcePath || "",
            crossOrigin: this.crossOrigin,
            requestHeader: this.requestHeader,
            manager: this.manager,
            ktx2Loader: this.ktx2Loader,
            meshoptDecoder: this.meshoptDecoder
        });
        c.fileLoader.setRequestHeader(this.requestHeader);
        for (let l = 0; l < this.pluginCallbacks.length; l++) {
            const u = this.pluginCallbacks[l](c);
            u.name || console.error("THREE.GLTFLoader: Invalid plugin found: missing name"), a[u.name] = u, o[u.name] = !0
        }
        if (r.extensionsUsed)
            for (let l = 0; l < r.extensionsUsed.length; ++l) {
                const u = r.extensionsUsed[l],
                    f = r.extensionsRequired || [];
                switch (u) {
                    case k.KHR_MATERIALS_UNLIT:
                        o[u] = new Lo;
                        break;
                    case k.KHR_DRACO_MESH_COMPRESSION:
                        o[u] = new $o(r, this.dracoLoader);
                        break;
                    case k.KHR_TEXTURE_TRANSFORM:
                        o[u] = new ea;
                        break;
                    case k.KHR_MESH_QUANTIZATION:
                        o[u] = new ta;
                        break;
                    default:
                        f.indexOf(u) >= 0 && a[u] === void 0 && console.warn('THREE.GLTFLoader: Unknown extension "' + u + '".')
                }
            }
        c.setExtensions(o), c.setPlugins(a), c.parse(i, n)
    }
    parseAsync(e, t) {
        const i = this;
        return new Promise(function(n, r) {
            i.parse(e, t, n, r)
        })
    }
}

function Fo() {
    let s = {};
    return {
        get: function(e) {
            return s[e]
        },
        add: function(e, t) {
            s[e] = t
        },
        remove: function(e) {
            delete s[e]
        },
        removeAll: function() {
            s = {}
        }
    }
}
const k = {
    KHR_BINARY_GLTF: "KHR_binary_glTF",
    KHR_DRACO_MESH_COMPRESSION: "KHR_draco_mesh_compression",
    KHR_LIGHTS_PUNCTUAL: "KHR_lights_punctual",
    KHR_MATERIALS_CLEARCOAT: "KHR_materials_clearcoat",
    KHR_MATERIALS_DISPERSION: "KHR_materials_dispersion",
    KHR_MATERIALS_IOR: "KHR_materials_ior",
    KHR_MATERIALS_SHEEN: "KHR_materials_sheen",
    KHR_MATERIALS_SPECULAR: "KHR_materials_specular",
    KHR_MATERIALS_TRANSMISSION: "KHR_materials_transmission",
    KHR_MATERIALS_IRIDESCENCE: "KHR_materials_iridescence",
    KHR_MATERIALS_ANISOTROPY: "KHR_materials_anisotropy",
    KHR_MATERIALS_UNLIT: "KHR_materials_unlit",
    KHR_MATERIALS_VOLUME: "KHR_materials_volume",
    KHR_TEXTURE_BASISU: "KHR_texture_basisu",
    KHR_TEXTURE_TRANSFORM: "KHR_texture_transform",
    KHR_MESH_QUANTIZATION: "KHR_mesh_quantization",
    KHR_MATERIALS_EMISSIVE_STRENGTH: "KHR_materials_emissive_strength",
    EXT_MATERIALS_BUMP: "EXT_materials_bump",
    EXT_TEXTURE_WEBP: "EXT_texture_webp",
    EXT_TEXTURE_AVIF: "EXT_texture_avif",
    EXT_MESHOPT_COMPRESSION: "EXT_meshopt_compression",
    EXT_MESH_GPU_INSTANCING: "EXT_mesh_gpu_instancing"
};
class Uo {
    constructor(e) {
        this.parser = e, this.name = k.KHR_LIGHTS_PUNCTUAL, this.cache = {
            refs: {},
            uses: {}
        }
    }
    _markDefs() {
        const e = this.parser,
            t = this.parser.json.nodes || [];
        for (let i = 0, n = t.length; i < n; i++) {
            const r = t[i];
            r.extensions && r.extensions[this.name] && r.extensions[this.name].light !== void 0 && e._addNodeRef(this.cache, r.extensions[this.name].light)
        }
    }
    _loadLight(e) {
        const t = this.parser,
            i = "light:" + e;
        let n = t.cache.get(i);
        if (n) return n;
        const r = t.json,
            c = ((r.extensions && r.extensions[this.name] || {}).lights || [])[e];
        let l;
        const u = new ve(16777215);
        c.color !== void 0 && u.setRGB(c.color[0], c.color[1], c.color[2], Ge);
        const f = c.range !== void 0 ? c.range : 0;
        switch (c.type) {
            case "directional":
                l = new Jr(u), l.target.position.set(0, 0, -1), l.add(l.target);
                break;
            case "point":
                l = new kr(u), l.distance = f;
                break;
            case "spot":
                l = new Nr(u), l.distance = f, c.spot = c.spot || {}, c.spot.innerConeAngle = c.spot.innerConeAngle !== void 0 ? c.spot.innerConeAngle : 0, c.spot.outerConeAngle = c.spot.outerConeAngle !== void 0 ? c.spot.outerConeAngle : Math.PI / 4, l.angle = c.spot.outerConeAngle, l.penumbra = 1 - c.spot.innerConeAngle / c.spot.outerConeAngle, l.target.position.set(0, 0, -1), l.add(l.target);
                break;
            default:
                throw new Error("THREE.GLTFLoader: Unexpected light type: " + c.type)
        }
        return l.position.set(0, 0, 0), l.decay = 2, we(l, c), c.intensity !== void 0 && (l.intensity = c.intensity), l.name = t.createUniqueName(c.name || "light_" + e), n = Promise.resolve(l), t.cache.add(i, n), n
    }
    getDependency(e, t) {
        if (e === "light") return this._loadLight(t)
    }
    createNodeAttachment(e) {
        const t = this,
            i = this.parser,
            r = i.json.nodes[e],
            a = (r.extensions && r.extensions[this.name] || {}).light;
        return a === void 0 ? null : this._loadLight(a).then(function(c) {
            return i._getNodeRef(t.cache, a, c)
        })
    }
}
class Lo {
    constructor() {
        this.name = k.KHR_MATERIALS_UNLIT
    }
    getMaterialType() {
        return kt
    }
    extendParams(e, t, i) {
        const n = [];
        e.color = new ve(1, 1, 1), e.opacity = 1;
        const r = t.pbrMetallicRoughness;
        if (r) {
            if (Array.isArray(r.baseColorFactor)) {
                const o = r.baseColorFactor;
                e.color.setRGB(o[0], o[1], o[2], Ge), e.opacity = o[3]
            }
            r.baseColorTexture !== void 0 && n.push(i.assignTexture(e, "map", r.baseColorTexture, rt))
        }
        return Promise.all(n)
    }
}
class wo {
    constructor(e) {
        this.parser = e, this.name = k.KHR_MATERIALS_EMISSIVE_STRENGTH
    }
    extendMaterialParams(e, t) {
        const n = this.parser.json.materials[e];
        if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
        const r = n.extensions[this.name].emissiveStrength;
        return r !== void 0 && (t.emissiveIntensity = r), Promise.resolve()
    }
}
class Po {
    constructor(e) {
        this.parser = e, this.name = k.KHR_MATERIALS_CLEARCOAT
    }
    getMaterialType(e) {
        const i = this.parser.json.materials[e];
        return !i.extensions || !i.extensions[this.name] ? null : Ie
    }
    extendMaterialParams(e, t) {
        const i = this.parser,
            n = i.json.materials[e];
        if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
        const r = [],
            o = n.extensions[this.name];
        if (o.clearcoatFactor !== void 0 && (t.clearcoat = o.clearcoatFactor), o.clearcoatTexture !== void 0 && r.push(i.assignTexture(t, "clearcoatMap", o.clearcoatTexture)), o.clearcoatRoughnessFactor !== void 0 && (t.clearcoatRoughness = o.clearcoatRoughnessFactor), o.clearcoatRoughnessTexture !== void 0 && r.push(i.assignTexture(t, "clearcoatRoughnessMap", o.clearcoatRoughnessTexture)), o.clearcoatNormalTexture !== void 0 && (r.push(i.assignTexture(t, "clearcoatNormalMap", o.clearcoatNormalTexture)), o.clearcoatNormalTexture.scale !== void 0)) {
            const a = o.clearcoatNormalTexture.scale;
            t.clearcoatNormalScale = new Z(a, a)
        }
        return Promise.all(r)
    }
}
class Go {
    constructor(e) {
        this.parser = e, this.name = k.KHR_MATERIALS_DISPERSION
    }
    getMaterialType(e) {
        const i = this.parser.json.materials[e];
        return !i.extensions || !i.extensions[this.name] ? null : Ie
    }
    extendMaterialParams(e, t) {
        const n = this.parser.json.materials[e];
        if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
        const r = n.extensions[this.name];
        return t.dispersion = r.dispersion !== void 0 ? r.dispersion : 0, Promise.resolve()
    }
}
class Ho {
    constructor(e) {
        this.parser = e, this.name = k.KHR_MATERIALS_IRIDESCENCE
    }
    getMaterialType(e) {
        const i = this.parser.json.materials[e];
        return !i.extensions || !i.extensions[this.name] ? null : Ie
    }
    extendMaterialParams(e, t) {
        const i = this.parser,
            n = i.json.materials[e];
        if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
        const r = [],
            o = n.extensions[this.name];
        return o.iridescenceFactor !== void 0 && (t.iridescence = o.iridescenceFactor), o.iridescenceTexture !== void 0 && r.push(i.assignTexture(t, "iridescenceMap", o.iridescenceTexture)), o.iridescenceIor !== void 0 && (t.iridescenceIOR = o.iridescenceIor), t.iridescenceThicknessRange === void 0 && (t.iridescenceThicknessRange = [100, 400]), o.iridescenceThicknessMinimum !== void 0 && (t.iridescenceThicknessRange[0] = o.iridescenceThicknessMinimum), o.iridescenceThicknessMaximum !== void 0 && (t.iridescenceThicknessRange[1] = o.iridescenceThicknessMaximum), o.iridescenceThicknessTexture !== void 0 && r.push(i.assignTexture(t, "iridescenceThicknessMap", o.iridescenceThicknessTexture)), Promise.all(r)
    }
}
class No {
    constructor(e) {
        this.parser = e, this.name = k.KHR_MATERIALS_SHEEN
    }
    getMaterialType(e) {
        const i = this.parser.json.materials[e];
        return !i.extensions || !i.extensions[this.name] ? null : Ie
    }
    extendMaterialParams(e, t) {
        const i = this.parser,
            n = i.json.materials[e];
        if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
        const r = [];
        t.sheenColor = new ve(0, 0, 0), t.sheenRoughness = 0, t.sheen = 1;
        const o = n.extensions[this.name];
        if (o.sheenColorFactor !== void 0) {
            const a = o.sheenColorFactor;
            t.sheenColor.setRGB(a[0], a[1], a[2], Ge)
        }
        return o.sheenRoughnessFactor !== void 0 && (t.sheenRoughness = o.sheenRoughnessFactor), o.sheenColorTexture !== void 0 && r.push(i.assignTexture(t, "sheenColorMap", o.sheenColorTexture, rt)), o.sheenRoughnessTexture !== void 0 && r.push(i.assignTexture(t, "sheenRoughnessMap", o.sheenRoughnessTexture)), Promise.all(r)
    }
}
class ko {
    constructor(e) {
        this.parser = e, this.name = k.KHR_MATERIALS_TRANSMISSION
    }
    getMaterialType(e) {
        const i = this.parser.json.materials[e];
        return !i.extensions || !i.extensions[this.name] ? null : Ie
    }
    extendMaterialParams(e, t) {
        const i = this.parser,
            n = i.json.materials[e];
        if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
        const r = [],
            o = n.extensions[this.name];
        return o.transmissionFactor !== void 0 && (t.transmission = o.transmissionFactor), o.transmissionTexture !== void 0 && r.push(i.assignTexture(t, "transmissionMap", o.transmissionTexture)), Promise.all(r)
    }
}
class Jo {
    constructor(e) {
        this.parser = e, this.name = k.KHR_MATERIALS_VOLUME
    }
    getMaterialType(e) {
        const i = this.parser.json.materials[e];
        return !i.extensions || !i.extensions[this.name] ? null : Ie
    }
    extendMaterialParams(e, t) {
        const i = this.parser,
            n = i.json.materials[e];
        if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
        const r = [],
            o = n.extensions[this.name];
        t.thickness = o.thicknessFactor !== void 0 ? o.thicknessFactor : 0, o.thicknessTexture !== void 0 && r.push(i.assignTexture(t, "thicknessMap", o.thicknessTexture)), t.attenuationDistance = o.attenuationDistance || 1 / 0;
        const a = o.attenuationColor || [1, 1, 1];
        return t.attenuationColor = new ve().setRGB(a[0], a[1], a[2], Ge), Promise.all(r)
    }
}
class Ko {
    constructor(e) {
        this.parser = e, this.name = k.KHR_MATERIALS_IOR
    }
    getMaterialType(e) {
        const i = this.parser.json.materials[e];
        return !i.extensions || !i.extensions[this.name] ? null : Ie
    }
    extendMaterialParams(e, t) {
        const n = this.parser.json.materials[e];
        if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
        const r = n.extensions[this.name];
        return t.ior = r.ior !== void 0 ? r.ior : 1.5, Promise.resolve()
    }
}
class zo {
    constructor(e) {
        this.parser = e, this.name = k.KHR_MATERIALS_SPECULAR
    }
    getMaterialType(e) {
        const i = this.parser.json.materials[e];
        return !i.extensions || !i.extensions[this.name] ? null : Ie
    }
    extendMaterialParams(e, t) {
        const i = this.parser,
            n = i.json.materials[e];
        if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
        const r = [],
            o = n.extensions[this.name];
        t.specularIntensity = o.specularFactor !== void 0 ? o.specularFactor : 1, o.specularTexture !== void 0 && r.push(i.assignTexture(t, "specularIntensityMap", o.specularTexture));
        const a = o.specularColorFactor || [1, 1, 1];
        return t.specularColor = new ve().setRGB(a[0], a[1], a[2], Ge), o.specularColorTexture !== void 0 && r.push(i.assignTexture(t, "specularColorMap", o.specularColorTexture, rt)), Promise.all(r)
    }
}
class Yo {
    constructor(e) {
        this.parser = e, this.name = k.EXT_MATERIALS_BUMP
    }
    getMaterialType(e) {
        const i = this.parser.json.materials[e];
        return !i.extensions || !i.extensions[this.name] ? null : Ie
    }
    extendMaterialParams(e, t) {
        const i = this.parser,
            n = i.json.materials[e];
        if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
        const r = [],
            o = n.extensions[this.name];
        return t.bumpScale = o.bumpFactor !== void 0 ? o.bumpFactor : 1, o.bumpTexture !== void 0 && r.push(i.assignTexture(t, "bumpMap", o.bumpTexture)), Promise.all(r)
    }
}
class Xo {
    constructor(e) {
        this.parser = e, this.name = k.KHR_MATERIALS_ANISOTROPY
    }
    getMaterialType(e) {
        const i = this.parser.json.materials[e];
        return !i.extensions || !i.extensions[this.name] ? null : Ie
    }
    extendMaterialParams(e, t) {
        const i = this.parser,
            n = i.json.materials[e];
        if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
        const r = [],
            o = n.extensions[this.name];
        return o.anisotropyStrength !== void 0 && (t.anisotropy = o.anisotropyStrength), o.anisotropyRotation !== void 0 && (t.anisotropyRotation = o.anisotropyRotation), o.anisotropyTexture !== void 0 && r.push(i.assignTexture(t, "anisotropyMap", o.anisotropyTexture)), Promise.all(r)
    }
}
class jo {
    constructor(e) {
        this.parser = e, this.name = k.KHR_TEXTURE_BASISU
    }
    loadTexture(e) {
        const t = this.parser,
            i = t.json,
            n = i.textures[e];
        if (!n.extensions || !n.extensions[this.name]) return null;
        const r = n.extensions[this.name],
            o = t.options.ktx2Loader;
        if (!o) {
            if (i.extensionsRequired && i.extensionsRequired.indexOf(this.name) >= 0) throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");
            return null
        }
        return t.loadTextureImage(e, r.source, o)
    }
}
class Qo {
    constructor(e) {
        this.parser = e, this.name = k.EXT_TEXTURE_WEBP, this.isSupported = null
    }
    loadTexture(e) {
        const t = this.name,
            i = this.parser,
            n = i.json,
            r = n.textures[e];
        if (!r.extensions || !r.extensions[t]) return null;
        const o = r.extensions[t],
            a = n.images[o.source];
        let c = i.textureLoader;
        if (a.uri) {
            const l = i.options.manager.getHandler(a.uri);
            l !== null && (c = l)
        }
        return this.detectSupport().then(function(l) {
            if (l) return i.loadTextureImage(e, o.source, c);
            if (n.extensionsRequired && n.extensionsRequired.indexOf(t) >= 0) throw new Error("THREE.GLTFLoader: WebP required by asset but unsupported.");
            return i.loadTexture(e)
        })
    }
    detectSupport() {
        return this.isSupported || (this.isSupported = new Promise(function(e) {
            const t = new Image;
            t.src = "data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEADsD+JaQAA3AAAAAA", t.onload = t.onerror = function() {
                e(t.height === 1)
            }
        })), this.isSupported
    }
}
class Vo {
    constructor(e) {
        this.parser = e, this.name = k.EXT_TEXTURE_AVIF, this.isSupported = null
    }
    loadTexture(e) {
        const t = this.name,
            i = this.parser,
            n = i.json,
            r = n.textures[e];
        if (!r.extensions || !r.extensions[t]) return null;
        const o = r.extensions[t],
            a = n.images[o.source];
        let c = i.textureLoader;
        if (a.uri) {
            const l = i.options.manager.getHandler(a.uri);
            l !== null && (c = l)
        }
        return this.detectSupport().then(function(l) {
            if (l) return i.loadTextureImage(e, o.source, c);
            if (n.extensionsRequired && n.extensionsRequired.indexOf(t) >= 0) throw new Error("THREE.GLTFLoader: AVIF required by asset but unsupported.");
            return i.loadTexture(e)
        })
    }
    detectSupport() {
        return this.isSupported || (this.isSupported = new Promise(function(e) {
            const t = new Image;
            t.src = "data:image/avif;base64,AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUIAAADybWV0YQAAAAAAAAAoaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAGxpYmF2aWYAAAAADnBpdG0AAAAAAAEAAAAeaWxvYwAAAABEAAABAAEAAAABAAABGgAAABcAAAAoaWluZgAAAAAAAQAAABppbmZlAgAAAAABAABhdjAxQ29sb3IAAAAAamlwcnAAAABLaXBjbwAAABRpc3BlAAAAAAAAAAEAAAABAAAAEHBpeGkAAAAAAwgICAAAAAxhdjFDgQAMAAAAABNjb2xybmNseAACAAIABoAAAAAXaXBtYQAAAAAAAAABAAEEAQKDBAAAAB9tZGF0EgAKCBgABogQEDQgMgkQAAAAB8dSLfI=", t.onload = t.onerror = function() {
                e(t.height === 1)
            }
        })), this.isSupported
    }
}
class Wo {
    constructor(e) {
        this.name = k.EXT_MESHOPT_COMPRESSION, this.parser = e
    }
    loadBufferView(e) {
        const t = this.parser.json,
            i = t.bufferViews[e];
        if (i.extensions && i.extensions[this.name]) {
            const n = i.extensions[this.name],
                r = this.parser.getDependency("buffer", n.buffer),
                o = this.parser.options.meshoptDecoder;
            if (!o || !o.supported) {
                if (t.extensionsRequired && t.extensionsRequired.indexOf(this.name) >= 0) throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");
                return null
            }
            return r.then(function(a) {
                const c = n.byteOffset || 0,
                    l = n.byteLength || 0,
                    u = n.count,
                    f = n.byteStride,
                    p = new Uint8Array(a, c, l);
                return o.decodeGltfBufferAsync ? o.decodeGltfBufferAsync(u, f, p, n.mode, n.filter).then(function(A) {
                    return A.buffer
                }) : o.ready.then(function() {
                    const A = new ArrayBuffer(u * f);
                    return o.decodeGltfBuffer(new Uint8Array(A), u, f, p, n.mode, n.filter), A
                })
            })
        } else return null
    }
}
class Zo {
    constructor(e) {
        this.name = k.EXT_MESH_GPU_INSTANCING, this.parser = e
    }
    createNodeMesh(e) {
        const t = this.parser.json,
            i = t.nodes[e];
        if (!i.extensions || !i.extensions[this.name] || i.mesh === void 0) return null;
        const n = t.meshes[i.mesh];
        for (const l of n.primitives)
            if (l.mode !== Ae.TRIANGLES && l.mode !== Ae.TRIANGLE_STRIP && l.mode !== Ae.TRIANGLE_FAN && l.mode !== void 0) return null;
        const o = i.extensions[this.name].attributes,
            a = [],
            c = {};
        for (const l in o) a.push(this.parser.getDependency("accessor", o[l]).then(u => (c[l] = u, c[l])));
        return a.length < 1 ? null : (a.push(this.parser.createNodeMesh(e)), Promise.all(a).then(l => {
            const u = l.pop(),
                f = u.isGroup ? u.children : [u],
                p = l[0].count,
                A = [];
            for (const v of f) {
                const _ = new zt,
                    T = new Pe,
                    g = new pi,
                    B = new Pe(1, 1, 1),
                    y = new Kr(v.geometry, v.material, p);
                for (let b = 0; b < p; b++) c.TRANSLATION && T.fromBufferAttribute(c.TRANSLATION, b), c.ROTATION && g.fromBufferAttribute(c.ROTATION, b), c.SCALE && B.fromBufferAttribute(c.SCALE, b), y.setMatrixAt(b, _.compose(T, g, B));
                for (const b in c)
                    if (b === "_COLOR_0") {
                        const S = c[b];
                        y.instanceColor = new zr(S.array, S.itemSize, S.normalized)
                    } else b !== "TRANSLATION" && b !== "ROTATION" && b !== "SCALE" && v.geometry.setAttribute(b, c[b]);
                Nn.prototype.copy.call(y, v), this.parser.assignFinalMaterial(y), A.push(y)
            }
            return u.isGroup ? (u.clear(), u.add(...A), u) : A[0]
        }))
    }
}
const er = "glTF",
    Ft = 12,
    ln = {
        JSON: 1313821514,
        BIN: 5130562
    };
class qo {
    constructor(e) {
        this.name = k.KHR_BINARY_GLTF, this.content = null, this.body = null;
        const t = new DataView(e, 0, Ft);
        if (this.header = {
                magic: As(new Uint8Array(e.slice(0, 4))),
                version: t.getUint32(4, !0),
                length: t.getUint32(8, !0)
            }, this.header.magic !== er) throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");
        if (this.header.version < 2) throw new Error("THREE.GLTFLoader: Legacy binary file detected.");
        const i = this.header.length - Ft,
            n = new DataView(e, Ft);
        let r = 0;
        for (; r < i;) {
            const o = n.getUint32(r, !0);
            r += 4;
            const a = n.getUint32(r, !0);
            if (r += 4, a === ln.JSON) {
                const c = new Uint8Array(e, Ft + r, o);
                this.content = As(c)
            } else if (a === ln.BIN) {
                const c = Ft + r;
                this.body = e.slice(c, c + o)
            }
            r += o
        }
        if (this.content === null) throw new Error("THREE.GLTFLoader: JSON content not found.")
    }
}
class $o {
    constructor(e, t) {
        if (!t) throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");
        this.name = k.KHR_DRACO_MESH_COMPRESSION, this.json = e, this.dracoLoader = t, this.dracoLoader.preload()
    }
    decodePrimitive(e, t) {
        const i = this.json,
            n = this.dracoLoader,
            r = e.extensions[this.name].bufferView,
            o = e.extensions[this.name].attributes,
            a = {},
            c = {},
            l = {};
        for (const u in o) {
            const f = li[u] || u.toLowerCase();
            a[f] = o[u]
        }
        for (const u in e.attributes) {
            const f = li[u] || u.toLowerCase();
            if (o[u] !== void 0) {
                const p = i.accessors[e.attributes[u]],
                    A = Bt[p.componentType];
                l[f] = A.name, c[f] = p.normalized === !0
            }
        }
        return t.getDependency("bufferView", r).then(function(u) {
            return new Promise(function(f, p) {
                n.decodeDracoFile(u, function(A) {
                    for (const v in A.attributes) {
                        const _ = A.attributes[v],
                            T = c[v];
                        T !== void 0 && (_.normalized = T)
                    }
                    f(A)
                }, a, l, Ge, p)
            })
        })
    }
}
class ea {
    constructor() {
        this.name = k.KHR_TEXTURE_TRANSFORM
    }
    extendTexture(e, t) {
        return (t.texCoord === void 0 || t.texCoord === e.channel) && t.offset === void 0 && t.rotation === void 0 && t.scale === void 0 || (e = e.clone(), t.texCoord !== void 0 && (e.channel = t.texCoord), t.offset !== void 0 && e.offset.fromArray(t.offset), t.rotation !== void 0 && (e.rotation = t.rotation), t.scale !== void 0 && e.repeat.fromArray(t.scale), e.needsUpdate = !0), e
    }
}
class ta {
    constructor() {
        this.name = k.KHR_MESH_QUANTIZATION
    }
}
class tr extends uo {
    constructor(e, t, i, n) {
        super(e, t, i, n)
    }
    copySampleValue_(e) {
        const t = this.resultBuffer,
            i = this.sampleValues,
            n = this.valueSize,
            r = e * n * 3 + n;
        for (let o = 0; o !== n; o++) t[o] = i[r + o];
        return t
    }
    interpolate_(e, t, i, n) {
        const r = this.resultBuffer,
            o = this.sampleValues,
            a = this.valueSize,
            c = a * 2,
            l = a * 3,
            u = n - t,
            f = (i - t) / u,
            p = f * f,
            A = p * f,
            v = e * l,
            _ = v - l,
            T = -2 * A + 3 * p,
            g = A - p,
            B = 1 - T,
            y = g - p + f;
        for (let b = 0; b !== a; b++) {
            const S = o[_ + b + a],
                R = o[_ + b + c] * u,
                D = o[v + b + a],
                F = o[v + b] * u;
            r[b] = B * S + y * R + T * D + g * F
        }
        return r
    }
}
const sa = new pi;
class ia extends tr {
    interpolate_(e, t, i, n) {
        const r = super.interpolate_(e, t, i, n);
        return sa.fromArray(r).normalize().toArray(r), r
    }
}
const Ae = {
        POINTS: 0,
        LINES: 1,
        LINE_LOOP: 2,
        LINE_STRIP: 3,
        TRIANGLES: 4,
        TRIANGLE_STRIP: 5,
        TRIANGLE_FAN: 6
    },
    Bt = {
        5120: Int8Array,
        5121: Uint8Array,
        5122: Int16Array,
        5123: Uint16Array,
        5125: Uint32Array,
        5126: Float32Array
    },
    hn = {
        9728: Yt,
        9729: Ve,
        9984: Vr,
        9985: Qr,
        9986: jr,
        9987: kn
    },
    un = {
        33071: Zr,
        33648: Wr,
        10497: ai
    },
    Ls = {
        SCALAR: 1,
        VEC2: 2,
        VEC3: 3,
        VEC4: 4,
        MAT2: 4,
        MAT3: 9,
        MAT4: 16
    },
    li = {
        POSITION: "position",
        NORMAL: "normal",
        TANGENT: "tangent",
        ...Oo >= 152 ? {
            TEXCOORD_0: "uv",
            TEXCOORD_1: "uv1",
            TEXCOORD_2: "uv2",
            TEXCOORD_3: "uv3"
        } : {
            TEXCOORD_0: "uv",
            TEXCOORD_1: "uv2"
        },
        COLOR_0: "color",
        WEIGHTS_0: "skinWeight",
        JOINTS_0: "skinIndex"
    },
    Ke = {
        scale: "scale",
        translation: "position",
        rotation: "quaternion",
        weights: "morphTargetInfluences"
    },
    na = {
        CUBICSPLINE: void 0,
        LINEAR: Xn,
        STEP: lo
    },
    ws = {
        OPAQUE: "OPAQUE",
        MASK: "MASK",
        BLEND: "BLEND"
    };

function ra(s) {
    return s.DefaultMaterial === void 0 && (s.DefaultMaterial = new Jn({
        color: 16777215,
        emissive: 0,
        metalness: 1,
        roughness: 1,
        transparent: !1,
        depthTest: !0,
        side: jn
    })), s.DefaultMaterial
}

function tt(s, e, t) {
    for (const i in t.extensions) s[i] === void 0 && (e.userData.gltfExtensions = e.userData.gltfExtensions || {}, e.userData.gltfExtensions[i] = t.extensions[i])
}

function we(s, e) {
    e.extras !== void 0 && (typeof e.extras == "object" ? Object.assign(s.userData, e.extras) : console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, " + e.extras))
}

function oa(s, e, t) {
    let i = !1,
        n = !1,
        r = !1;
    for (let l = 0, u = e.length; l < u; l++) {
        const f = e[l];
        if (f.POSITION !== void 0 && (i = !0), f.NORMAL !== void 0 && (n = !0), f.COLOR_0 !== void 0 && (r = !0), i && n && r) break
    }
    if (!i && !n && !r) return Promise.resolve(s);
    const o = [],
        a = [],
        c = [];
    for (let l = 0, u = e.length; l < u; l++) {
        const f = e[l];
        if (i) {
            const p = f.POSITION !== void 0 ? t.getDependency("accessor", f.POSITION) : s.attributes.position;
            o.push(p)
        }
        if (n) {
            const p = f.NORMAL !== void 0 ? t.getDependency("accessor", f.NORMAL) : s.attributes.normal;
            a.push(p)
        }
        if (r) {
            const p = f.COLOR_0 !== void 0 ? t.getDependency("accessor", f.COLOR_0) : s.attributes.color;
            c.push(p)
        }
    }
    return Promise.all([Promise.all(o), Promise.all(a), Promise.all(c)]).then(function(l) {
        const u = l[0],
            f = l[1],
            p = l[2];
        return i && (s.morphAttributes.position = u), n && (s.morphAttributes.normal = f), r && (s.morphAttributes.color = p), s.morphTargetsRelative = !0, s
    })
}

function aa(s, e) {
    if (s.updateMorphTargets(), e.weights !== void 0)
        for (let t = 0, i = e.weights.length; t < i; t++) s.morphTargetInfluences[t] = e.weights[t];
    if (e.extras && Array.isArray(e.extras.targetNames)) {
        const t = e.extras.targetNames;
        if (s.morphTargetInfluences.length === t.length) {
            s.morphTargetDictionary = {};
            for (let i = 0, n = t.length; i < n; i++) s.morphTargetDictionary[t[i]] = i
        } else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")
    }
}

function ca(s) {
    let e;
    const t = s.extensions && s.extensions[k.KHR_DRACO_MESH_COMPRESSION];
    if (t ? e = "draco:" + t.bufferView + ":" + t.indices + ":" + Ps(t.attributes) : e = s.indices + ":" + Ps(s.attributes) + ":" + s.mode, s.targets !== void 0)
        for (let i = 0, n = s.targets.length; i < n; i++) e += ":" + Ps(s.targets[i]);
    return e
}

function Ps(s) {
    let e = "";
    const t = Object.keys(s).sort();
    for (let i = 0, n = t.length; i < n; i++) e += t[i] + ":" + s[t[i]] + ";";
    return e
}

function hi(s) {
    switch (s) {
        case Int8Array:
            return 1 / 127;
        case Uint8Array:
            return 1 / 255;
        case Int16Array:
            return 1 / 32767;
        case Uint16Array:
            return 1 / 65535;
        default:
            throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")
    }
}

function la(s) {
    return s.search(/\.jpe?g($|\?)/i) > 0 || s.search(/^data\:image\/jpeg/) === 0 ? "image/jpeg" : s.search(/\.webp($|\?)/i) > 0 || s.search(/^data\:image\/webp/) === 0 ? "image/webp" : "image/png"
}
const ha = new zt;
class ua {
    constructor(e = {}, t = {}) {
        this.json = e, this.extensions = {}, this.plugins = {}, this.options = t, this.cache = new Fo, this.associations = new Map, this.primitiveCache = {}, this.nodeCache = {}, this.meshCache = {
            refs: {},
            uses: {}
        }, this.cameraCache = {
            refs: {},
            uses: {}
        }, this.lightCache = {
            refs: {},
            uses: {}
        }, this.sourceCache = {}, this.textureCache = {}, this.nodeNamesUsed = {};
        let i = !1,
            n = !1,
            r = -1;
        typeof navigator < "u" && typeof navigator.userAgent < "u" && (i = /^((?!chrome|android).)*safari/i.test(navigator.userAgent) === !0, n = navigator.userAgent.indexOf("Firefox") > -1, r = n ? navigator.userAgent.match(/Firefox\/([0-9]+)\./)[1] : -1), typeof createImageBitmap > "u" || i || n && r < 98 ? this.textureLoader = new vs(this.options.manager) : this.textureLoader = new Yr(this.options.manager), this.textureLoader.setCrossOrigin(this.options.crossOrigin), this.textureLoader.setRequestHeader(this.options.requestHeader), this.fileLoader = new ms(this.options.manager), this.fileLoader.setResponseType("arraybuffer"), this.options.crossOrigin === "use-credentials" && this.fileLoader.setWithCredentials(!0)
    }
    setExtensions(e) {
        this.extensions = e
    }
    setPlugins(e) {
        this.plugins = e
    }
    parse(e, t) {
        const i = this,
            n = this.json,
            r = this.extensions;
        this.cache.removeAll(), this.nodeCache = {}, this._invokeAll(function(o) {
            return o._markDefs && o._markDefs()
        }), Promise.all(this._invokeAll(function(o) {
            return o.beforeRoot && o.beforeRoot()
        })).then(function() {
            return Promise.all([i.getDependencies("scene"), i.getDependencies("animation"), i.getDependencies("camera")])
        }).then(function(o) {
            const a = {
                scene: o[0][n.scene || 0],
                scenes: o[0],
                animations: o[1],
                cameras: o[2],
                asset: n.asset,
                parser: i,
                userData: {}
            };
            return tt(r, a, n), we(a, n), Promise.all(i._invokeAll(function(c) {
                return c.afterRoot && c.afterRoot(a)
            })).then(function() {
                for (const c of a.scenes) c.updateMatrixWorld();
                e(a)
            })
        }).catch(t)
    }
    _markDefs() {
        const e = this.json.nodes || [],
            t = this.json.skins || [],
            i = this.json.meshes || [];
        for (let n = 0, r = t.length; n < r; n++) {
            const o = t[n].joints;
            for (let a = 0, c = o.length; a < c; a++) e[o[a]].isBone = !0
        }
        for (let n = 0, r = e.length; n < r; n++) {
            const o = e[n];
            o.mesh !== void 0 && (this._addNodeRef(this.meshCache, o.mesh), o.skin !== void 0 && (i[o.mesh].isSkinnedMesh = !0)), o.camera !== void 0 && this._addNodeRef(this.cameraCache, o.camera)
        }
    }
    _addNodeRef(e, t) {
        t !== void 0 && (e.refs[t] === void 0 && (e.refs[t] = e.uses[t] = 0), e.refs[t]++)
    }
    _getNodeRef(e, t, i) {
        if (e.refs[t] <= 1) return i;
        const n = i.clone(),
            r = (o, a) => {
                const c = this.associations.get(o);
                c != null && this.associations.set(a, c);
                for (const [l, u] of o.children.entries()) r(u, a.children[l])
            };
        return r(i, n), n.name += "_instance_" + e.uses[t]++, n
    }
    _invokeOne(e) {
        const t = Object.values(this.plugins);
        t.push(this);
        for (let i = 0; i < t.length; i++) {
            const n = e(t[i]);
            if (n) return n
        }
        return null
    }
    _invokeAll(e) {
        const t = Object.values(this.plugins);
        t.unshift(this);
        const i = [];
        for (let n = 0; n < t.length; n++) {
            const r = e(t[n]);
            r && i.push(r)
        }
        return i
    }
    getDependency(e, t) {
        const i = e + ":" + t;
        let n = this.cache.get(i);
        if (!n) {
            switch (e) {
                case "scene":
                    n = this.loadScene(t);
                    break;
                case "node":
                    n = this._invokeOne(function(r) {
                        return r.loadNode && r.loadNode(t)
                    });
                    break;
                case "mesh":
                    n = this._invokeOne(function(r) {
                        return r.loadMesh && r.loadMesh(t)
                    });
                    break;
                case "accessor":
                    n = this.loadAccessor(t);
                    break;
                case "bufferView":
                    n = this._invokeOne(function(r) {
                        return r.loadBufferView && r.loadBufferView(t)
                    });
                    break;
                case "buffer":
                    n = this.loadBuffer(t);
                    break;
                case "material":
                    n = this._invokeOne(function(r) {
                        return r.loadMaterial && r.loadMaterial(t)
                    });
                    break;
                case "texture":
                    n = this._invokeOne(function(r) {
                        return r.loadTexture && r.loadTexture(t)
                    });
                    break;
                case "skin":
                    n = this.loadSkin(t);
                    break;
                case "animation":
                    n = this._invokeOne(function(r) {
                        return r.loadAnimation && r.loadAnimation(t)
                    });
                    break;
                case "camera":
                    n = this.loadCamera(t);
                    break;
                default:
                    if (n = this._invokeOne(function(r) {
                            return r != this && r.getDependency && r.getDependency(e, t)
                        }), !n) throw new Error("Unknown type: " + e);
                    break
            }
            this.cache.add(i, n)
        }
        return n
    }
    getDependencies(e) {
        let t = this.cache.get(e);
        if (!t) {
            const i = this,
                n = this.json[e + (e === "mesh" ? "es" : "s")] || [];
            t = Promise.all(n.map(function(r, o) {
                return i.getDependency(e, o)
            })), this.cache.add(e, t)
        }
        return t
    }
    loadBuffer(e) {
        const t = this.json.buffers[e],
            i = this.fileLoader;
        if (t.type && t.type !== "arraybuffer") throw new Error("THREE.GLTFLoader: " + t.type + " buffer type is not supported.");
        if (t.uri === void 0 && e === 0) return Promise.resolve(this.extensions[k.KHR_BINARY_GLTF].body);
        const n = this.options;
        return new Promise(function(r, o) {
            i.load(Jt.resolveURL(t.uri, n.path), r, void 0, function() {
                o(new Error('THREE.GLTFLoader: Failed to load buffer "' + t.uri + '".'))
            })
        })
    }
    loadBufferView(e) {
        const t = this.json.bufferViews[e];
        return this.getDependency("buffer", t.buffer).then(function(i) {
            const n = t.byteLength || 0,
                r = t.byteOffset || 0;
            return i.slice(r, r + n)
        })
    }
    loadAccessor(e) {
        const t = this,
            i = this.json,
            n = this.json.accessors[e];
        if (n.bufferView === void 0 && n.sparse === void 0) {
            const o = Ls[n.type],
                a = Bt[n.componentType],
                c = n.normalized === !0,
                l = new a(n.count * o);
            return Promise.resolve(new ot(l, o, c))
        }
        const r = [];
        return n.bufferView !== void 0 ? r.push(this.getDependency("bufferView", n.bufferView)) : r.push(null), n.sparse !== void 0 && (r.push(this.getDependency("bufferView", n.sparse.indices.bufferView)), r.push(this.getDependency("bufferView", n.sparse.values.bufferView))), Promise.all(r).then(function(o) {
            const a = o[0],
                c = Ls[n.type],
                l = Bt[n.componentType],
                u = l.BYTES_PER_ELEMENT,
                f = u * c,
                p = n.byteOffset || 0,
                A = n.bufferView !== void 0 ? i.bufferViews[n.bufferView].byteStride : void 0,
                v = n.normalized === !0;
            let _, T;
            if (A && A !== f) {
                const g = Math.floor(p / A),
                    B = "InterleavedBuffer:" + n.bufferView + ":" + n.componentType + ":" + g + ":" + n.count;
                let y = t.cache.get(B);
                y || (_ = new l(a, g * A, n.count * A / u), y = new Xr(_, A / u), t.cache.add(B, y)), T = new ho(y, c, p % A / u, v)
            } else a === null ? _ = new l(n.count * c) : _ = new l(a, p, n.count * c), T = new ot(_, c, v);
            if (n.sparse !== void 0) {
                const g = Ls.SCALAR,
                    B = Bt[n.sparse.indices.componentType],
                    y = n.sparse.indices.byteOffset || 0,
                    b = n.sparse.values.byteOffset || 0,
                    S = new B(o[1], y, n.sparse.count * g),
                    R = new l(o[2], b, n.sparse.count * c);
                a !== null && (T = new ot(T.array.slice(), T.itemSize, T.normalized));
                for (let D = 0, F = S.length; D < F; D++) {
                    const w = S[D];
                    if (T.setX(w, R[D * c]), c >= 2 && T.setY(w, R[D * c + 1]), c >= 3 && T.setZ(w, R[D * c + 2]), c >= 4 && T.setW(w, R[D * c + 3]), c >= 5) throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")
                }
            }
            return T
        })
    }
    loadTexture(e) {
        const t = this.json,
            i = this.options,
            r = t.textures[e].source,
            o = t.images[r];
        let a = this.textureLoader;
        if (o.uri) {
            const c = i.manager.getHandler(o.uri);
            c !== null && (a = c)
        }
        return this.loadTextureImage(e, r, a)
    }
    loadTextureImage(e, t, i) {
        const n = this,
            r = this.json,
            o = r.textures[e],
            a = r.images[t],
            c = (a.uri || a.bufferView) + ":" + o.sampler;
        if (this.textureCache[c]) return this.textureCache[c];
        const l = this.loadImageSource(t, i).then(function(u) {
            u.flipY = !1, u.name = o.name || a.name || "", u.name === "" && typeof a.uri == "string" && a.uri.startsWith("data:image/") === !1 && (u.name = a.uri);
            const p = (r.samplers || {})[o.sampler] || {};
            return u.magFilter = hn[p.magFilter] || Ve, u.minFilter = hn[p.minFilter] || kn, u.wrapS = un[p.wrapS] || ai, u.wrapT = un[p.wrapT] || ai, n.associations.set(u, {
                textures: e
            }), u
        }).catch(function() {
            return null
        });
        return this.textureCache[c] = l, l
    }
    loadImageSource(e, t) {
        const i = this,
            n = this.json,
            r = this.options;
        if (this.sourceCache[e] !== void 0) return this.sourceCache[e].then(f => f.clone());
        const o = n.images[e],
            a = self.URL || self.webkitURL;
        let c = o.uri || "",
            l = !1;
        if (o.bufferView !== void 0) c = i.getDependency("bufferView", o.bufferView).then(function(f) {
            l = !0;
            const p = new Blob([f], {
                type: o.mimeType
            });
            return c = a.createObjectURL(p), c
        });
        else if (o.uri === void 0) throw new Error("THREE.GLTFLoader: Image " + e + " is missing URI and bufferView");
        const u = Promise.resolve(c).then(function(f) {
            return new Promise(function(p, A) {
                let v = p;
                t.isImageBitmapLoader === !0 && (v = function(_) {
                    const T = new at(_);
                    T.needsUpdate = !0, p(T)
                }), t.load(Jt.resolveURL(f, r.path), v, void 0, A)
            })
        }).then(function(f) {
            return l === !0 && a.revokeObjectURL(c), we(f, o), f.userData.mimeType = o.mimeType || la(o.uri), f
        }).catch(function(f) {
            throw console.error("THREE.GLTFLoader: Couldn't load texture", c), f
        });
        return this.sourceCache[e] = u, u
    }
    assignTexture(e, t, i, n) {
        const r = this;
        return this.getDependency("texture", i.index).then(function(o) {
            if (!o) return null;
            if (i.texCoord !== void 0 && i.texCoord > 0 && (o = o.clone(), o.channel = i.texCoord), r.extensions[k.KHR_TEXTURE_TRANSFORM]) {
                const a = i.extensions !== void 0 ? i.extensions[k.KHR_TEXTURE_TRANSFORM] : void 0;
                if (a) {
                    const c = r.associations.get(o);
                    o = r.extensions[k.KHR_TEXTURE_TRANSFORM].extendTexture(o, a), r.associations.set(o, c)
                }
            }
            return n !== void 0 && (typeof n == "number" && (n = n === cn ? rt : Ge), "colorSpace" in o ? o.colorSpace = n : o.encoding = n === rt ? cn : Io), e[t] = o, o
        })
    }
    assignFinalMaterial(e) {
        const t = e.geometry;
        let i = e.material;
        const n = t.attributes.tangent === void 0,
            r = t.attributes.color !== void 0,
            o = t.attributes.normal === void 0;
        if (e.isPoints) {
            const a = "PointsMaterial:" + i.uuid;
            let c = this.cache.get(a);
            c || (c = new qr, Kt.prototype.copy.call(c, i), c.color.copy(i.color), c.map = i.map, c.sizeAttenuation = !1, this.cache.add(a, c)), i = c
        } else if (e.isLine) {
            const a = "LineBasicMaterial:" + i.uuid;
            let c = this.cache.get(a);
            c || (c = new $r, Kt.prototype.copy.call(c, i), c.color.copy(i.color), c.map = i.map, this.cache.add(a, c)), i = c
        }
        if (n || r || o) {
            let a = "ClonedMaterial:" + i.uuid + ":";
            n && (a += "derivative-tangents:"), r && (a += "vertex-colors:"), o && (a += "flat-shading:");
            let c = this.cache.get(a);
            c || (c = i.clone(), r && (c.vertexColors = !0), o && (c.flatShading = !0), n && (c.normalScale && (c.normalScale.y *= -1), c.clearcoatNormalScale && (c.clearcoatNormalScale.y *= -1)), this.cache.add(a, c), this.associations.set(c, this.associations.get(i))), i = c
        }
        e.material = i
    }
    getMaterialType() {
        return Jn
    }
    loadMaterial(e) {
        const t = this,
            i = this.json,
            n = this.extensions,
            r = i.materials[e];
        let o;
        const a = {},
            c = r.extensions || {},
            l = [];
        if (c[k.KHR_MATERIALS_UNLIT]) {
            const f = n[k.KHR_MATERIALS_UNLIT];
            o = f.getMaterialType(), l.push(f.extendParams(a, r, t))
        } else {
            const f = r.pbrMetallicRoughness || {};
            if (a.color = new ve(1, 1, 1), a.opacity = 1, Array.isArray(f.baseColorFactor)) {
                const p = f.baseColorFactor;
                a.color.setRGB(p[0], p[1], p[2], Ge), a.opacity = p[3]
            }
            f.baseColorTexture !== void 0 && l.push(t.assignTexture(a, "map", f.baseColorTexture, rt)), a.metalness = f.metallicFactor !== void 0 ? f.metallicFactor : 1, a.roughness = f.roughnessFactor !== void 0 ? f.roughnessFactor : 1, f.metallicRoughnessTexture !== void 0 && (l.push(t.assignTexture(a, "metalnessMap", f.metallicRoughnessTexture)), l.push(t.assignTexture(a, "roughnessMap", f.metallicRoughnessTexture))), o = this._invokeOne(function(p) {
                return p.getMaterialType && p.getMaterialType(e)
            }), l.push(Promise.all(this._invokeAll(function(p) {
                return p.extendMaterialParams && p.extendMaterialParams(e, a)
            })))
        }
        r.doubleSided === !0 && (a.side = Nt);
        const u = r.alphaMode || ws.OPAQUE;
        if (u === ws.BLEND ? (a.transparent = !0, a.depthWrite = !1) : (a.transparent = !1, u === ws.MASK && (a.alphaTest = r.alphaCutoff !== void 0 ? r.alphaCutoff : .5)), r.normalTexture !== void 0 && o !== kt && (l.push(t.assignTexture(a, "normalMap", r.normalTexture)), a.normalScale = new Z(1, 1), r.normalTexture.scale !== void 0)) {
            const f = r.normalTexture.scale;
            a.normalScale.set(f, f)
        }
        if (r.occlusionTexture !== void 0 && o !== kt && (l.push(t.assignTexture(a, "aoMap", r.occlusionTexture)), r.occlusionTexture.strength !== void 0 && (a.aoMapIntensity = r.occlusionTexture.strength)), r.emissiveFactor !== void 0 && o !== kt) {
            const f = r.emissiveFactor;
            a.emissive = new ve().setRGB(f[0], f[1], f[2], Ge)
        }
        return r.emissiveTexture !== void 0 && o !== kt && l.push(t.assignTexture(a, "emissiveMap", r.emissiveTexture, rt)), Promise.all(l).then(function() {
            const f = new o(a);
            return r.name && (f.name = r.name), we(f, r), t.associations.set(f, {
                materials: e
            }), r.extensions && tt(n, f, r), f
        })
    }
    createUniqueName(e) {
        const t = eo.sanitizeNodeName(e || "");
        return t in this.nodeNamesUsed ? t + "_" + ++this.nodeNamesUsed[t] : (this.nodeNamesUsed[t] = 0, t)
    }
    loadGeometries(e) {
        const t = this,
            i = this.extensions,
            n = this.primitiveCache;

        function r(a) {
            return i[k.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(a, t).then(function(c) {
                return dn(c, a, t)
            })
        }
        const o = [];
        for (let a = 0, c = e.length; a < c; a++) {
            const l = e[a],
                u = ca(l),
                f = n[u];
            if (f) o.push(f.promise);
            else {
                let p;
                l.extensions && l.extensions[k.KHR_DRACO_MESH_COMPRESSION] ? p = r(l) : p = dn(new mi, l, t), n[u] = {
                    primitive: l,
                    promise: p
                }, o.push(p)
            }
        }
        return Promise.all(o)
    }
    loadMesh(e) {
        const t = this,
            i = this.json,
            n = this.extensions,
            r = i.meshes[e],
            o = r.primitives,
            a = [];
        for (let c = 0, l = o.length; c < l; c++) {
            const u = o[c].material === void 0 ? ra(this.cache) : this.getDependency("material", o[c].material);
            a.push(u)
        }
        return a.push(t.loadGeometries(o)), Promise.all(a).then(function(c) {
            const l = c.slice(0, c.length - 1),
                u = c[c.length - 1],
                f = [];
            for (let A = 0, v = u.length; A < v; A++) {
                const _ = u[A],
                    T = o[A];
                let g;
                const B = l[A];
                if (T.mode === Ae.TRIANGLES || T.mode === Ae.TRIANGLE_STRIP || T.mode === Ae.TRIANGLE_FAN || T.mode === void 0) g = r.isSkinnedMesh === !0 ? new to(_, B) : new Kn(_, B), g.isSkinnedMesh === !0 && g.normalizeSkinWeights(), T.mode === Ae.TRIANGLE_STRIP ? g.geometry = an(g.geometry, Gn) : T.mode === Ae.TRIANGLE_FAN && (g.geometry = an(g.geometry, oi));
                else if (T.mode === Ae.LINES) g = new so(_, B);
                else if (T.mode === Ae.LINE_STRIP) g = new io(_, B);
                else if (T.mode === Ae.LINE_LOOP) g = new no(_, B);
                else if (T.mode === Ae.POINTS) g = new ro(_, B);
                else throw new Error("THREE.GLTFLoader: Primitive mode unsupported: " + T.mode);
                Object.keys(g.geometry.morphAttributes).length > 0 && aa(g, r), g.name = t.createUniqueName(r.name || "mesh_" + e), we(g, r), T.extensions && tt(n, g, T), t.assignFinalMaterial(g), f.push(g)
            }
            for (let A = 0, v = f.length; A < v; A++) t.associations.set(f[A], {
                meshes: e,
                primitives: A
            });
            if (f.length === 1) return r.extensions && tt(n, f[0], r), f[0];
            const p = new Fs;
            r.extensions && tt(n, p, r), t.associations.set(p, {
                meshes: e
            });
            for (let A = 0, v = f.length; A < v; A++) p.add(f[A]);
            return p
        })
    }
    loadCamera(e) {
        let t;
        const i = this.json.cameras[e],
            n = i[i.type];
        if (!n) {
            console.warn("THREE.GLTFLoader: Missing camera parameters.");
            return
        }
        return i.type === "perspective" ? t = new zn(Ai.radToDeg(n.yfov), n.aspectRatio || 1, n.znear || 1, n.zfar || 2e6) : i.type === "orthographic" && (t = new Yn(-n.xmag, n.xmag, n.ymag, -n.ymag, n.znear, n.zfar)), i.name && (t.name = this.createUniqueName(i.name)), we(t, i), Promise.resolve(t)
    }
    loadSkin(e) {
        const t = this.json.skins[e],
            i = [];
        for (let n = 0, r = t.joints.length; n < r; n++) i.push(this._loadNodeShallow(t.joints[n]));
        return t.inverseBindMatrices !== void 0 ? i.push(this.getDependency("accessor", t.inverseBindMatrices)) : i.push(null), Promise.all(i).then(function(n) {
            const r = n.pop(),
                o = n,
                a = [],
                c = [];
            for (let l = 0, u = o.length; l < u; l++) {
                const f = o[l];
                if (f) {
                    a.push(f);
                    const p = new zt;
                    r !== null && p.fromArray(r.array, l * 16), c.push(p)
                } else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.', t.joints[l])
            }
            return new oo(a, c)
        })
    }
    loadAnimation(e) {
        const t = this.json,
            i = this,
            n = t.animations[e],
            r = n.name ? n.name : "animation_" + e,
            o = [],
            a = [],
            c = [],
            l = [],
            u = [];
        for (let f = 0, p = n.channels.length; f < p; f++) {
            const A = n.channels[f],
                v = n.samplers[A.sampler],
                _ = A.target,
                T = _.node,
                g = n.parameters !== void 0 ? n.parameters[v.input] : v.input,
                B = n.parameters !== void 0 ? n.parameters[v.output] : v.output;
            _.node !== void 0 && (o.push(this.getDependency("node", T)), a.push(this.getDependency("accessor", g)), c.push(this.getDependency("accessor", B)), l.push(v), u.push(_))
        }
        return Promise.all([Promise.all(o), Promise.all(a), Promise.all(c), Promise.all(l), Promise.all(u)]).then(function(f) {
            const p = f[0],
                A = f[1],
                v = f[2],
                _ = f[3],
                T = f[4],
                g = [];
            for (let B = 0, y = p.length; B < y; B++) {
                const b = p[B],
                    S = A[B],
                    R = v[B],
                    D = _[B],
                    F = T[B];
                if (b === void 0) continue;
                b.updateMatrix && b.updateMatrix();
                const w = i._createAnimationTracks(b, S, R, D, F);
                if (w)
                    for (let z = 0; z < w.length; z++) g.push(w[z])
            }
            return new ao(r, void 0, g)
        })
    }
    createNodeMesh(e) {
        const t = this.json,
            i = this,
            n = t.nodes[e];
        return n.mesh === void 0 ? null : i.getDependency("mesh", n.mesh).then(function(r) {
            const o = i._getNodeRef(i.meshCache, n.mesh, r);
            return n.weights !== void 0 && o.traverse(function(a) {
                if (a.isMesh)
                    for (let c = 0, l = n.weights.length; c < l; c++) a.morphTargetInfluences[c] = n.weights[c]
            }), o
        })
    }
    loadNode(e) {
        const t = this.json,
            i = this,
            n = t.nodes[e],
            r = i._loadNodeShallow(e),
            o = [],
            a = n.children || [];
        for (let l = 0, u = a.length; l < u; l++) o.push(i.getDependency("node", a[l]));
        const c = n.skin === void 0 ? Promise.resolve(null) : i.getDependency("skin", n.skin);
        return Promise.all([r, Promise.all(o), c]).then(function(l) {
            const u = l[0],
                f = l[1],
                p = l[2];
            p !== null && u.traverse(function(A) {
                A.isSkinnedMesh && A.bind(p, ha)
            });
            for (let A = 0, v = f.length; A < v; A++) u.add(f[A]);
            return u
        })
    }
    _loadNodeShallow(e) {
        const t = this.json,
            i = this.extensions,
            n = this;
        if (this.nodeCache[e] !== void 0) return this.nodeCache[e];
        const r = t.nodes[e],
            o = r.name ? n.createUniqueName(r.name) : "",
            a = [],
            c = n._invokeOne(function(l) {
                return l.createNodeMesh && l.createNodeMesh(e)
            });
        return c && a.push(c), r.camera !== void 0 && a.push(n.getDependency("camera", r.camera).then(function(l) {
            return n._getNodeRef(n.cameraCache, r.camera, l)
        })), n._invokeAll(function(l) {
            return l.createNodeAttachment && l.createNodeAttachment(e)
        }).forEach(function(l) {
            a.push(l)
        }), this.nodeCache[e] = Promise.all(a).then(function(l) {
            let u;
            if (r.isBone === !0 ? u = new co : l.length > 1 ? u = new Fs : l.length === 1 ? u = l[0] : u = new Nn, u !== l[0])
                for (let f = 0, p = l.length; f < p; f++) u.add(l[f]);
            if (r.name && (u.userData.name = r.name, u.name = o), we(u, r), r.extensions && tt(i, u, r), r.matrix !== void 0) {
                const f = new zt;
                f.fromArray(r.matrix), u.applyMatrix4(f)
            } else r.translation !== void 0 && u.position.fromArray(r.translation), r.rotation !== void 0 && u.quaternion.fromArray(r.rotation), r.scale !== void 0 && u.scale.fromArray(r.scale);
            return n.associations.has(u) || n.associations.set(u, {}), n.associations.get(u).nodes = e, u
        }), this.nodeCache[e]
    }
    loadScene(e) {
        const t = this.extensions,
            i = this.json.scenes[e],
            n = this,
            r = new Fs;
        i.name && (r.name = n.createUniqueName(i.name)), we(r, i), i.extensions && tt(t, r, i);
        const o = i.nodes || [],
            a = [];
        for (let c = 0, l = o.length; c < l; c++) a.push(n.getDependency("node", o[c]));
        return Promise.all(a).then(function(c) {
            for (let u = 0, f = c.length; u < f; u++) r.add(c[u]);
            const l = u => {
                const f = new Map;
                for (const [p, A] of n.associations)(p instanceof Kt || p instanceof at) && f.set(p, A);
                return u.traverse(p => {
                    const A = n.associations.get(p);
                    A != null && f.set(p, A)
                }), f
            };
            return n.associations = l(r), r
        })
    }
    _createAnimationTracks(e, t, i, n, r) {
        const o = [],
            a = e.name ? e.name : e.uuid,
            c = [];
        Ke[r.path] === Ke.weights ? e.traverse(function(p) {
            p.morphTargetInfluences && c.push(p.name ? p.name : p.uuid)
        }) : c.push(a);
        let l;
        switch (Ke[r.path]) {
            case Ke.weights:
                l = Yi;
                break;
            case Ke.rotation:
                l = Xi;
                break;
            case Ke.position:
            case Ke.scale:
                l = zi;
                break;
            default:
                i.itemSize === 1 ? l = Yi : l = zi;
                break
        }
        const u = n.interpolation !== void 0 ? na[n.interpolation] : Xn,
            f = this._getArrayFromAccessor(i);
        for (let p = 0, A = c.length; p < A; p++) {
            const v = new l(c[p] + "." + Ke[r.path], t.array, f, u);
            n.interpolation === "CUBICSPLINE" && this._createCubicSplineTrackInterpolant(v), o.push(v)
        }
        return o
    }
    _getArrayFromAccessor(e) {
        let t = e.array;
        if (e.normalized) {
            const i = hi(t.constructor),
                n = new Float32Array(t.length);
            for (let r = 0, o = t.length; r < o; r++) n[r] = t[r] * i;
            t = n
        }
        return t
    }
    _createCubicSplineTrackInterpolant(e) {
        e.createInterpolant = function(i) {
            const n = this instanceof Xi ? ia : tr;
            return new n(this.times, this.values, this.getValueSize() / 3, i)
        }, e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline = !0
    }
}

function da(s, e, t) {
    const i = e.attributes,
        n = new Qn;
    if (i.POSITION !== void 0) {
        const a = t.json.accessors[i.POSITION],
            c = a.min,
            l = a.max;
        if (c !== void 0 && l !== void 0) {
            if (n.set(new Pe(c[0], c[1], c[2]), new Pe(l[0], l[1], l[2])), a.normalized) {
                const u = hi(Bt[a.componentType]);
                n.min.multiplyScalar(u), n.max.multiplyScalar(u)
            }
        } else {
            console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");
            return
        }
    } else return;
    const r = e.targets;
    if (r !== void 0) {
        const a = new Pe,
            c = new Pe;
        for (let l = 0, u = r.length; l < u; l++) {
            const f = r[l];
            if (f.POSITION !== void 0) {
                const p = t.json.accessors[f.POSITION],
                    A = p.min,
                    v = p.max;
                if (A !== void 0 && v !== void 0) {
                    if (c.setX(Math.max(Math.abs(A[0]), Math.abs(v[0]))), c.setY(Math.max(Math.abs(A[1]), Math.abs(v[1]))), c.setZ(Math.max(Math.abs(A[2]), Math.abs(v[2]))), p.normalized) {
                        const _ = hi(Bt[p.componentType]);
                        c.multiplyScalar(_)
                    }
                    a.max(c)
                } else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")
            }
        }
        n.expandByVector(a)
    }
    s.boundingBox = n;
    const o = new Vn;
    n.getCenter(o.center), o.radius = n.min.distanceTo(n.max) / 2, s.boundingSphere = o
}

function dn(s, e, t) {
    const i = e.attributes,
        n = [];

    function r(o, a) {
        return t.getDependency("accessor", o).then(function(c) {
            s.setAttribute(a, c)
        })
    }
    for (const o in i) {
        const a = li[o] || o.toLowerCase();
        a in s.attributes || n.push(r(i[o], a))
    }
    if (e.indices !== void 0 && !s.index) {
        const o = t.getDependency("accessor", e.indices).then(function(a) {
            s.setIndex(a)
        });
        n.push(o)
    }
    return we(s, e), da(s, e, t), Promise.all(n).then(function() {
        return e.targets !== void 0 ? oa(s, e.targets, t) : s
    })
}
const Gs = new WeakMap;
class fa extends Hn {
    constructor(e) {
        super(e), this.decoderPath = "", this.decoderConfig = {}, this.decoderBinary = null, this.decoderPending = null, this.workerLimit = 4, this.workerPool = [], this.workerNextTaskID = 1, this.workerSourceURL = "", this.defaultAttributeIDs = {
            position: "POSITION",
            normal: "NORMAL",
            color: "COLOR",
            uv: "TEX_COORD"
        }, this.defaultAttributeTypes = {
            position: "Float32Array",
            normal: "Float32Array",
            color: "Float32Array",
            uv: "Float32Array"
        }
    }
    setDecoderPath(e) {
        return this.decoderPath = e, this
    }
    setDecoderConfig(e) {
        return this.decoderConfig = e, this
    }
    setWorkerLimit(e) {
        return this.workerLimit = e, this
    }
    load(e, t, i, n) {
        const r = new ms(this.manager);
        r.setPath(this.path), r.setResponseType("arraybuffer"), r.setRequestHeader(this.requestHeader), r.setWithCredentials(this.withCredentials), r.load(e, o => {
            const a = {
                attributeIDs: this.defaultAttributeIDs,
                attributeTypes: this.defaultAttributeTypes,
                useUniqueIDs: !1
            };
            this.decodeGeometry(o, a).then(t).catch(n)
        }, i, n)
    }
    decodeDracoFile(e, t, i, n) {
        const r = {
            attributeIDs: i || this.defaultAttributeIDs,
            attributeTypes: n || this.defaultAttributeTypes,
            useUniqueIDs: !!i
        };
        this.decodeGeometry(e, r).then(t)
    }
    decodeGeometry(e, t) {
        for (const c in t.attributeTypes) {
            const l = t.attributeTypes[c];
            l.BYTES_PER_ELEMENT !== void 0 && (t.attributeTypes[c] = l.name)
        }
        const i = JSON.stringify(t);
        if (Gs.has(e)) {
            const c = Gs.get(e);
            if (c.key === i) return c.promise;
            if (e.byteLength === 0) throw new Error("THREE.DRACOLoader: Unable to re-decode a buffer with different settings. Buffer has already been transferred.")
        }
        let n;
        const r = this.workerNextTaskID++,
            o = e.byteLength,
            a = this._getWorker(r, o).then(c => (n = c, new Promise((l, u) => {
                n._callbacks[r] = {
                    resolve: l,
                    reject: u
                }, n.postMessage({
                    type: "decode",
                    id: r,
                    taskConfig: t,
                    buffer: e
                }, [e])
            }))).then(c => this._createGeometry(c.geometry));
        return a.catch(() => !0).then(() => {
            n && r && this._releaseTask(n, r)
        }), Gs.set(e, {
            key: i,
            promise: a
        }), a
    }
    _createGeometry(e) {
        const t = new mi;
        e.index && t.setIndex(new ot(e.index.array, 1));
        for (let i = 0; i < e.attributes.length; i++) {
            const n = e.attributes[i],
                r = n.name,
                o = n.array,
                a = n.itemSize;
            t.setAttribute(r, new ot(o, a))
        }
        return t
    }
    _loadLibrary(e, t) {
        const i = new ms(this.manager);
        return i.setPath(this.decoderPath), i.setResponseType(t), i.setWithCredentials(this.withCredentials), new Promise((n, r) => {
            i.load(e, n, void 0, r)
        })
    }
    preload() {
        return this._initDecoder(), this
    }
    _initDecoder() {
        if (this.decoderPending) return this.decoderPending;
        const e = typeof WebAssembly != "object" || this.decoderConfig.type === "js",
            t = [];
        return e ? t.push(this._loadLibrary("draco_decoder.js", "text")) : (t.push(this._loadLibrary("draco_wasm_wrapper.js", "text")), t.push(this._loadLibrary("draco_decoder.wasm", "arraybuffer"))), this.decoderPending = Promise.all(t).then(i => {
            const n = i[0];
            e || (this.decoderConfig.wasmBinary = i[1]);
            const r = pa.toString(),
                o = ["/* draco decoder */", n, "", "/* worker */", r.substring(r.indexOf("{") + 1, r.lastIndexOf("}"))].join(`
`);
            this.workerSourceURL = URL.createObjectURL(new Blob([o]))
        }), this.decoderPending
    }
    _getWorker(e, t) {
        return this._initDecoder().then(() => {
            if (this.workerPool.length < this.workerLimit) {
                const n = new Worker(this.workerSourceURL);
                n._callbacks = {}, n._taskCosts = {}, n._taskLoad = 0, n.postMessage({
                    type: "init",
                    decoderConfig: this.decoderConfig
                }), n.onmessage = function(r) {
                    const o = r.data;
                    switch (o.type) {
                        case "decode":
                            n._callbacks[o.id].resolve(o);
                            break;
                        case "error":
                            n._callbacks[o.id].reject(o);
                            break;
                        default:
                            console.error('THREE.DRACOLoader: Unexpected message, "' + o.type + '"')
                    }
                }, this.workerPool.push(n)
            } else this.workerPool.sort(function(n, r) {
                return n._taskLoad > r._taskLoad ? -1 : 1
            });
            const i = this.workerPool[this.workerPool.length - 1];
            return i._taskCosts[e] = t, i._taskLoad += t, i
        })
    }
    _releaseTask(e, t) {
        e._taskLoad -= e._taskCosts[t], delete e._callbacks[t], delete e._taskCosts[t]
    }
    debug() {
        console.log("Task load: ", this.workerPool.map(e => e._taskLoad))
    }
    dispose() {
        for (let e = 0; e < this.workerPool.length; ++e) this.workerPool[e].terminate();
        return this.workerPool.length = 0, this
    }
}

function pa() {
    let s, e;
    onmessage = function(o) {
        const a = o.data;
        switch (a.type) {
            case "init":
                s = a.decoderConfig, e = new Promise(function(u) {
                    s.onModuleLoaded = function(f) {
                        u({
                            draco: f
                        })
                    }, DracoDecoderModule(s)
                });
                break;
            case "decode":
                const c = a.buffer,
                    l = a.taskConfig;
                e.then(u => {
                    const f = u.draco,
                        p = new f.Decoder,
                        A = new f.DecoderBuffer;
                    A.Init(new Int8Array(c), c.byteLength);
                    try {
                        const v = t(f, p, A, l),
                            _ = v.attributes.map(T => T.array.buffer);
                        v.index && _.push(v.index.array.buffer), self.postMessage({
                            type: "decode",
                            id: a.id,
                            geometry: v
                        }, _)
                    } catch (v) {
                        console.error(v), self.postMessage({
                            type: "error",
                            id: a.id,
                            error: v.message
                        })
                    } finally {
                        f.destroy(A), f.destroy(p)
                    }
                });
                break
        }
    };

    function t(o, a, c, l) {
        const u = l.attributeIDs,
            f = l.attributeTypes;
        let p, A;
        const v = a.GetEncodedGeometryType(c);
        if (v === o.TRIANGULAR_MESH) p = new o.Mesh, A = a.DecodeBufferToMesh(c, p);
        else if (v === o.POINT_CLOUD) p = new o.PointCloud, A = a.DecodeBufferToPointCloud(c, p);
        else throw new Error("THREE.DRACOLoader: Unexpected geometry type.");
        if (!A.ok() || p.ptr === 0) throw new Error("THREE.DRACOLoader: Decoding failed: " + A.error_msg());
        const _ = {
            index: null,
            attributes: []
        };
        for (const T in u) {
            const g = self[f[T]];
            let B, y;
            if (l.useUniqueIDs) y = u[T], B = a.GetAttributeByUniqueId(p, y);
            else {
                if (y = a.GetAttributeId(p, o[u[T]]), y === -1) continue;
                B = a.GetAttribute(p, y)
            }
            _.attributes.push(n(o, a, p, T, g, B))
        }
        return v === o.TRIANGULAR_MESH && (_.index = i(o, a, p)), o.destroy(p), _
    }

    function i(o, a, c) {
        const u = c.num_faces() * 3,
            f = u * 4,
            p = o._malloc(f);
        a.GetTrianglesUInt32Array(c, f, p);
        const A = new Uint32Array(o.HEAPF32.buffer, p, u).slice();
        return o._free(p), {
            array: A,
            itemSize: 1
        }
    }

    function n(o, a, c, l, u, f) {
        const p = f.num_components(),
            v = c.num_points() * p,
            _ = v * u.BYTES_PER_ELEMENT,
            T = r(o, u),
            g = o._malloc(_);
        a.GetAttributeDataArrayForAllPoints(c, f, T, _, g);
        const B = new u(o.HEAPF32.buffer, g, v).slice();
        return o._free(g), {
            name: l,
            array: B,
            itemSize: p
        }
    }

    function r(o, a) {
        switch (a) {
            case Float32Array:
                return o.DT_FLOAT32;
            case Int8Array:
                return o.DT_INT8;
            case Int16Array:
                return o.DT_INT16;
            case Int32Array:
                return o.DT_INT32;
            case Uint8Array:
                return o.DT_UINT8;
            case Uint16Array:
                return o.DT_UINT16;
            case Uint32Array:
                return o.DT_UINT32
        }
    }
}
let rs;
const Hs = () => {
        if (rs) return rs;
        const s = "B9h9z9tFBBBF8fL9gBB9gLaaaaaFa9gEaaaB9gFaFa9gEaaaFaEMcBFFFGGGEIIILF9wFFFLEFBFKNFaFCx/IFMO/LFVK9tv9t9vq95GBt9f9f939h9z9t9f9j9h9s9s9f9jW9vq9zBBp9tv9z9o9v9wW9f9kv9j9v9kv9WvqWv94h919m9mvqBF8Z9tv9z9o9v9wW9f9kv9j9v9kv9J9u9kv94h919m9mvqBGy9tv9z9o9v9wW9f9kv9j9v9kv9J9u9kv949TvZ91v9u9jvBEn9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9P9jWBIi9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9R919hWBLn9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9F949wBKI9z9iqlBOc+x8ycGBM/qQFTa8jUUUUBCU/EBlHL8kUUUUBC9+RKGXAGCFJAI9LQBCaRKAE2BBC+gF9HQBALAEAIJHOAGlAGTkUUUBRNCUoBAG9uC/wgBZHKCUGAKCUG9JyRVAECFJRICBRcGXEXAcAF9PQFAVAFAclAcAVJAF9JyRMGXGXAG9FQBAMCbJHKC9wZRSAKCIrCEJCGrRQANCUGJRfCBRbAIRTEXGXAOATlAQ9PQBCBRISEMATAQJRIGXAS9FQBCBRtCBREEXGXAOAIlCi9PQBCBRISLMANCU/CBJAEJRKGXGXGXGXGXATAECKrJ2BBAtCKZrCEZfIBFGEBMAKhB83EBAKCNJhB83EBSEMAKAI2BIAI2BBHmCKrHYAYCE6HYy86BBAKCFJAICIJAYJHY2BBAmCIrCEZHPAPCE6HPy86BBAKCGJAYAPJHY2BBAmCGrCEZHPAPCE6HPy86BBAKCEJAYAPJHY2BBAmCEZHmAmCE6Hmy86BBAKCIJAYAmJHY2BBAI2BFHmCKrHPAPCE6HPy86BBAKCLJAYAPJHY2BBAmCIrCEZHPAPCE6HPy86BBAKCKJAYAPJHY2BBAmCGrCEZHPAPCE6HPy86BBAKCOJAYAPJHY2BBAmCEZHmAmCE6Hmy86BBAKCNJAYAmJHY2BBAI2BGHmCKrHPAPCE6HPy86BBAKCVJAYAPJHY2BBAmCIrCEZHPAPCE6HPy86BBAKCcJAYAPJHY2BBAmCGrCEZHPAPCE6HPy86BBAKCMJAYAPJHY2BBAmCEZHmAmCE6Hmy86BBAKCSJAYAmJHm2BBAI2BEHICKrHYAYCE6HYy86BBAKCQJAmAYJHm2BBAICIrCEZHYAYCE6HYy86BBAKCfJAmAYJHm2BBAICGrCEZHYAYCE6HYy86BBAKCbJAmAYJHK2BBAICEZHIAICE6HIy86BBAKAIJRISGMAKAI2BNAI2BBHmCIrHYAYCb6HYy86BBAKCFJAICNJAYJHY2BBAmCbZHmAmCb6Hmy86BBAKCGJAYAmJHm2BBAI2BFHYCIrHPAPCb6HPy86BBAKCEJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCIJAmAYJHm2BBAI2BGHYCIrHPAPCb6HPy86BBAKCLJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCKJAmAYJHm2BBAI2BEHYCIrHPAPCb6HPy86BBAKCOJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCNJAmAYJHm2BBAI2BIHYCIrHPAPCb6HPy86BBAKCVJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCcJAmAYJHm2BBAI2BLHYCIrHPAPCb6HPy86BBAKCMJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCSJAmAYJHm2BBAI2BKHYCIrHPAPCb6HPy86BBAKCQJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCfJAmAYJHm2BBAI2BOHICIrHYAYCb6HYy86BBAKCbJAmAYJHK2BBAICbZHIAICb6HIy86BBAKAIJRISFMAKAI8pBB83BBAKCNJAICNJ8pBB83BBAICTJRIMAtCGJRtAECTJHEAS9JQBMMGXAIQBCBRISEMGXAM9FQBANAbJ2BBRtCBRKAfREEXAEANCU/CBJAKJ2BBHTCFrCBATCFZl9zAtJHt86BBAEAGJREAKCFJHKAM9HQBMMAfCFJRfAIRTAbCFJHbAG9HQBMMABAcAG9sJANCUGJAMAG9sTkUUUBpANANCUGJAMCaJAG9sJAGTkUUUBpMAMCBAIyAcJRcAIQBMC9+RKSFMCBC99AOAIlAGCAAGCA9Ly6yRKMALCU/EBJ8kUUUUBAKM+OmFTa8jUUUUBCoFlHL8kUUUUBC9+RKGXAFCE9uHOCtJAI9LQBCaRKAE2BBHNC/wFZC/gF9HQBANCbZHVCF9LQBALCoBJCgFCUFT+JUUUBpALC84Jha83EBALC8wJha83EBALC8oJha83EBALCAJha83EBALCiJha83EBALCTJha83EBALha83ENALha83EBAEAIJC9wJRcAECFJHNAOJRMGXAF9FQBCQCbAVCF6yRSABRECBRVCBRQCBRfCBRICBRKEXGXAMAcuQBC9+RKSEMGXGXAN2BBHOC/vF9LQBALCoBJAOCIrCa9zAKJCbZCEWJHb8oGIRTAb8oGBRtGXAOCbZHbAS9PQBALAOCa9zAIJCbZCGWJ8oGBAVAbyROAb9FRbGXGXAGCG9HQBABAt87FBABCIJAO87FBABCGJAT87FBSFMAEAtjGBAECNJAOjGBAECIJATjGBMAVAbJRVALCoBJAKCEWJHmAOjGBAmATjGIALAICGWJAOjGBALCoBJAKCFJCbZHKCEWJHTAtjGBATAOjGIAIAbJRIAKCFJRKSGMGXGXAbCb6QBAQAbJAbC989zJCFJRQSFMAM1BBHbCgFZROGXGXAbCa9MQBAMCFJRMSFMAM1BFHbCgBZCOWAOCgBZqROGXAbCa9MQBAMCGJRMSFMAM1BGHbCgBZCfWAOqROGXAbCa9MQBAMCEJRMSFMAM1BEHbCgBZCdWAOqROGXAbCa9MQBAMCIJRMSFMAM2BIC8cWAOqROAMCLJRMMAOCFrCBAOCFZl9zAQJRQMGXGXAGCG9HQBABAt87FBABCIJAQ87FBABCGJAT87FBSFMAEAtjGBAECNJAQjGBAECIJATjGBMALCoBJAKCEWJHOAQjGBAOATjGIALAICGWJAQjGBALCoBJAKCFJCbZHKCEWJHOAtjGBAOAQjGIAICFJRIAKCFJRKSFMGXAOCDF9LQBALAIAcAOCbZJ2BBHbCIrHTlCbZCGWJ8oGBAVCFJHtATyROALAIAblCbZCGWJ8oGBAtAT9FHmJHtAbCbZHTyRbAT9FRTGXGXAGCG9HQBABAV87FBABCIJAb87FBABCGJAO87FBSFMAEAVjGBAECNJAbjGBAECIJAOjGBMALAICGWJAVjGBALCoBJAKCEWJHYAOjGBAYAVjGIALAICFJHICbZCGWJAOjGBALCoBJAKCFJCbZCEWJHYAbjGBAYAOjGIALAIAmJCbZHICGWJAbjGBALCoBJAKCGJCbZHKCEWJHOAVjGBAOAbjGIAKCFJRKAIATJRIAtATJRVSFMAVCBAM2BBHYyHTAOC/+F6HPJROAYCbZRtGXGXAYCIrHmQBAOCFJRbSFMAORbALAIAmlCbZCGWJ8oGBROMGXGXAtQBAbCFJRVSFMAbRVALAIAYlCbZCGWJ8oGBRbMGXGXAP9FQBAMCFJRYSFMAM1BFHYCgFZRTGXGXAYCa9MQBAMCGJRYSFMAM1BGHYCgBZCOWATCgBZqRTGXAYCa9MQBAMCEJRYSFMAM1BEHYCgBZCfWATqRTGXAYCa9MQBAMCIJRYSFMAM1BIHYCgBZCdWATqRTGXAYCa9MQBAMCLJRYSFMAMCKJRYAM2BLC8cWATqRTMATCFrCBATCFZl9zAQJHQRTMGXGXAmCb6QBAYRPSFMAY1BBHMCgFZROGXGXAMCa9MQBAYCFJRPSFMAY1BFHMCgBZCOWAOCgBZqROGXAMCa9MQBAYCGJRPSFMAY1BGHMCgBZCfWAOqROGXAMCa9MQBAYCEJRPSFMAY1BEHMCgBZCdWAOqROGXAMCa9MQBAYCIJRPSFMAYCLJRPAY2BIC8cWAOqROMAOCFrCBAOCFZl9zAQJHQROMGXGXAtCb6QBAPRMSFMAP1BBHMCgFZRbGXGXAMCa9MQBAPCFJRMSFMAP1BFHMCgBZCOWAbCgBZqRbGXAMCa9MQBAPCGJRMSFMAP1BGHMCgBZCfWAbqRbGXAMCa9MQBAPCEJRMSFMAP1BEHMCgBZCdWAbqRbGXAMCa9MQBAPCIJRMSFMAPCLJRMAP2BIC8cWAbqRbMAbCFrCBAbCFZl9zAQJHQRbMGXGXAGCG9HQBABAT87FBABCIJAb87FBABCGJAO87FBSFMAEATjGBAECNJAbjGBAECIJAOjGBMALCoBJAKCEWJHYAOjGBAYATjGIALAICGWJATjGBALCoBJAKCFJCbZCEWJHYAbjGBAYAOjGIALAICFJHICbZCGWJAOjGBALCoBJAKCGJCbZCEWJHOATjGBAOAbjGIALAIAm9FAmCb6qJHICbZCGWJAbjGBAIAt9FAtCb6qJRIAKCEJRKMANCFJRNABCKJRBAECSJREAKCbZRKAICbZRIAfCEJHfAF9JQBMMCBC99AMAc6yRKMALCoFJ8kUUUUBAKM/tIFGa8jUUUUBCTlRLC9+RKGXAFCLJAI9LQBCaRKAE2BBC/+FZC/QF9HQBALhB83ENAECFJRKAEAIJC98JREGXAF9FQBGXAGCG6QBEXGXAKAE9JQBC9+bMAK1BBHGCgFZRIGXGXAGCa9MQBAKCFJRKSFMAK1BFHGCgBZCOWAICgBZqRIGXAGCa9MQBAKCGJRKSFMAK1BGHGCgBZCfWAIqRIGXAGCa9MQBAKCEJRKSFMAK1BEHGCgBZCdWAIqRIGXAGCa9MQBAKCIJRKSFMAK2BIC8cWAIqRIAKCLJRKMALCNJAICFZCGWqHGAICGrCBAICFrCFZl9zAG8oGBJHIjGBABAIjGBABCIJRBAFCaJHFQBSGMMEXGXAKAE9JQBC9+bMAK1BBHGCgFZRIGXGXAGCa9MQBAKCFJRKSFMAK1BFHGCgBZCOWAICgBZqRIGXAGCa9MQBAKCGJRKSFMAK1BGHGCgBZCfWAIqRIGXAGCa9MQBAKCEJRKSFMAK1BEHGCgBZCdWAIqRIGXAGCa9MQBAKCIJRKSFMAK2BIC8cWAIqRIAKCLJRKMABAICGrCBAICFrCFZl9zALCNJAICFZCGWqHI8oGBJHG87FBAIAGjGBABCGJRBAFCaJHFQBMMCBC99AKAE6yRKMAKM+lLKFaF99GaG99FaG99GXGXAGCI9HQBAF9FQFEXGXGX9DBBB8/9DBBB+/ABCGJHG1BB+yAB1BBHE+yHI+L+TABCFJHL1BBHK+yHO+L+THN9DBBBB9gHVyAN9DBB/+hANAN+U9DBBBBANAVyHcAc+MHMAECa3yAI+SHIAI+UAcAMAKCa3yAO+SHcAc+U+S+S+R+VHO+U+SHN+L9DBBB9P9d9FQBAN+oRESFMCUUUU94REMAGAE86BBGXGX9DBBB8/9DBBB+/Ac9DBBBB9gyAcAO+U+SHN+L9DBBB9P9d9FQBAN+oRGSFMCUUUU94RGMALAG86BBGXGX9DBBB8/9DBBB+/AI9DBBBB9gyAIAO+U+SHN+L9DBBB9P9d9FQBAN+oRGSFMCUUUU94RGMABAG86BBABCIJRBAFCaJHFQBSGMMAF9FQBEXGXGX9DBBB8/9DBBB+/ABCIJHG8uFB+yAB8uFBHE+yHI+L+TABCGJHL8uFBHK+yHO+L+THN9DBBBB9gHVyAN9DB/+g6ANAN+U9DBBBBANAVyHcAc+MHMAECa3yAI+SHIAI+UAcAMAKCa3yAO+SHcAc+U+S+S+R+VHO+U+SHN+L9DBBB9P9d9FQBAN+oRESFMCUUUU94REMAGAE87FBGXGX9DBBB8/9DBBB+/Ac9DBBBB9gyAcAO+U+SHN+L9DBBB9P9d9FQBAN+oRGSFMCUUUU94RGMALAG87FBGXGX9DBBB8/9DBBB+/AI9DBBBB9gyAIAO+U+SHN+L9DBBB9P9d9FQBAN+oRGSFMCUUUU94RGMABAG87FBABCNJRBAFCaJHFQBMMM/SEIEaE99EaF99GXAF9FQBCBREABRIEXGXGX9D/zI818/AICKJ8uFBHLCEq+y+VHKAI8uFB+y+UHO9DB/+g6+U9DBBB8/9DBBB+/AO9DBBBB9gy+SHN+L9DBBB9P9d9FQBAN+oRVSFMCUUUU94RVMAICIJ8uFBRcAICGJ8uFBRMABALCFJCEZAEqCFWJAV87FBGXGXAKAM+y+UHN9DB/+g6+U9DBBB8/9DBBB+/AN9DBBBB9gy+SHS+L9DBBB9P9d9FQBAS+oRMSFMCUUUU94RMMABALCGJCEZAEqCFWJAM87FBGXGXAKAc+y+UHK9DB/+g6+U9DBBB8/9DBBB+/AK9DBBBB9gy+SHS+L9DBBB9P9d9FQBAS+oRcSFMCUUUU94RcMABALCaJCEZAEqCFWJAc87FBGXGX9DBBU8/AOAO+U+TANAN+U+TAKAK+U+THO9DBBBBAO9DBBBB9gy+R9DB/+g6+U9DBBB8/+SHO+L9DBBB9P9d9FQBAO+oRcSFMCUUUU94RcMABALCEZAEqCFWJAc87FBAICNJRIAECIJREAFCaJHFQBMMM9JBGXAGCGrAF9sHF9FQBEXABAB8oGBHGCNWCN91+yAGCi91CnWCUUU/8EJ+++U84GBABCIJRBAFCaJHFQBMMM9TFEaCBCB8oGUkUUBHFABCEJC98ZJHBjGUkUUBGXGXAB8/BCTWHGuQBCaREABAGlCggEJCTrXBCa6QFMAFREMAEM/lFFFaGXGXAFABqCEZ9FQBABRESFMGXGXAGCT9PQBABRESFMABREEXAEAF8oGBjGBAECIJAFCIJ8oGBjGBAECNJAFCNJ8oGBjGBAECSJAFCSJ8oGBjGBAECTJREAFCTJRFAGC9wJHGCb9LQBMMAGCI9JQBEXAEAF8oGBjGBAFCIJRFAECIJREAGC98JHGCE9LQBMMGXAG9FQBEXAEAF2BB86BBAECFJREAFCFJRFAGCaJHGQBMMABMoFFGaGXGXABCEZ9FQBABRESFMAFCgFZC+BwsN9sRIGXGXAGCT9PQBABRESFMABREEXAEAIjGBAECSJAIjGBAECNJAIjGBAECIJAIjGBAECTJREAGC9wJHGCb9LQBMMAGCI9JQBEXAEAIjGBAECIJREAGC98JHGCE9LQBMMGXAG9FQBEXAEAF86BBAECFJREAGCaJHGQBMMABMMMFBCUNMIT9kBB",
            e = "B9h9z9tFBBBFiI9gBB9gLaaaaaFa9gEaaaB9gFaFaEMcBBFBFFGGGEILF9wFFFLEFBFKNFaFCx/aFMO/LFVK9tv9t9vq95GBt9f9f939h9z9t9f9j9h9s9s9f9jW9vq9zBBp9tv9z9o9v9wW9f9kv9j9v9kv9WvqWv94h919m9mvqBG8Z9tv9z9o9v9wW9f9kv9j9v9kv9J9u9kv94h919m9mvqBIy9tv9z9o9v9wW9f9kv9j9v9kv9J9u9kv949TvZ91v9u9jvBLn9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9P9jWBKi9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9R919hWBOn9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9F949wBNI9z9iqlBVc+N9IcIBTEM9+FLa8jUUUUBCTlRBCBRFEXCBRGCBREEXABCNJAGJAECUaAFAGrCFZHIy86BBAEAIJREAGCFJHGCN9HQBMAFCx+YUUBJAE86BBAFCEWCxkUUBJAB8pEN83EBAFCFJHFCUG9HQBMMk8lLbaE97F9+FaL978jUUUUBCU/KBlHL8kUUUUBC9+RKGXAGCFJAI9LQBCaRKAE2BBC+gF9HQBALAEAIJHOAGlAG/8cBBCUoBAG9uC/wgBZHKCUGAKCUG9JyRNAECFJRKCBRVGXEXAVAF9PQFANAFAVlAVANJAF9JyRcGXGXAG9FQBAcCbJHIC9wZHMCE9sRSAMCFWRQAICIrCEJCGrRfCBRbEXAKRTCBRtGXEXGXAOATlAf9PQBCBRKSLMALCU/CBJAtAM9sJRmATAfJRKCBREGXAMCoB9JQBAOAKlC/gB9JQBCBRIEXAmAIJREGXGXGXGXGXATAICKrJ2BBHYCEZfIBFGEBMAECBDtDMIBSEMAEAKDBBIAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnHPCGD+MFAPDQBTFtGmEYIPLdKeOnC0+G+MiDtD9OHdCEDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIBAKCIJAeDeBJAiCx+YUUBJ2BBJRKSGMAEAKDBBNAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnC+P+e+8/4BDtD9OHdCbDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIBAKCNJAeDeBJAiCx+YUUBJ2BBJRKSFMAEAKDBBBDMIBAKCTJRKMGXGXGXGXGXAYCGrCEZfIBFGEBMAECBDtDMITSEMAEAKDBBIAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnHPCGD+MFAPDQBTFtGmEYIPLdKeOnC0+G+MiDtD9OHdCEDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMITAKCIJAeDeBJAiCx+YUUBJ2BBJRKSGMAEAKDBBNAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnC+P+e+8/4BDtD9OHdCbDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMITAKCNJAeDeBJAiCx+YUUBJ2BBJRKSFMAEAKDBBBDMITAKCTJRKMGXGXGXGXGXAYCIrCEZfIBFGEBMAECBDtDMIASEMAEAKDBBIAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnHPCGD+MFAPDQBTFtGmEYIPLdKeOnC0+G+MiDtD9OHdCEDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIAAKCIJAeDeBJAiCx+YUUBJ2BBJRKSGMAEAKDBBNAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnC+P+e+8/4BDtD9OHdCbDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIAAKCNJAeDeBJAiCx+YUUBJ2BBJRKSFMAEAKDBBBDMIAAKCTJRKMGXGXGXGXGXAYCKrfIBFGEBMAECBDtDMI8wSEMAEAKDBBIAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnHPCGD+MFAPDQBTFtGmEYIPLdKeOnC0+G+MiDtD9OHdCEDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHYCEWCxkUUBJDBEBAYCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHYCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMI8wAKCIJAeDeBJAYCx+YUUBJ2BBJRKSGMAEAKDBBNAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnC+P+e+8/4BDtD9OHdCbDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHYCEWCxkUUBJDBEBAYCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHYCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMI8wAKCNJAeDeBJAYCx+YUUBJ2BBJRKSFMAEAKDBBBDMI8wAKCTJRKMAICoBJREAICUFJAM9LQFAERIAOAKlC/fB9LQBMMGXAEAM9PQBAECErRIEXGXAOAKlCi9PQBCBRKSOMAmAEJRYGXGXGXGXGXATAECKrJ2BBAICKZrCEZfIBFGEBMAYCBDtDMIBSEMAYAKDBBIAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnHPCGD+MFAPDQBTFtGmEYIPLdKeOnC0+G+MiDtD9OHdCEDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIBAKCIJAeDeBJAiCx+YUUBJ2BBJRKSGMAYAKDBBNAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnC+P+e+8/4BDtD9OHdCbDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIBAKCNJAeDeBJAiCx+YUUBJ2BBJRKSFMAYAKDBBBDMIBAKCTJRKMAICGJRIAECTJHEAM9JQBMMGXAK9FQBAKRTAtCFJHtCI6QGSFMMCBRKSEMGXAM9FQBALCUGJAbJREALAbJDBGBReCBRYEXAEALCU/CBJAYJHIDBIBHdCFD9tAdCFDbHPD9OD9hD9RHdAIAMJDBIBH8ZCFD9tA8ZAPD9OD9hD9RH8ZDQBTFtGmEYIPLdKeOnHpAIAQJDBIBHyCFD9tAyAPD9OD9hD9RHyAIASJDBIBH8cCFD9tA8cAPD9OD9hD9RH8cDQBTFtGmEYIPLdKeOnH8dDQBFTtGEmYILPdKOenHPAPDQBFGEBFGEBFGEBFGEAeD9uHeDyBjGBAEAGJHIAeAPAPDQILKOILKOILKOILKOD9uHeDyBjGBAIAGJHIAeAPAPDQNVcMNVcMNVcMNVcMD9uHeDyBjGBAIAGJHIAeAPAPDQSQfbSQfbSQfbSQfbD9uHeDyBjGBAIAGJHIAeApA8dDQNVi8ZcMpySQ8c8dfb8e8fHPAPDQBFGEBFGEBFGEBFGED9uHeDyBjGBAIAGJHIAeAPAPDQILKOILKOILKOILKOD9uHeDyBjGBAIAGJHIAeAPAPDQNVcMNVcMNVcMNVcMD9uHeDyBjGBAIAGJHIAeAPAPDQSQfbSQfbSQfbSQfbD9uHeDyBjGBAIAGJHIAeAdA8ZDQNiV8ZcpMyS8cQ8df8eb8fHdAyA8cDQNiV8ZcpMyS8cQ8df8eb8fH8ZDQBFTtGEmYILPdKOenHPAPDQBFGEBFGEBFGEBFGED9uHeDyBjGBAIAGJHIAeAPAPDQILKOILKOILKOILKOD9uHeDyBjGBAIAGJHIAeAPAPDQNVcMNVcMNVcMNVcMD9uHeDyBjGBAIAGJHIAeAPAPDQSQfbSQfbSQfbSQfbD9uHeDyBjGBAIAGJHIAeAdA8ZDQNVi8ZcMpySQ8c8dfb8e8fHPAPDQBFGEBFGEBFGEBFGED9uHeDyBjGBAIAGJHIAeAPAPDQILKOILKOILKOILKOD9uHeDyBjGBAIAGJHIAeAPAPDQNVcMNVcMNVcMNVcMD9uHeDyBjGBAIAGJHIAeAPAPDQSQfbSQfbSQfbSQfbD9uHeDyBjGBAIAGJREAYCTJHYAM9JQBMMAbCIJHbAG9JQBMMABAVAG9sJALCUGJAcAG9s/8cBBALALCUGJAcCaJAG9sJAG/8cBBMAcCBAKyAVJRVAKQBMC9+RKSFMCBC99AOAKlAGCAAGCA9Ly6yRKMALCU/KBJ8kUUUUBAKMNBT+BUUUBM+KmFTa8jUUUUBCoFlHL8kUUUUBC9+RKGXAFCE9uHOCtJAI9LQBCaRKAE2BBHNC/wFZC/gF9HQBANCbZHVCF9LQBALCoBJCgFCUF/8MBALC84Jha83EBALC8wJha83EBALC8oJha83EBALCAJha83EBALCiJha83EBALCTJha83EBALha83ENALha83EBAEAIJC9wJRcAECFJHNAOJRMGXAF9FQBCQCbAVCF6yRSABRECBRVCBRQCBRfCBRICBRKEXGXAMAcuQBC9+RKSEMGXGXAN2BBHOC/vF9LQBALCoBJAOCIrCa9zAKJCbZCEWJHb8oGIRTAb8oGBRtGXAOCbZHbAS9PQBALAOCa9zAIJCbZCGWJ8oGBAVAbyROAb9FRbGXGXAGCG9HQBABAt87FBABCIJAO87FBABCGJAT87FBSFMAEAtjGBAECNJAOjGBAECIJATjGBMAVAbJRVALCoBJAKCEWJHmAOjGBAmATjGIALAICGWJAOjGBALCoBJAKCFJCbZHKCEWJHTAtjGBATAOjGIAIAbJRIAKCFJRKSGMGXGXAbCb6QBAQAbJAbC989zJCFJRQSFMAM1BBHbCgFZROGXGXAbCa9MQBAMCFJRMSFMAM1BFHbCgBZCOWAOCgBZqROGXAbCa9MQBAMCGJRMSFMAM1BGHbCgBZCfWAOqROGXAbCa9MQBAMCEJRMSFMAM1BEHbCgBZCdWAOqROGXAbCa9MQBAMCIJRMSFMAM2BIC8cWAOqROAMCLJRMMAOCFrCBAOCFZl9zAQJRQMGXGXAGCG9HQBABAt87FBABCIJAQ87FBABCGJAT87FBSFMAEAtjGBAECNJAQjGBAECIJATjGBMALCoBJAKCEWJHOAQjGBAOATjGIALAICGWJAQjGBALCoBJAKCFJCbZHKCEWJHOAtjGBAOAQjGIAICFJRIAKCFJRKSFMGXAOCDF9LQBALAIAcAOCbZJ2BBHbCIrHTlCbZCGWJ8oGBAVCFJHtATyROALAIAblCbZCGWJ8oGBAtAT9FHmJHtAbCbZHTyRbAT9FRTGXGXAGCG9HQBABAV87FBABCIJAb87FBABCGJAO87FBSFMAEAVjGBAECNJAbjGBAECIJAOjGBMALAICGWJAVjGBALCoBJAKCEWJHYAOjGBAYAVjGIALAICFJHICbZCGWJAOjGBALCoBJAKCFJCbZCEWJHYAbjGBAYAOjGIALAIAmJCbZHICGWJAbjGBALCoBJAKCGJCbZHKCEWJHOAVjGBAOAbjGIAKCFJRKAIATJRIAtATJRVSFMAVCBAM2BBHYyHTAOC/+F6HPJROAYCbZRtGXGXAYCIrHmQBAOCFJRbSFMAORbALAIAmlCbZCGWJ8oGBROMGXGXAtQBAbCFJRVSFMAbRVALAIAYlCbZCGWJ8oGBRbMGXGXAP9FQBAMCFJRYSFMAM1BFHYCgFZRTGXGXAYCa9MQBAMCGJRYSFMAM1BGHYCgBZCOWATCgBZqRTGXAYCa9MQBAMCEJRYSFMAM1BEHYCgBZCfWATqRTGXAYCa9MQBAMCIJRYSFMAM1BIHYCgBZCdWATqRTGXAYCa9MQBAMCLJRYSFMAMCKJRYAM2BLC8cWATqRTMATCFrCBATCFZl9zAQJHQRTMGXGXAmCb6QBAYRPSFMAY1BBHMCgFZROGXGXAMCa9MQBAYCFJRPSFMAY1BFHMCgBZCOWAOCgBZqROGXAMCa9MQBAYCGJRPSFMAY1BGHMCgBZCfWAOqROGXAMCa9MQBAYCEJRPSFMAY1BEHMCgBZCdWAOqROGXAMCa9MQBAYCIJRPSFMAYCLJRPAY2BIC8cWAOqROMAOCFrCBAOCFZl9zAQJHQROMGXGXAtCb6QBAPRMSFMAP1BBHMCgFZRbGXGXAMCa9MQBAPCFJRMSFMAP1BFHMCgBZCOWAbCgBZqRbGXAMCa9MQBAPCGJRMSFMAP1BGHMCgBZCfWAbqRbGXAMCa9MQBAPCEJRMSFMAP1BEHMCgBZCdWAbqRbGXAMCa9MQBAPCIJRMSFMAPCLJRMAP2BIC8cWAbqRbMAbCFrCBAbCFZl9zAQJHQRbMGXGXAGCG9HQBABAT87FBABCIJAb87FBABCGJAO87FBSFMAEATjGBAECNJAbjGBAECIJAOjGBMALCoBJAKCEWJHYAOjGBAYATjGIALAICGWJATjGBALCoBJAKCFJCbZCEWJHYAbjGBAYAOjGIALAICFJHICbZCGWJAOjGBALCoBJAKCGJCbZCEWJHOATjGBAOAbjGIALAIAm9FAmCb6qJHICbZCGWJAbjGBAIAt9FAtCb6qJRIAKCEJRKMANCFJRNABCKJRBAECSJREAKCbZRKAICbZRIAfCEJHfAF9JQBMMCBC99AMAc6yRKMALCoFJ8kUUUUBAKM/tIFGa8jUUUUBCTlRLC9+RKGXAFCLJAI9LQBCaRKAE2BBC/+FZC/QF9HQBALhB83ENAECFJRKAEAIJC98JREGXAF9FQBGXAGCG6QBEXGXAKAE9JQBC9+bMAK1BBHGCgFZRIGXGXAGCa9MQBAKCFJRKSFMAK1BFHGCgBZCOWAICgBZqRIGXAGCa9MQBAKCGJRKSFMAK1BGHGCgBZCfWAIqRIGXAGCa9MQBAKCEJRKSFMAK1BEHGCgBZCdWAIqRIGXAGCa9MQBAKCIJRKSFMAK2BIC8cWAIqRIAKCLJRKMALCNJAICFZCGWqHGAICGrCBAICFrCFZl9zAG8oGBJHIjGBABAIjGBABCIJRBAFCaJHFQBSGMMEXGXAKAE9JQBC9+bMAK1BBHGCgFZRIGXGXAGCa9MQBAKCFJRKSFMAK1BFHGCgBZCOWAICgBZqRIGXAGCa9MQBAKCGJRKSFMAK1BGHGCgBZCfWAIqRIGXAGCa9MQBAKCEJRKSFMAK1BEHGCgBZCdWAIqRIGXAGCa9MQBAKCIJRKSFMAK2BIC8cWAIqRIAKCLJRKMABAICGrCBAICFrCFZl9zALCNJAICFZCGWqHI8oGBJHG87FBAIAGjGBABCGJRBAFCaJHFQBMMCBC99AKAE6yRKMAKM/dLEK97FaF97GXGXAGCI9HQBAF9FQFCBRGEXABABDBBBHECiD+rFCiD+sFD/6FHIAECND+rFCiD+sFD/6FAID/gFAECTD+rFCiD+sFD/6FHLD/gFD/kFD/lFHKCBDtD+2FHOAICUUUU94DtHND9OD9RD/kFHI9DBB/+hDYAIAID/mFAKAKD/mFALAOALAND9OD9RD/kFHIAID/mFD/kFD/kFD/jFD/nFHLD/mF9DBBX9LDYHOD/kFCgFDtD9OAECUUU94DtD9OD9QAIALD/mFAOD/kFCND+rFCU/+EDtD9OD9QAKALD/mFAOD/kFCTD+rFCUU/8ODtD9OD9QDMBBABCTJRBAGCIJHGAF9JQBSGMMAF9FQBCBRGEXABCTJHVAVDBBBHECBDtHOCUU98D8cFCUU98D8cEHND9OABDBBBHKAEDQILKOSQfbPden8c8d8e8fCggFDtD9OD/6FAKAEDQBFGENVcMTtmYi8ZpyHECTD+sFD/6FHID/gFAECTD+rFCTD+sFD/6FHLD/gFD/kFD/lFHE9DB/+g6DYALAEAOD+2FHOALCUUUU94DtHcD9OD9RD/kFHLALD/mFAEAED/mFAIAOAIAcD9OD9RD/kFHEAED/mFD/kFD/kFD/jFD/nFHID/mF9DBBX9LDYHOD/kFCTD+rFALAID/mFAOD/kFCggEDtD9OD9QHLAEAID/mFAOD/kFCaDbCBDnGCBDnECBDnKCBDnOCBDncCBDnMCBDnfCBDnbD9OHEDQNVi8ZcMpySQ8c8dfb8e8fD9QDMBBABAKAND9OALAEDQBFTtGEmYILPdKOenD9QDMBBABCAJRBAGCIJHGAF9JQBMMM/hEIGaF97FaL978jUUUUBCTlREGXAF9FQBCBRIEXAEABDBBBHLABCTJHKDBBBHODQILKOSQfbPden8c8d8e8fHNCTD+sFHVCID+rFDMIBAB9DBBU8/DY9D/zI818/DYAVCEDtD9QD/6FD/nFHVALAODQBFGENVcMTtmYi8ZpyHLCTD+rFCTD+sFD/6FD/mFHOAOD/mFAVALCTD+sFD/6FD/mFHcAcD/mFAVANCTD+rFCTD+sFD/6FD/mFHNAND/mFD/kFD/kFD/lFCBDtD+4FD/jF9DB/+g6DYHVD/mF9DBBX9LDYHLD/kFCggEDtHMD9OAcAVD/mFALD/kFCTD+rFD9QHcANAVD/mFALD/kFCTD+rFAOAVD/mFALD/kFAMD9OD9QHVDQBFTtGEmYILPdKOenHLD8dBAEDBIBDyB+t+J83EBABCNJALD8dFAEDBIBDyF+t+J83EBAKAcAVDQNVi8ZcMpySQ8c8dfb8e8fHVD8dBAEDBIBDyG+t+J83EBABCiJAVD8dFAEDBIBDyE+t+J83EBABCAJRBAICIJHIAF9JQBMMM9jFF97GXAGCGrAF9sHG9FQBCBRFEXABABDBBBHECND+rFCND+sFD/6FAECiD+sFCnD+rFCUUU/8EDtD+uFD/mFDMBBABCTJRBAFCIJHFAG9JQBMMM9TFEaCBCB8oGUkUUBHFABCEJC98ZJHBjGUkUUBGXGXAB8/BCTWHGuQBCaREABAGlCggEJCTrXBCa6QFMAFREMAEMMMFBCUNMIT9tBB",
            t = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 3, 2, 0, 0, 5, 3, 1, 0, 1, 12, 1, 0, 10, 22, 2, 12, 0, 65, 0, 65, 0, 65, 0, 252, 10, 0, 0, 11, 7, 0, 65, 0, 253, 15, 26, 11]),
            i = new Uint8Array([32, 0, 65, 253, 3, 1, 2, 34, 4, 106, 6, 5, 11, 8, 7, 20, 13, 33, 12, 16, 128, 9, 116, 64, 19, 113, 127, 15, 10, 21, 22, 14, 255, 66, 24, 54, 136, 107, 18, 23, 192, 26, 114, 118, 132, 17, 77, 101, 130, 144, 27, 87, 131, 44, 45, 74, 156, 154, 70, 167]);
        if (typeof WebAssembly != "object") return {
            supported: !1
        };
        let n = s;
        WebAssembly.validate(t) && (n = e);
        let r;
        const o = WebAssembly.instantiate(a(n), {}).then(f => {
            r = f.instance, r.exports.__wasm_call_ctors()
        });

        function a(f) {
            const p = new Uint8Array(f.length);
            for (let v = 0; v < f.length; ++v) {
                const _ = f.charCodeAt(v);
                p[v] = _ > 96 ? _ - 71 : _ > 64 ? _ - 65 : _ > 47 ? _ + 4 : _ > 46 ? 63 : 62
            }
            let A = 0;
            for (let v = 0; v < f.length; ++v) p[A++] = p[v] < 60 ? i[p[v]] : (p[v] - 60) * 64 + p[++v];
            return p.buffer.slice(0, A)
        }

        function c(f, p, A, v, _, T) {
            const g = r.exports.sbrk,
                B = A + 3 & -4,
                y = g(B * v),
                b = g(_.length),
                S = new Uint8Array(r.exports.memory.buffer);
            S.set(_, b);
            const R = f(y, A, v, b, _.length);
            if (R === 0 && T && T(y, B, v), p.set(S.subarray(y, y + A * v)), g(y - g(0)), R !== 0) throw new Error(`Malformed buffer data: ${R}`)
        }
        const l = {
                0: "",
                1: "meshopt_decodeFilterOct",
                2: "meshopt_decodeFilterQuat",
                3: "meshopt_decodeFilterExp",
                NONE: "",
                OCTAHEDRAL: "meshopt_decodeFilterOct",
                QUATERNION: "meshopt_decodeFilterQuat",
                EXPONENTIAL: "meshopt_decodeFilterExp"
            },
            u = {
                0: "meshopt_decodeVertexBuffer",
                1: "meshopt_decodeIndexBuffer",
                2: "meshopt_decodeIndexSequence",
                ATTRIBUTES: "meshopt_decodeVertexBuffer",
                TRIANGLES: "meshopt_decodeIndexBuffer",
                INDICES: "meshopt_decodeIndexSequence"
            };
        return rs = {
            ready: o,
            supported: !0,
            decodeVertexBuffer(f, p, A, v, _) {
                c(r.exports.meshopt_decodeVertexBuffer, f, p, A, v, r.exports[l[_]])
            },
            decodeIndexBuffer(f, p, A, v) {
                c(r.exports.meshopt_decodeIndexBuffer, f, p, A, v)
            },
            decodeIndexSequence(f, p, A, v) {
                c(r.exports.meshopt_decodeIndexSequence, f, p, A, v)
            },
            decodeGltfBuffer(f, p, A, v, _, T) {
                c(r.exports[u[_]], f, p, A, v, r.exports[l[T]])
            }
        }, rs
    },
    ze = x.forwardRef(({
        url: s,
        distance: e = 1,
        loop: t = !0,
        autoplay: i,
        ...n
    }, r) => {
        const o = x.useRef(null);
        x.useImperativeHandle(r, () => o.current, []);
        const a = X(({
                camera: u
            }) => u),
            [c] = x.useState(() => new fo),
            l = ct(po, s);
        return x.useEffect(() => {
            const u = o.current;
            u && (u.setBuffer(l), u.setRefDistance(e), u.setLoop(t), i && !u.isPlaying && u.play())
        }, [l, a, e, t]), x.useEffect(() => {
            const u = o.current;
            return a.add(c), () => {
                a.remove(c), u && (u.isPlaying && u.stop(), u.source && u.source._connected && u.disconnect())
            }
        }, []), x.createElement("positionalAudio", Xt({
            ref: o,
            args: [c]
        }, n))
    });

function ma(s, e, t, i) {
    const n = class extends Ne {
        constructor(o = {}) {
            const a = Object.entries(s);
            super({
                uniforms: a.reduce((c, [l, u]) => {
                    const f = mo.clone({
                        [l]: {
                            value: u
                        }
                    });
                    return { ...c,
                        ...f
                    }
                }, {}),
                vertexShader: e,
                fragmentShader: t
            }), this.key = "", a.forEach(([c]) => Object.defineProperty(this, c, {
                get: () => this.uniforms[c].value,
                set: l => this.uniforms[c].value = l
            })), Object.assign(this, o)
        }
    };
    return n.key = Ai.generateUUID(), n
}
const Ns = s => s === Object(s) && !Array.isArray(s) && typeof s != "function";

function gs(s, e) {
    const t = X(r => r.gl),
        i = ct(vs, Ns(s) ? Object.values(s) : s);
    return x.useLayoutEffect(() => {
        e ? .(i)
    }, [e]), x.useEffect(() => {
        if ("initTexture" in t) {
            let r = [];
            Array.isArray(i) ? r = i : i instanceof at ? r = [i] : Ns(i) && (r = Object.values(i)), r.forEach(o => {
                o instanceof at && t.initTexture(o)
            })
        }
    }, [t, i]), x.useMemo(() => {
        if (Ns(s)) {
            const r = {};
            let o = 0;
            for (const a in s) r[a] = i[o++];
            return r
        } else return i
    }, [s, i])
}
gs.preload = s => ct.preload(vs, s);
gs.clear = s => ct.clear(vs, s);
let os = null,
    sr = "https://www.gstatic.com/draco/versioned/decoders/1.5.5/";

function ir(s = !0, e = !0, t) {
    return i => {
        t && t(i), s && (os || (os = new fa), os.setDecoderPath(typeof s == "string" ? s : sr), i.setDRACOLoader(os)), e && i.setMeshoptDecoder(typeof Hs == "function" ? Hs() : Hs)
    }
}
const ht = (s, e, t, i) => ct(Ti, s, ir(e, t, i));
ht.preload = (s, e, t, i) => ct.preload(Ti, s, ir(e, t, i));
ht.clear = s => ct.clear(Ti, s);
ht.setDecoderPath = s => {
    sr = s
};

function Aa(s, e, t) {
    const i = X(p => p.size),
        n = X(p => p.viewport),
        r = typeof s == "number" ? s : i.width * n.dpr,
        o = i.height * n.dpr,
        a = (typeof s == "number" ? t : s) || {},
        {
            samples: c = 0,
            depth: l,
            ...u
        } = a,
        f = x.useMemo(() => {
            const p = new Be(r, o, {
                minFilter: Ve,
                magFilter: Ve,
                type: Wn,
                ...u
            });
            return l && (p.depthTexture = new ps(r, o, gi)), p.samples = c, p
        }, []);
    return x.useLayoutEffect(() => {
        f.setSize(r, o), c && (f.samples = c)
    }, [c, f, r, o]), x.useEffect(() => () => f.dispose(), []), f
}
const ga = s => typeof s == "function",
    va = x.forwardRef(({
        envMap: s,
        resolution: e = 256,
        frames: t = 1 / 0,
        makeDefault: i,
        children: n,
        ...r
    }, o) => {
        const a = X(({
                set: T
            }) => T),
            c = X(({
                camera: T
            }) => T),
            l = X(({
                size: T
            }) => T),
            u = x.useRef(null);
        x.useImperativeHandle(o, () => u.current, []);
        const f = x.useRef(null),
            p = Aa(e);
        x.useLayoutEffect(() => {
            r.manual || (u.current.aspect = l.width / l.height)
        }, [l, r]), x.useLayoutEffect(() => {
            u.current.updateProjectionMatrix()
        });
        let A = 0,
            v = null;
        const _ = ga(n);
        return Fe(T => {
            _ && (t === 1 / 0 || A < t) && (f.current.visible = !1, T.gl.setRenderTarget(p), v = T.scene.background, s && (T.scene.background = s), T.gl.render(T.scene, u.current), T.scene.background = v, T.gl.setRenderTarget(null), f.current.visible = !0, A++)
        }), x.useLayoutEffect(() => {
            if (i) {
                const T = c;
                return a(() => ({
                    camera: u.current
                })), () => a(() => ({
                    camera: T
                }))
            }
        }, [u, i, a]), x.createElement(x.Fragment, null, x.createElement("perspectiveCamera", Xt({
            ref: u
        }, r), !_ && n), x.createElement("group", {
            ref: f
        }, _ && n(p.texture)))
    });
const W = {
        LEFT: 1,
        RIGHT: 2,
        MIDDLE: 4
    },
    E = Object.freeze({
        NONE: 0,
        ROTATE: 1,
        TRUCK: 2,
        SCREEN_PAN: 4,
        OFFSET: 8,
        DOLLY: 16,
        ZOOM: 32,
        TOUCH_ROTATE: 64,
        TOUCH_TRUCK: 128,
        TOUCH_SCREEN_PAN: 256,
        TOUCH_OFFSET: 512,
        TOUCH_DOLLY: 1024,
        TOUCH_ZOOM: 2048,
        TOUCH_DOLLY_TRUCK: 4096,
        TOUCH_DOLLY_SCREEN_PAN: 8192,
        TOUCH_DOLLY_OFFSET: 16384,
        TOUCH_DOLLY_ROTATE: 32768,
        TOUCH_ZOOM_TRUCK: 65536,
        TOUCH_ZOOM_OFFSET: 131072,
        TOUCH_ZOOM_SCREEN_PAN: 262144,
        TOUCH_ZOOM_ROTATE: 524288
    }),
    pt = {
        NONE: 0,
        IN: 1,
        OUT: -1
    };

function st(s) {
    return s.isPerspectiveCamera
}

function je(s) {
    return s.isOrthographicCamera
}
const mt = Math.PI * 2,
    fn = Math.PI / 2,
    nr = 1e-5,
    Ut = Math.PI / 180;

function ye(s, e, t) {
    return Math.max(e, Math.min(t, s))
}

function j(s, e = nr) {
    return Math.abs(s) < e
}

function Y(s, e, t = nr) {
    return j(s - e, t)
}

function pn(s, e) {
    return Math.round(s / e) * e
}

function Lt(s) {
    return isFinite(s) ? s : s < 0 ? -Number.MAX_VALUE : Number.MAX_VALUE
}

function wt(s) {
    return Math.abs(s) < Number.MAX_VALUE ? s : s * (1 / 0)
}

function as(s, e, t, i, n = 1 / 0, r) {
    i = Math.max(1e-4, i);
    const o = 2 / i,
        a = o * r,
        c = 1 / (1 + a + .48 * a * a + .235 * a * a * a);
    let l = s - e;
    const u = e,
        f = n * i;
    l = ye(l, -f, f), e = s - l;
    const p = (t.value + o * l) * r;
    t.value = (t.value - o * p) * c;
    let A = e + (l + p) * c;
    return u - s > 0 == A > u && (A = u, t.value = (A - u) / r), A
}

function mn(s, e, t, i, n = 1 / 0, r, o) {
    i = Math.max(1e-4, i);
    const a = 2 / i,
        c = a * r,
        l = 1 / (1 + c + .48 * c * c + .235 * c * c * c);
    let u = e.x,
        f = e.y,
        p = e.z,
        A = s.x - u,
        v = s.y - f,
        _ = s.z - p;
    const T = u,
        g = f,
        B = p,
        y = n * i,
        b = y * y,
        S = A * A + v * v + _ * _;
    if (S > b) {
        const Ce = Math.sqrt(S);
        A = A / Ce * y, v = v / Ce * y, _ = _ / Ce * y
    }
    u = s.x - A, f = s.y - v, p = s.z - _;
    const R = (t.x + a * A) * r,
        D = (t.y + a * v) * r,
        F = (t.z + a * _) * r;
    t.x = (t.x - a * R) * l, t.y = (t.y - a * D) * l, t.z = (t.z - a * F) * l, o.x = u + (A + R) * l, o.y = f + (v + D) * l, o.z = p + (_ + F) * l;
    const w = T - s.x,
        z = g - s.y,
        Q = B - s.z,
        q = o.x - T,
        de = o.y - g,
        Ee = o.z - B;
    return w * q + z * de + Q * Ee > 0 && (o.x = T, o.y = g, o.z = B, t.x = (o.x - T) / r, t.y = (o.y - g) / r, t.z = (o.z - B) / r), o
}

function ks(s, e) {
    e.set(0, 0), s.forEach(t => {
        e.x += t.clientX, e.y += t.clientY
    }), e.x /= s.length, e.y /= s.length
}

function Js(s, e) {
    return je(s) ? (console.warn(`${e} is not supported in OrthographicCamera`), !0) : !1
}
class Ba {
    constructor() {
        this._listeners = {}
    }
    addEventListener(e, t) {
        const i = this._listeners;
        i[e] === void 0 && (i[e] = []), i[e].indexOf(t) === -1 && i[e].push(t)
    }
    hasEventListener(e, t) {
        const i = this._listeners;
        return i[e] !== void 0 && i[e].indexOf(t) !== -1
    }
    removeEventListener(e, t) {
        const n = this._listeners[e];
        if (n !== void 0) {
            const r = n.indexOf(t);
            r !== -1 && n.splice(r, 1)
        }
    }
    removeAllEventListeners(e) {
        if (!e) {
            this._listeners = {};
            return
        }
        Array.isArray(this._listeners[e]) && (this._listeners[e].length = 0)
    }
    dispatchEvent(e) {
        const i = this._listeners[e.type];
        if (i !== void 0) {
            e.target = this;
            const n = i.slice(0);
            for (let r = 0, o = n.length; r < o; r++) n[r].call(this, e)
        }
    }
}
var Ks;
const Ea = "2.10.1",
    cs = 1 / 8,
    Ca = /Mac/.test((Ks = globalThis ? .navigator) === null || Ks === void 0 ? void 0 : Ks.platform);
let U, An, ls, zs, le, P, J, At, Pt, xe, De, it, gn, vn, me, Gt, gt, Bn, Ys, En, Xs, js, hs, Qs = class ui extends Ba {
    static install(e) {
        U = e.THREE, An = Object.freeze(new U.Vector3(0, 0, 0)), ls = Object.freeze(new U.Vector3(0, 1, 0)), zs = Object.freeze(new U.Vector3(0, 0, 1)), le = new U.Vector2, P = new U.Vector3, J = new U.Vector3, At = new U.Vector3, Pt = new U.Vector3, xe = new U.Vector3, De = new U.Vector3, it = new U.Vector3, gn = new U.Vector3, vn = new U.Vector3, me = new U.Spherical, Gt = new U.Spherical, gt = new U.Box3, Bn = new U.Box3, Ys = new U.Sphere, En = new U.Quaternion, Xs = new U.Quaternion, js = new U.Matrix4, hs = new U.Raycaster
    }
    static get ACTION() {
        return E
    }
    set verticalDragToForward(e) {
        console.warn("camera-controls: `verticalDragToForward` was removed. Use `mouseButtons.left = CameraControls.ACTION.SCREEN_PAN` instead.")
    }
    constructor(e, t) {
        super(), this.minPolarAngle = 0, this.maxPolarAngle = Math.PI, this.minAzimuthAngle = -1 / 0, this.maxAzimuthAngle = 1 / 0, this.minDistance = Number.EPSILON, this.maxDistance = 1 / 0, this.infinityDolly = !1, this.minZoom = .01, this.maxZoom = 1 / 0, this.smoothTime = .25, this.draggingSmoothTime = .125, this.maxSpeed = 1 / 0, this.azimuthRotateSpeed = 1, this.polarRotateSpeed = 1, this.dollySpeed = 1, this.dollyDragInverted = !1, this.truckSpeed = 2, this.dollyToCursor = !1, this.dragToOffset = !1, this.boundaryFriction = 0, this.restThreshold = .01, this.colliderMeshes = [], this.cancel = () => {}, this._enabled = !0, this._state = E.NONE, this._viewport = null, this._changedDolly = 0, this._changedZoom = 0, this._hasRested = !0, this._boundaryEnclosesCamera = !1, this._needsUpdate = !0, this._updatedLastTime = !1, this._elementRect = new DOMRect, this._isDragging = !1, this._dragNeedsUpdate = !0, this._activePointers = [], this._lockedPointer = null, this._interactiveArea = new DOMRect(0, 0, 1, 1), this._isUserControllingRotate = !1, this._isUserControllingDolly = !1, this._isUserControllingTruck = !1, this._isUserControllingOffset = !1, this._isUserControllingZoom = !1, this._lastDollyDirection = pt.NONE, this._thetaVelocity = {
            value: 0
        }, this._phiVelocity = {
            value: 0
        }, this._radiusVelocity = {
            value: 0
        }, this._targetVelocity = new U.Vector3, this._focalOffsetVelocity = new U.Vector3, this._zoomVelocity = {
            value: 0
        }, this._truckInternal = (g, B, y, b) => {
            let S, R;
            if (st(this._camera)) {
                const D = P.copy(this._camera.position).sub(this._target),
                    F = this._camera.getEffectiveFOV() * Ut,
                    w = D.length() * Math.tan(F * .5);
                S = this.truckSpeed * g * w / this._elementRect.height, R = this.truckSpeed * B * w / this._elementRect.height
            } else if (je(this._camera)) {
                const D = this._camera;
                S = this.truckSpeed * g * (D.right - D.left) / D.zoom / this._elementRect.width, R = this.truckSpeed * B * (D.top - D.bottom) / D.zoom / this._elementRect.height
            } else return;
            b ? (y ? this.setFocalOffset(this._focalOffsetEnd.x + S, this._focalOffsetEnd.y, this._focalOffsetEnd.z, !0) : this.truck(S, 0, !0), this.forward(-R, !0)) : y ? this.setFocalOffset(this._focalOffsetEnd.x + S, this._focalOffsetEnd.y + R, this._focalOffsetEnd.z, !0) : this.truck(S, R, !0)
        }, this._rotateInternal = (g, B) => {
            const y = mt * this.azimuthRotateSpeed * g / this._elementRect.height,
                b = mt * this.polarRotateSpeed * B / this._elementRect.height;
            this.rotate(y, b, !0)
        }, this._dollyInternal = (g, B, y) => {
            const b = Math.pow(.95, -g * this.dollySpeed),
                S = this._sphericalEnd.radius,
                R = this._sphericalEnd.radius * b,
                D = ye(R, this.minDistance, this.maxDistance),
                F = D - R;
            this.infinityDolly && this.dollyToCursor ? this._dollyToNoClamp(R, !0) : this.infinityDolly && !this.dollyToCursor ? (this.dollyInFixed(F, !0), this._dollyToNoClamp(D, !0)) : this._dollyToNoClamp(D, !0), this.dollyToCursor && (this._changedDolly += (this.infinityDolly ? R : D) - S, this._dollyControlCoord.set(B, y)), this._lastDollyDirection = Math.sign(-g)
        }, this._zoomInternal = (g, B, y) => {
            const b = Math.pow(.95, g * this.dollySpeed),
                S = this._zoom,
                R = this._zoom * b;
            this.zoomTo(R, !0), this.dollyToCursor && (this._changedZoom += R - S, this._dollyControlCoord.set(B, y))
        }, typeof U > "u" && console.error("camera-controls: `THREE` is undefined. You must first run `CameraControls.install( { THREE: THREE } )`. Check the docs for further information."), this._camera = e, this._yAxisUpSpace = new U.Quaternion().setFromUnitVectors(this._camera.up, ls), this._yAxisUpSpaceInverse = this._yAxisUpSpace.clone().invert(), this._state = E.NONE, this._target = new U.Vector3, this._targetEnd = this._target.clone(), this._focalOffset = new U.Vector3, this._focalOffsetEnd = this._focalOffset.clone(), this._spherical = new U.Spherical().setFromVector3(P.copy(this._camera.position).applyQuaternion(this._yAxisUpSpace)), this._sphericalEnd = this._spherical.clone(), this._lastDistance = this._spherical.radius, this._zoom = this._camera.zoom, this._zoomEnd = this._zoom, this._lastZoom = this._zoom, this._nearPlaneCorners = [new U.Vector3, new U.Vector3, new U.Vector3, new U.Vector3], this._updateNearPlaneCorners(), this._boundary = new U.Box3(new U.Vector3(-1 / 0, -1 / 0, -1 / 0), new U.Vector3(1 / 0, 1 / 0, 1 / 0)), this._cameraUp0 = this._camera.up.clone(), this._target0 = this._target.clone(), this._position0 = this._camera.position.clone(), this._zoom0 = this._zoom, this._focalOffset0 = this._focalOffset.clone(), this._dollyControlCoord = new U.Vector2, this.mouseButtons = {
            left: E.ROTATE,
            middle: E.DOLLY,
            right: E.TRUCK,
            wheel: st(this._camera) ? E.DOLLY : je(this._camera) ? E.ZOOM : E.NONE
        }, this.touches = {
            one: E.TOUCH_ROTATE,
            two: st(this._camera) ? E.TOUCH_DOLLY_TRUCK : je(this._camera) ? E.TOUCH_ZOOM_TRUCK : E.NONE,
            three: E.TOUCH_TRUCK
        };
        const i = new U.Vector2,
            n = new U.Vector2,
            r = new U.Vector2,
            o = g => {
                if (!this._enabled || !this._domElement) return;
                if (this._interactiveArea.left !== 0 || this._interactiveArea.top !== 0 || this._interactiveArea.width !== 1 || this._interactiveArea.height !== 1) {
                    const b = this._domElement.getBoundingClientRect(),
                        S = g.clientX / b.width,
                        R = g.clientY / b.height;
                    if (S < this._interactiveArea.left || S > this._interactiveArea.right || R < this._interactiveArea.top || R > this._interactiveArea.bottom) return
                }
                const B = g.pointerType !== "mouse" ? null : (g.buttons & W.LEFT) === W.LEFT ? W.LEFT : (g.buttons & W.MIDDLE) === W.MIDDLE ? W.MIDDLE : (g.buttons & W.RIGHT) === W.RIGHT ? W.RIGHT : null;
                if (B !== null) {
                    const b = this._findPointerByMouseButton(B);
                    b && this._disposePointer(b)
                }
                if ((g.buttons & W.LEFT) === W.LEFT && this._lockedPointer) return;
                const y = {
                    pointerId: g.pointerId,
                    clientX: g.clientX,
                    clientY: g.clientY,
                    deltaX: 0,
                    deltaY: 0,
                    mouseButton: B
                };
                this._activePointers.push(y), this._domElement.ownerDocument.removeEventListener("pointermove", a, {
                    passive: !1
                }), this._domElement.ownerDocument.removeEventListener("pointerup", c), this._domElement.ownerDocument.addEventListener("pointermove", a, {
                    passive: !1
                }), this._domElement.ownerDocument.addEventListener("pointerup", c), this._isDragging = !0, p(g)
            },
            a = g => {
                g.cancelable && g.preventDefault();
                const B = g.pointerId,
                    y = this._lockedPointer || this._findPointerById(B);
                if (y) {
                    if (y.clientX = g.clientX, y.clientY = g.clientY, y.deltaX = g.movementX, y.deltaY = g.movementY, this._state = 0, g.pointerType === "touch") switch (this._activePointers.length) {
                        case 1:
                            this._state = this.touches.one;
                            break;
                        case 2:
                            this._state = this.touches.two;
                            break;
                        case 3:
                            this._state = this.touches.three;
                            break
                    } else(!this._isDragging && this._lockedPointer || this._isDragging && (g.buttons & W.LEFT) === W.LEFT) && (this._state = this._state | this.mouseButtons.left), this._isDragging && (g.buttons & W.MIDDLE) === W.MIDDLE && (this._state = this._state | this.mouseButtons.middle), this._isDragging && (g.buttons & W.RIGHT) === W.RIGHT && (this._state = this._state | this.mouseButtons.right);
                    A()
                }
            },
            c = g => {
                const B = this._findPointerById(g.pointerId);
                if (!(B && B === this._lockedPointer)) {
                    if (B && this._disposePointer(B), g.pointerType === "touch") switch (this._activePointers.length) {
                        case 0:
                            this._state = E.NONE;
                            break;
                        case 1:
                            this._state = this.touches.one;
                            break;
                        case 2:
                            this._state = this.touches.two;
                            break;
                        case 3:
                            this._state = this.touches.three;
                            break
                    } else this._state = E.NONE;
                    v()
                }
            };
        let l = -1;
        const u = g => {
                if (!this._domElement || !this._enabled || this.mouseButtons.wheel === E.NONE) return;
                if (this._interactiveArea.left !== 0 || this._interactiveArea.top !== 0 || this._interactiveArea.width !== 1 || this._interactiveArea.height !== 1) {
                    const R = this._domElement.getBoundingClientRect(),
                        D = g.clientX / R.width,
                        F = g.clientY / R.height;
                    if (D < this._interactiveArea.left || D > this._interactiveArea.right || F < this._interactiveArea.top || F > this._interactiveArea.bottom) return
                }
                if (g.preventDefault(), this.dollyToCursor || this.mouseButtons.wheel === E.ROTATE || this.mouseButtons.wheel === E.TRUCK) {
                    const R = performance.now();
                    l - R < 1e3 && this._getClientRect(this._elementRect), l = R
                }
                const B = Ca ? -1 : -3,
                    y = g.deltaMode === 1 || g.ctrlKey ? g.deltaY / B : g.deltaY / (B * 10),
                    b = this.dollyToCursor ? (g.clientX - this._elementRect.x) / this._elementRect.width * 2 - 1 : 0,
                    S = this.dollyToCursor ? (g.clientY - this._elementRect.y) / this._elementRect.height * -2 + 1 : 0;
                switch (this.mouseButtons.wheel) {
                    case E.ROTATE:
                        {
                            this._rotateInternal(g.deltaX, g.deltaY),
                            this._isUserControllingRotate = !0;
                            break
                        }
                    case E.TRUCK:
                        {
                            this._truckInternal(g.deltaX, g.deltaY, !1, !1),
                            this._isUserControllingTruck = !0;
                            break
                        }
                    case E.SCREEN_PAN:
                        {
                            this._truckInternal(g.deltaX, g.deltaY, !1, !0),
                            this._isUserControllingTruck = !0;
                            break
                        }
                    case E.OFFSET:
                        {
                            this._truckInternal(g.deltaX, g.deltaY, !0, !1),
                            this._isUserControllingOffset = !0;
                            break
                        }
                    case E.DOLLY:
                        {
                            this._dollyInternal(-y, b, S),
                            this._isUserControllingDolly = !0;
                            break
                        }
                    case E.ZOOM:
                        {
                            this._zoomInternal(-y, b, S),
                            this._isUserControllingZoom = !0;
                            break
                        }
                }
                this.dispatchEvent({
                    type: "control"
                })
            },
            f = g => {
                if (!(!this._domElement || !this._enabled)) {
                    if (this.mouseButtons.right === ui.ACTION.NONE) {
                        const B = g instanceof PointerEvent ? g.pointerId : 0,
                            y = this._findPointerById(B);
                        y && this._disposePointer(y), this._domElement.ownerDocument.removeEventListener("pointermove", a, {
                            passive: !1
                        }), this._domElement.ownerDocument.removeEventListener("pointerup", c);
                        return
                    }
                    g.preventDefault()
                }
            },
            p = g => {
                if (!this._enabled) return;
                if (ks(this._activePointers, le), this._getClientRect(this._elementRect), i.copy(le), n.copy(le), this._activePointers.length >= 2) {
                    const y = le.x - this._activePointers[1].clientX,
                        b = le.y - this._activePointers[1].clientY,
                        S = Math.sqrt(y * y + b * b);
                    r.set(0, S);
                    const R = (this._activePointers[0].clientX + this._activePointers[1].clientX) * .5,
                        D = (this._activePointers[0].clientY + this._activePointers[1].clientY) * .5;
                    n.set(R, D)
                }
                if (this._state = 0, !g) this._lockedPointer && (this._state = this._state | this.mouseButtons.left);
                else if ("pointerType" in g && g.pointerType === "touch") switch (this._activePointers.length) {
                    case 1:
                        this._state = this.touches.one;
                        break;
                    case 2:
                        this._state = this.touches.two;
                        break;
                    case 3:
                        this._state = this.touches.three;
                        break
                } else !this._lockedPointer && (g.buttons & W.LEFT) === W.LEFT && (this._state = this._state | this.mouseButtons.left), (g.buttons & W.MIDDLE) === W.MIDDLE && (this._state = this._state | this.mouseButtons.middle), (g.buttons & W.RIGHT) === W.RIGHT && (this._state = this._state | this.mouseButtons.right);
                ((this._state & E.ROTATE) === E.ROTATE || (this._state & E.TOUCH_ROTATE) === E.TOUCH_ROTATE || (this._state & E.TOUCH_DOLLY_ROTATE) === E.TOUCH_DOLLY_ROTATE || (this._state & E.TOUCH_ZOOM_ROTATE) === E.TOUCH_ZOOM_ROTATE) && (this._sphericalEnd.theta = this._spherical.theta, this._sphericalEnd.phi = this._spherical.phi, this._thetaVelocity.value = 0, this._phiVelocity.value = 0), ((this._state & E.TRUCK) === E.TRUCK || (this._state & E.SCREEN_PAN) === E.SCREEN_PAN || (this._state & E.TOUCH_TRUCK) === E.TOUCH_TRUCK || (this._state & E.TOUCH_SCREEN_PAN) === E.TOUCH_SCREEN_PAN || (this._state & E.TOUCH_DOLLY_TRUCK) === E.TOUCH_DOLLY_TRUCK || (this._state & E.TOUCH_DOLLY_SCREEN_PAN) === E.TOUCH_DOLLY_SCREEN_PAN || (this._state & E.TOUCH_ZOOM_TRUCK) === E.TOUCH_ZOOM_TRUCK || (this._state & E.TOUCH_ZOOM_SCREEN_PAN) === E.TOUCH_DOLLY_SCREEN_PAN) && (this._targetEnd.copy(this._target), this._targetVelocity.set(0, 0, 0)), ((this._state & E.DOLLY) === E.DOLLY || (this._state & E.TOUCH_DOLLY) === E.TOUCH_DOLLY || (this._state & E.TOUCH_DOLLY_TRUCK) === E.TOUCH_DOLLY_TRUCK || (this._state & E.TOUCH_DOLLY_SCREEN_PAN) === E.TOUCH_DOLLY_SCREEN_PAN || (this._state & E.TOUCH_DOLLY_OFFSET) === E.TOUCH_DOLLY_OFFSET || (this._state & E.TOUCH_DOLLY_ROTATE) === E.TOUCH_DOLLY_ROTATE) && (this._sphericalEnd.radius = this._spherical.radius, this._radiusVelocity.value = 0), ((this._state & E.ZOOM) === E.ZOOM || (this._state & E.TOUCH_ZOOM) === E.TOUCH_ZOOM || (this._state & E.TOUCH_ZOOM_TRUCK) === E.TOUCH_ZOOM_TRUCK || (this._state & E.TOUCH_ZOOM_SCREEN_PAN) === E.TOUCH_ZOOM_SCREEN_PAN || (this._state & E.TOUCH_ZOOM_OFFSET) === E.TOUCH_ZOOM_OFFSET || (this._state & E.TOUCH_ZOOM_ROTATE) === E.TOUCH_ZOOM_ROTATE) && (this._zoomEnd = this._zoom, this._zoomVelocity.value = 0), ((this._state & E.OFFSET) === E.OFFSET || (this._state & E.TOUCH_OFFSET) === E.TOUCH_OFFSET || (this._state & E.TOUCH_DOLLY_OFFSET) === E.TOUCH_DOLLY_OFFSET || (this._state & E.TOUCH_ZOOM_OFFSET) === E.TOUCH_ZOOM_OFFSET) && (this._focalOffsetEnd.copy(this._focalOffset), this._focalOffsetVelocity.set(0, 0, 0)), this.dispatchEvent({
                    type: "controlstart"
                })
            },
            A = () => {
                if (!this._enabled || !this._dragNeedsUpdate) return;
                this._dragNeedsUpdate = !1, ks(this._activePointers, le);
                const B = this._domElement && this._domElement.ownerDocument.pointerLockElement === this._domElement ? this._lockedPointer || this._activePointers[0] : null,
                    y = B ? -B.deltaX : n.x - le.x,
                    b = B ? -B.deltaY : n.y - le.y;
                if (n.copy(le), ((this._state & E.ROTATE) === E.ROTATE || (this._state & E.TOUCH_ROTATE) === E.TOUCH_ROTATE || (this._state & E.TOUCH_DOLLY_ROTATE) === E.TOUCH_DOLLY_ROTATE || (this._state & E.TOUCH_ZOOM_ROTATE) === E.TOUCH_ZOOM_ROTATE) && (this._rotateInternal(y, b), this._isUserControllingRotate = !0), (this._state & E.DOLLY) === E.DOLLY || (this._state & E.ZOOM) === E.ZOOM) {
                    const S = this.dollyToCursor ? (i.x - this._elementRect.x) / this._elementRect.width * 2 - 1 : 0,
                        R = this.dollyToCursor ? (i.y - this._elementRect.y) / this._elementRect.height * -2 + 1 : 0,
                        D = this.dollyDragInverted ? -1 : 1;
                    (this._state & E.DOLLY) === E.DOLLY ? (this._dollyInternal(D * b * cs, S, R), this._isUserControllingDolly = !0) : (this._zoomInternal(D * b * cs, S, R), this._isUserControllingZoom = !0)
                }
                if ((this._state & E.TOUCH_DOLLY) === E.TOUCH_DOLLY || (this._state & E.TOUCH_ZOOM) === E.TOUCH_ZOOM || (this._state & E.TOUCH_DOLLY_TRUCK) === E.TOUCH_DOLLY_TRUCK || (this._state & E.TOUCH_ZOOM_TRUCK) === E.TOUCH_ZOOM_TRUCK || (this._state & E.TOUCH_DOLLY_SCREEN_PAN) === E.TOUCH_DOLLY_SCREEN_PAN || (this._state & E.TOUCH_ZOOM_SCREEN_PAN) === E.TOUCH_ZOOM_SCREEN_PAN || (this._state & E.TOUCH_DOLLY_OFFSET) === E.TOUCH_DOLLY_OFFSET || (this._state & E.TOUCH_ZOOM_OFFSET) === E.TOUCH_ZOOM_OFFSET || (this._state & E.TOUCH_DOLLY_ROTATE) === E.TOUCH_DOLLY_ROTATE || (this._state & E.TOUCH_ZOOM_ROTATE) === E.TOUCH_ZOOM_ROTATE) {
                    const S = le.x - this._activePointers[1].clientX,
                        R = le.y - this._activePointers[1].clientY,
                        D = Math.sqrt(S * S + R * R),
                        F = r.y - D;
                    r.set(0, D);
                    const w = this.dollyToCursor ? (n.x - this._elementRect.x) / this._elementRect.width * 2 - 1 : 0,
                        z = this.dollyToCursor ? (n.y - this._elementRect.y) / this._elementRect.height * -2 + 1 : 0;
                    (this._state & E.TOUCH_DOLLY) === E.TOUCH_DOLLY || (this._state & E.TOUCH_DOLLY_ROTATE) === E.TOUCH_DOLLY_ROTATE || (this._state & E.TOUCH_DOLLY_TRUCK) === E.TOUCH_DOLLY_TRUCK || (this._state & E.TOUCH_DOLLY_SCREEN_PAN) === E.TOUCH_DOLLY_SCREEN_PAN || (this._state & E.TOUCH_DOLLY_OFFSET) === E.TOUCH_DOLLY_OFFSET ? (this._dollyInternal(F * cs, w, z), this._isUserControllingDolly = !0) : (this._zoomInternal(F * cs, w, z), this._isUserControllingZoom = !0)
                }((this._state & E.TRUCK) === E.TRUCK || (this._state & E.TOUCH_TRUCK) === E.TOUCH_TRUCK || (this._state & E.TOUCH_DOLLY_TRUCK) === E.TOUCH_DOLLY_TRUCK || (this._state & E.TOUCH_ZOOM_TRUCK) === E.TOUCH_ZOOM_TRUCK) && (this._truckInternal(y, b, !1, !1), this._isUserControllingTruck = !0), ((this._state & E.SCREEN_PAN) === E.SCREEN_PAN || (this._state & E.TOUCH_SCREEN_PAN) === E.TOUCH_SCREEN_PAN || (this._state & E.TOUCH_DOLLY_SCREEN_PAN) === E.TOUCH_DOLLY_SCREEN_PAN || (this._state & E.TOUCH_ZOOM_SCREEN_PAN) === E.TOUCH_ZOOM_SCREEN_PAN) && (this._truckInternal(y, b, !1, !0), this._isUserControllingTruck = !0), ((this._state & E.OFFSET) === E.OFFSET || (this._state & E.TOUCH_OFFSET) === E.TOUCH_OFFSET || (this._state & E.TOUCH_DOLLY_OFFSET) === E.TOUCH_DOLLY_OFFSET || (this._state & E.TOUCH_ZOOM_OFFSET) === E.TOUCH_ZOOM_OFFSET) && (this._truckInternal(y, b, !0, !1), this._isUserControllingOffset = !0), this.dispatchEvent({
                    type: "control"
                })
            },
            v = () => {
                ks(this._activePointers, le), n.copy(le), this._dragNeedsUpdate = !1, (this._activePointers.length === 0 || this._activePointers.length === 1 && this._activePointers[0] === this._lockedPointer) && (this._isDragging = !1), this._activePointers.length === 0 && this._domElement && (this._domElement.ownerDocument.removeEventListener("pointermove", a, {
                    passive: !1
                }), this._domElement.ownerDocument.removeEventListener("pointerup", c), this.dispatchEvent({
                    type: "controlend"
                }))
            };
        this.lockPointer = () => {
            !this._enabled || !this._domElement || (this.cancel(), this._lockedPointer = {
                pointerId: -1,
                clientX: 0,
                clientY: 0,
                deltaX: 0,
                deltaY: 0,
                mouseButton: null
            }, this._activePointers.push(this._lockedPointer), this._domElement.ownerDocument.removeEventListener("pointermove", a, {
                passive: !1
            }), this._domElement.ownerDocument.removeEventListener("pointerup", c), this._domElement.requestPointerLock(), this._domElement.ownerDocument.addEventListener("pointerlockchange", _), this._domElement.ownerDocument.addEventListener("pointerlockerror", T), this._domElement.ownerDocument.addEventListener("pointermove", a, {
                passive: !1
            }), this._domElement.ownerDocument.addEventListener("pointerup", c), p())
        }, this.unlockPointer = () => {
            var g, B, y;
            this._lockedPointer !== null && (this._disposePointer(this._lockedPointer), this._lockedPointer = null), (g = this._domElement) === null || g === void 0 || g.ownerDocument.exitPointerLock(), (B = this._domElement) === null || B === void 0 || B.ownerDocument.removeEventListener("pointerlockchange", _), (y = this._domElement) === null || y === void 0 || y.ownerDocument.removeEventListener("pointerlockerror", T), this.cancel()
        };
        const _ = () => {
                this._domElement && this._domElement.ownerDocument.pointerLockElement === this._domElement || this.unlockPointer()
            },
            T = () => {
                this.unlockPointer()
            };
        this._addAllEventListeners = g => {
            this._domElement = g, this._domElement.style.touchAction = "none", this._domElement.style.userSelect = "none", this._domElement.style.webkitUserSelect = "none", this._domElement.addEventListener("pointerdown", o), this._domElement.addEventListener("pointercancel", c), this._domElement.addEventListener("wheel", u, {
                passive: !1
            }), this._domElement.addEventListener("contextmenu", f)
        }, this._removeAllEventListeners = () => {
            this._domElement && (this._domElement.style.touchAction = "", this._domElement.style.userSelect = "", this._domElement.style.webkitUserSelect = "", this._domElement.removeEventListener("pointerdown", o), this._domElement.removeEventListener("pointercancel", c), this._domElement.removeEventListener("wheel", u, {
                passive: !1
            }), this._domElement.removeEventListener("contextmenu", f), this._domElement.ownerDocument.removeEventListener("pointermove", a, {
                passive: !1
            }), this._domElement.ownerDocument.removeEventListener("pointerup", c), this._domElement.ownerDocument.removeEventListener("pointerlockchange", _), this._domElement.ownerDocument.removeEventListener("pointerlockerror", T))
        }, this.cancel = () => {
            this._state !== E.NONE && (this._state = E.NONE, this._activePointers.length = 0, v())
        }, t && this.connect(t), this.update(0)
    }
    get camera() {
        return this._camera
    }
    set camera(e) {
        this._camera = e, this.updateCameraUp(), this._camera.updateProjectionMatrix(), this._updateNearPlaneCorners(), this._needsUpdate = !0
    }
    get enabled() {
        return this._enabled
    }
    set enabled(e) {
        this._enabled = e, this._domElement && (e ? (this._domElement.style.touchAction = "none", this._domElement.style.userSelect = "none", this._domElement.style.webkitUserSelect = "none") : (this.cancel(), this._domElement.style.touchAction = "", this._domElement.style.userSelect = "", this._domElement.style.webkitUserSelect = ""))
    }
    get active() {
        return !this._hasRested
    }
    get currentAction() {
        return this._state
    }
    get distance() {
        return this._spherical.radius
    }
    set distance(e) {
        this._spherical.radius === e && this._sphericalEnd.radius === e || (this._spherical.radius = e, this._sphericalEnd.radius = e, this._needsUpdate = !0)
    }
    get azimuthAngle() {
        return this._spherical.theta
    }
    set azimuthAngle(e) {
        this._spherical.theta === e && this._sphericalEnd.theta === e || (this._spherical.theta = e, this._sphericalEnd.theta = e, this._needsUpdate = !0)
    }
    get polarAngle() {
        return this._spherical.phi
    }
    set polarAngle(e) {
        this._spherical.phi === e && this._sphericalEnd.phi === e || (this._spherical.phi = e, this._sphericalEnd.phi = e, this._needsUpdate = !0)
    }
    get boundaryEnclosesCamera() {
        return this._boundaryEnclosesCamera
    }
    set boundaryEnclosesCamera(e) {
        this._boundaryEnclosesCamera = e, this._needsUpdate = !0
    }
    set interactiveArea(e) {
        this._interactiveArea.width = ye(e.width, 0, 1), this._interactiveArea.height = ye(e.height, 0, 1), this._interactiveArea.x = ye(e.x, 0, 1 - this._interactiveArea.width), this._interactiveArea.y = ye(e.y, 0, 1 - this._interactiveArea.height)
    }
    addEventListener(e, t) {
        super.addEventListener(e, t)
    }
    removeEventListener(e, t) {
        super.removeEventListener(e, t)
    }
    rotate(e, t, i = !1) {
        return this.rotateTo(this._sphericalEnd.theta + e, this._sphericalEnd.phi + t, i)
    }
    rotateAzimuthTo(e, t = !1) {
        return this.rotateTo(e, this._sphericalEnd.phi, t)
    }
    rotatePolarTo(e, t = !1) {
        return this.rotateTo(this._sphericalEnd.theta, e, t)
    }
    rotateTo(e, t, i = !1) {
        this._isUserControllingRotate = !1;
        const n = ye(e, this.minAzimuthAngle, this.maxAzimuthAngle),
            r = ye(t, this.minPolarAngle, this.maxPolarAngle);
        this._sphericalEnd.theta = n, this._sphericalEnd.phi = r, this._sphericalEnd.makeSafe(), this._needsUpdate = !0, i || (this._spherical.theta = this._sphericalEnd.theta, this._spherical.phi = this._sphericalEnd.phi);
        const o = !i || Y(this._spherical.theta, this._sphericalEnd.theta, this.restThreshold) && Y(this._spherical.phi, this._sphericalEnd.phi, this.restThreshold);
        return this._createOnRestPromise(o)
    }
    dolly(e, t = !1) {
        return this.dollyTo(this._sphericalEnd.radius - e, t)
    }
    dollyTo(e, t = !1) {
        return this._isUserControllingDolly = !1, this._lastDollyDirection = pt.NONE, this._changedDolly = 0, this._dollyToNoClamp(ye(e, this.minDistance, this.maxDistance), t)
    }
    _dollyToNoClamp(e, t = !1) {
        const i = this._sphericalEnd.radius;
        if (this.colliderMeshes.length >= 1) {
            const o = this._collisionTest(),
                a = Y(o, this._spherical.radius);
            if (!(i > e) && a) return Promise.resolve();
            this._sphericalEnd.radius = Math.min(e, o)
        } else this._sphericalEnd.radius = e;
        this._needsUpdate = !0, t || (this._spherical.radius = this._sphericalEnd.radius);
        const r = !t || Y(this._spherical.radius, this._sphericalEnd.radius, this.restThreshold);
        return this._createOnRestPromise(r)
    }
    dollyInFixed(e, t = !1) {
        this._targetEnd.add(this._getCameraDirection(Pt).multiplyScalar(e)), t || this._target.copy(this._targetEnd);
        const i = !t || Y(this._target.x, this._targetEnd.x, this.restThreshold) && Y(this._target.y, this._targetEnd.y, this.restThreshold) && Y(this._target.z, this._targetEnd.z, this.restThreshold);
        return this._createOnRestPromise(i)
    }
    zoom(e, t = !1) {
        return this.zoomTo(this._zoomEnd + e, t)
    }
    zoomTo(e, t = !1) {
        this._isUserControllingZoom = !1, this._zoomEnd = ye(e, this.minZoom, this.maxZoom), this._needsUpdate = !0, t || (this._zoom = this._zoomEnd);
        const i = !t || Y(this._zoom, this._zoomEnd, this.restThreshold);
        return this._changedZoom = 0, this._createOnRestPromise(i)
    }
    pan(e, t, i = !1) {
        return console.warn("`pan` has been renamed to `truck`"), this.truck(e, t, i)
    }
    truck(e, t, i = !1) {
        this._camera.updateMatrix(), xe.setFromMatrixColumn(this._camera.matrix, 0), De.setFromMatrixColumn(this._camera.matrix, 1), xe.multiplyScalar(e), De.multiplyScalar(-t);
        const n = P.copy(xe).add(De),
            r = J.copy(this._targetEnd).add(n);
        return this.moveTo(r.x, r.y, r.z, i)
    }
    forward(e, t = !1) {
        P.setFromMatrixColumn(this._camera.matrix, 0), P.crossVectors(this._camera.up, P), P.multiplyScalar(e);
        const i = J.copy(this._targetEnd).add(P);
        return this.moveTo(i.x, i.y, i.z, t)
    }
    elevate(e, t = !1) {
        return P.copy(this._camera.up).multiplyScalar(e), this.moveTo(this._targetEnd.x + P.x, this._targetEnd.y + P.y, this._targetEnd.z + P.z, t)
    }
    moveTo(e, t, i, n = !1) {
        this._isUserControllingTruck = !1;
        const r = P.set(e, t, i).sub(this._targetEnd);
        this._encloseToBoundary(this._targetEnd, r, this.boundaryFriction), this._needsUpdate = !0, n || this._target.copy(this._targetEnd);
        const o = !n || Y(this._target.x, this._targetEnd.x, this.restThreshold) && Y(this._target.y, this._targetEnd.y, this.restThreshold) && Y(this._target.z, this._targetEnd.z, this.restThreshold);
        return this._createOnRestPromise(o)
    }
    lookInDirectionOf(e, t, i, n = !1) {
        const a = P.set(e, t, i).sub(this._targetEnd).normalize().multiplyScalar(-this._sphericalEnd.radius).add(this._targetEnd);
        return this.setPosition(a.x, a.y, a.z, n)
    }
    fitToBox(e, t, {
        cover: i = !1,
        paddingLeft: n = 0,
        paddingRight: r = 0,
        paddingBottom: o = 0,
        paddingTop: a = 0
    } = {}) {
        const c = [],
            l = e.isBox3 ? gt.copy(e) : gt.setFromObject(e);
        l.isEmpty() && (console.warn("camera-controls: fitTo() cannot be used with an empty box. Aborting"), Promise.resolve());
        const u = pn(this._sphericalEnd.theta, fn),
            f = pn(this._sphericalEnd.phi, fn);
        c.push(this.rotateTo(u, f, t));
        const p = P.setFromSpherical(this._sphericalEnd).normalize(),
            A = En.setFromUnitVectors(p, zs),
            v = Y(Math.abs(p.y), 1);
        v && A.multiply(Xs.setFromAxisAngle(ls, u)), A.multiply(this._yAxisUpSpaceInverse);
        const _ = Bn.makeEmpty();
        J.copy(l.min).applyQuaternion(A), _.expandByPoint(J), J.copy(l.min).setX(l.max.x).applyQuaternion(A), _.expandByPoint(J), J.copy(l.min).setY(l.max.y).applyQuaternion(A), _.expandByPoint(J), J.copy(l.max).setZ(l.min.z).applyQuaternion(A), _.expandByPoint(J), J.copy(l.min).setZ(l.max.z).applyQuaternion(A), _.expandByPoint(J), J.copy(l.max).setY(l.min.y).applyQuaternion(A), _.expandByPoint(J), J.copy(l.max).setX(l.min.x).applyQuaternion(A), _.expandByPoint(J), J.copy(l.max).applyQuaternion(A), _.expandByPoint(J), _.min.x -= n, _.min.y -= o, _.max.x += r, _.max.y += a, A.setFromUnitVectors(zs, p), v && A.premultiply(Xs.invert()), A.premultiply(this._yAxisUpSpace);
        const T = _.getSize(P),
            g = _.getCenter(J).applyQuaternion(A);
        if (st(this._camera)) {
            const B = this.getDistanceToFitBox(T.x, T.y, T.z, i);
            c.push(this.moveTo(g.x, g.y, g.z, t)), c.push(this.dollyTo(B, t)), c.push(this.setFocalOffset(0, 0, 0, t))
        } else if (je(this._camera)) {
            const B = this._camera,
                y = B.right - B.left,
                b = B.top - B.bottom,
                S = i ? Math.max(y / T.x, b / T.y) : Math.min(y / T.x, b / T.y);
            c.push(this.moveTo(g.x, g.y, g.z, t)), c.push(this.zoomTo(S, t)), c.push(this.setFocalOffset(0, 0, 0, t))
        }
        return Promise.all(c)
    }
    fitToSphere(e, t) {
        const i = [],
            r = "isObject3D" in e ? ui.createBoundingSphere(e, Ys) : Ys.copy(e);
        if (i.push(this.moveTo(r.center.x, r.center.y, r.center.z, t)), st(this._camera)) {
            const o = this.getDistanceToFitSphere(r.radius);
            i.push(this.dollyTo(o, t))
        } else if (je(this._camera)) {
            const o = this._camera.right - this._camera.left,
                a = this._camera.top - this._camera.bottom,
                c = 2 * r.radius,
                l = Math.min(o / c, a / c);
            i.push(this.zoomTo(l, t))
        }
        return i.push(this.setFocalOffset(0, 0, 0, t)), Promise.all(i)
    }
    setLookAt(e, t, i, n, r, o, a = !1) {
        this._isUserControllingRotate = !1, this._isUserControllingDolly = !1, this._isUserControllingTruck = !1, this._lastDollyDirection = pt.NONE, this._changedDolly = 0;
        const c = J.set(n, r, o),
            l = P.set(e, t, i);
        this._targetEnd.copy(c), this._sphericalEnd.setFromVector3(l.sub(c).applyQuaternion(this._yAxisUpSpace)), this.normalizeRotations(), this._needsUpdate = !0, a || (this._target.copy(this._targetEnd), this._spherical.copy(this._sphericalEnd));
        const u = !a || Y(this._target.x, this._targetEnd.x, this.restThreshold) && Y(this._target.y, this._targetEnd.y, this.restThreshold) && Y(this._target.z, this._targetEnd.z, this.restThreshold) && Y(this._spherical.theta, this._sphericalEnd.theta, this.restThreshold) && Y(this._spherical.phi, this._sphericalEnd.phi, this.restThreshold) && Y(this._spherical.radius, this._sphericalEnd.radius, this.restThreshold);
        return this._createOnRestPromise(u)
    }
    lerpLookAt(e, t, i, n, r, o, a, c, l, u, f, p, A, v = !1) {
        this._isUserControllingRotate = !1, this._isUserControllingDolly = !1, this._isUserControllingTruck = !1, this._lastDollyDirection = pt.NONE, this._changedDolly = 0;
        const _ = P.set(n, r, o),
            T = J.set(e, t, i);
        me.setFromVector3(T.sub(_).applyQuaternion(this._yAxisUpSpace));
        const g = At.set(u, f, p),
            B = J.set(a, c, l);
        Gt.setFromVector3(B.sub(g).applyQuaternion(this._yAxisUpSpace)), this._targetEnd.copy(_.lerp(g, A));
        const y = Gt.theta - me.theta,
            b = Gt.phi - me.phi,
            S = Gt.radius - me.radius;
        this._sphericalEnd.set(me.radius + S * A, me.phi + b * A, me.theta + y * A), this.normalizeRotations(), this._needsUpdate = !0, v || (this._target.copy(this._targetEnd), this._spherical.copy(this._sphericalEnd));
        const R = !v || Y(this._target.x, this._targetEnd.x, this.restThreshold) && Y(this._target.y, this._targetEnd.y, this.restThreshold) && Y(this._target.z, this._targetEnd.z, this.restThreshold) && Y(this._spherical.theta, this._sphericalEnd.theta, this.restThreshold) && Y(this._spherical.phi, this._sphericalEnd.phi, this.restThreshold) && Y(this._spherical.radius, this._sphericalEnd.radius, this.restThreshold);
        return this._createOnRestPromise(R)
    }
    setPosition(e, t, i, n = !1) {
        return this.setLookAt(e, t, i, this._targetEnd.x, this._targetEnd.y, this._targetEnd.z, n)
    }
    setTarget(e, t, i, n = !1) {
        const r = this.getPosition(P),
            o = this.setLookAt(r.x, r.y, r.z, e, t, i, n);
        return this._sphericalEnd.phi = ye(this._sphericalEnd.phi, this.minPolarAngle, this.maxPolarAngle), o
    }
    setFocalOffset(e, t, i, n = !1) {
        this._isUserControllingOffset = !1, this._focalOffsetEnd.set(e, t, i), this._needsUpdate = !0, n || this._focalOffset.copy(this._focalOffsetEnd);
        const r = !n || Y(this._focalOffset.x, this._focalOffsetEnd.x, this.restThreshold) && Y(this._focalOffset.y, this._focalOffsetEnd.y, this.restThreshold) && Y(this._focalOffset.z, this._focalOffsetEnd.z, this.restThreshold);
        return this._createOnRestPromise(r)
    }
    setOrbitPoint(e, t, i) {
        this._camera.updateMatrixWorld(), xe.setFromMatrixColumn(this._camera.matrixWorldInverse, 0), De.setFromMatrixColumn(this._camera.matrixWorldInverse, 1), it.setFromMatrixColumn(this._camera.matrixWorldInverse, 2);
        const n = P.set(e, t, i),
            r = n.distanceTo(this._camera.position),
            o = n.sub(this._camera.position);
        xe.multiplyScalar(o.x), De.multiplyScalar(o.y), it.multiplyScalar(o.z), P.copy(xe).add(De).add(it), P.z = P.z + r, this.dollyTo(r, !1), this.setFocalOffset(-P.x, P.y, -P.z, !1), this.moveTo(e, t, i, !1)
    }
    setBoundary(e) {
        if (!e) {
            this._boundary.min.set(-1 / 0, -1 / 0, -1 / 0), this._boundary.max.set(1 / 0, 1 / 0, 1 / 0), this._needsUpdate = !0;
            return
        }
        this._boundary.copy(e), this._boundary.clampPoint(this._targetEnd, this._targetEnd), this._needsUpdate = !0
    }
    setViewport(e, t, i, n) {
        if (e === null) {
            this._viewport = null;
            return
        }
        this._viewport = this._viewport || new U.Vector4, typeof e == "number" ? this._viewport.set(e, t, i, n) : this._viewport.copy(e)
    }
    getDistanceToFitBox(e, t, i, n = !1) {
        if (Js(this._camera, "getDistanceToFitBox")) return this._spherical.radius;
        const r = e / t,
            o = this._camera.getEffectiveFOV() * Ut,
            a = this._camera.aspect;
        return ((n ? r > a : r < a) ? t : e / a) * .5 / Math.tan(o * .5) + i * .5
    }
    getDistanceToFitSphere(e) {
        if (Js(this._camera, "getDistanceToFitSphere")) return this._spherical.radius;
        const t = this._camera.getEffectiveFOV() * Ut,
            i = Math.atan(Math.tan(t * .5) * this._camera.aspect) * 2,
            n = 1 < this._camera.aspect ? t : i;
        return e / Math.sin(n * .5)
    }
    getTarget(e, t = !0) {
        return (e && e.isVector3 ? e : new U.Vector3).copy(t ? this._targetEnd : this._target)
    }
    getPosition(e, t = !0) {
        return (e && e.isVector3 ? e : new U.Vector3).setFromSpherical(t ? this._sphericalEnd : this._spherical).applyQuaternion(this._yAxisUpSpaceInverse).add(t ? this._targetEnd : this._target)
    }
    getSpherical(e, t = !0) {
        return (e || new U.Spherical).copy(t ? this._sphericalEnd : this._spherical)
    }
    getFocalOffset(e, t = !0) {
        return (e && e.isVector3 ? e : new U.Vector3).copy(t ? this._focalOffsetEnd : this._focalOffset)
    }
    normalizeRotations() {
        this._sphericalEnd.theta = this._sphericalEnd.theta % mt, this._sphericalEnd.theta < 0 && (this._sphericalEnd.theta += mt), this._spherical.theta += mt * Math.round((this._sphericalEnd.theta - this._spherical.theta) / mt)
    }
    stop() {
        this._focalOffset.copy(this._focalOffsetEnd), this._target.copy(this._targetEnd), this._spherical.copy(this._sphericalEnd), this._zoom = this._zoomEnd
    }
    reset(e = !1) {
        if (!Y(this._camera.up.x, this._cameraUp0.x) || !Y(this._camera.up.y, this._cameraUp0.y) || !Y(this._camera.up.z, this._cameraUp0.z)) {
            this._camera.up.copy(this._cameraUp0);
            const i = this.getPosition(P);
            this.updateCameraUp(), this.setPosition(i.x, i.y, i.z)
        }
        const t = [this.setLookAt(this._position0.x, this._position0.y, this._position0.z, this._target0.x, this._target0.y, this._target0.z, e), this.setFocalOffset(this._focalOffset0.x, this._focalOffset0.y, this._focalOffset0.z, e), this.zoomTo(this._zoom0, e)];
        return Promise.all(t)
    }
    saveState() {
        this._cameraUp0.copy(this._camera.up), this.getTarget(this._target0), this.getPosition(this._position0), this._zoom0 = this._zoom, this._focalOffset0.copy(this._focalOffset)
    }
    updateCameraUp() {
        this._yAxisUpSpace.setFromUnitVectors(this._camera.up, ls), this._yAxisUpSpaceInverse.copy(this._yAxisUpSpace).invert()
    }
    applyCameraUp() {
        const e = P.subVectors(this._target, this._camera.position).normalize(),
            t = J.crossVectors(e, this._camera.up);
        this._camera.up.crossVectors(t, e).normalize(), this._camera.updateMatrixWorld();
        const i = this.getPosition(P);
        this.updateCameraUp(), this.setPosition(i.x, i.y, i.z)
    }
    update(e) {
        const t = this._sphericalEnd.theta - this._spherical.theta,
            i = this._sphericalEnd.phi - this._spherical.phi,
            n = this._sphericalEnd.radius - this._spherical.radius,
            r = gn.subVectors(this._targetEnd, this._target),
            o = vn.subVectors(this._focalOffsetEnd, this._focalOffset),
            a = this._zoomEnd - this._zoom;
        if (j(t)) this._thetaVelocity.value = 0, this._spherical.theta = this._sphericalEnd.theta;
        else {
            const f = this._isUserControllingRotate ? this.draggingSmoothTime : this.smoothTime;
            this._spherical.theta = as(this._spherical.theta, this._sphericalEnd.theta, this._thetaVelocity, f, 1 / 0, e), this._needsUpdate = !0
        }
        if (j(i)) this._phiVelocity.value = 0, this._spherical.phi = this._sphericalEnd.phi;
        else {
            const f = this._isUserControllingRotate ? this.draggingSmoothTime : this.smoothTime;
            this._spherical.phi = as(this._spherical.phi, this._sphericalEnd.phi, this._phiVelocity, f, 1 / 0, e), this._needsUpdate = !0
        }
        if (j(n)) this._radiusVelocity.value = 0, this._spherical.radius = this._sphericalEnd.radius;
        else {
            const f = this._isUserControllingDolly ? this.draggingSmoothTime : this.smoothTime;
            this._spherical.radius = as(this._spherical.radius, this._sphericalEnd.radius, this._radiusVelocity, f, this.maxSpeed, e), this._needsUpdate = !0
        }
        if (j(r.x) && j(r.y) && j(r.z)) this._targetVelocity.set(0, 0, 0), this._target.copy(this._targetEnd);
        else {
            const f = this._isUserControllingTruck ? this.draggingSmoothTime : this.smoothTime;
            mn(this._target, this._targetEnd, this._targetVelocity, f, this.maxSpeed, e, this._target), this._needsUpdate = !0
        }
        if (j(o.x) && j(o.y) && j(o.z)) this._focalOffsetVelocity.set(0, 0, 0), this._focalOffset.copy(this._focalOffsetEnd);
        else {
            const f = this._isUserControllingOffset ? this.draggingSmoothTime : this.smoothTime;
            mn(this._focalOffset, this._focalOffsetEnd, this._focalOffsetVelocity, f, this.maxSpeed, e, this._focalOffset), this._needsUpdate = !0
        }
        if (j(a)) this._zoomVelocity.value = 0, this._zoom = this._zoomEnd;
        else {
            const f = this._isUserControllingZoom ? this.draggingSmoothTime : this.smoothTime;
            this._zoom = as(this._zoom, this._zoomEnd, this._zoomVelocity, f, 1 / 0, e)
        }
        if (this.dollyToCursor) {
            if (st(this._camera) && this._changedDolly !== 0) {
                const f = this._spherical.radius - this._lastDistance,
                    p = this._camera,
                    A = this._getCameraDirection(Pt),
                    v = P.copy(A).cross(p.up).normalize();
                v.lengthSq() === 0 && (v.x = 1);
                const _ = J.crossVectors(v, A),
                    T = this._sphericalEnd.radius * Math.tan(p.getEffectiveFOV() * Ut * .5),
                    B = (this._sphericalEnd.radius - f - this._sphericalEnd.radius) / this._sphericalEnd.radius,
                    y = At.copy(this._targetEnd).add(v.multiplyScalar(this._dollyControlCoord.x * T * p.aspect)).add(_.multiplyScalar(this._dollyControlCoord.y * T)),
                    b = P.copy(this._targetEnd).lerp(y, B),
                    S = this._lastDollyDirection === pt.IN && this._spherical.radius <= this.minDistance,
                    R = this._lastDollyDirection === pt.OUT && this.maxDistance <= this._spherical.radius;
                if (this.infinityDolly && (S || R)) {
                    this._sphericalEnd.radius -= f, this._spherical.radius -= f;
                    const F = J.copy(A).multiplyScalar(-f);
                    b.add(F)
                }
                this._boundary.clampPoint(b, b);
                const D = J.subVectors(b, this._targetEnd);
                this._targetEnd.copy(b), this._target.add(D), this._changedDolly -= f, j(this._changedDolly) && (this._changedDolly = 0)
            } else if (je(this._camera) && this._changedZoom !== 0) {
                const f = this._zoom - this._lastZoom,
                    p = this._camera,
                    A = P.set(this._dollyControlCoord.x, this._dollyControlCoord.y, (p.near + p.far) / (p.near - p.far)).unproject(p),
                    v = J.set(0, 0, -1).applyQuaternion(p.quaternion),
                    _ = At.copy(A).add(v.multiplyScalar(-A.dot(p.up))),
                    g = -(this._zoom - f - this._zoom) / this._zoom,
                    B = this._getCameraDirection(Pt),
                    y = this._targetEnd.dot(B),
                    b = P.copy(this._targetEnd).lerp(_, g),
                    S = b.dot(B),
                    R = B.multiplyScalar(S - y);
                b.sub(R), this._boundary.clampPoint(b, b);
                const D = J.subVectors(b, this._targetEnd);
                this._targetEnd.copy(b), this._target.add(D), this._changedZoom -= f, j(this._changedZoom) && (this._changedZoom = 0)
            }
        }
        this._camera.zoom !== this._zoom && (this._camera.zoom = this._zoom, this._camera.updateProjectionMatrix(), this._updateNearPlaneCorners(), this._needsUpdate = !0), this._dragNeedsUpdate = !0;
        const c = this._collisionTest();
        this._spherical.radius = Math.min(this._spherical.radius, c), this._spherical.makeSafe(), this._camera.position.setFromSpherical(this._spherical).applyQuaternion(this._yAxisUpSpaceInverse).add(this._target), this._camera.lookAt(this._target), (!j(this._focalOffset.x) || !j(this._focalOffset.y) || !j(this._focalOffset.z)) && (xe.setFromMatrixColumn(this._camera.matrix, 0), De.setFromMatrixColumn(this._camera.matrix, 1), it.setFromMatrixColumn(this._camera.matrix, 2), xe.multiplyScalar(this._focalOffset.x), De.multiplyScalar(-this._focalOffset.y), it.multiplyScalar(this._focalOffset.z), P.copy(xe).add(De).add(it), this._camera.position.add(P), this._camera.updateMatrixWorld()), this._boundaryEnclosesCamera && this._encloseToBoundary(this._camera.position.copy(this._target), P.setFromSpherical(this._spherical).applyQuaternion(this._yAxisUpSpaceInverse), 1);
        const u = this._needsUpdate;
        return u && !this._updatedLastTime ? (this._hasRested = !1, this.dispatchEvent({
            type: "wake"
        }), this.dispatchEvent({
            type: "update"
        })) : u ? (this.dispatchEvent({
            type: "update"
        }), j(t, this.restThreshold) && j(i, this.restThreshold) && j(n, this.restThreshold) && j(r.x, this.restThreshold) && j(r.y, this.restThreshold) && j(r.z, this.restThreshold) && j(o.x, this.restThreshold) && j(o.y, this.restThreshold) && j(o.z, this.restThreshold) && j(a, this.restThreshold) && !this._hasRested && (this._hasRested = !0, this.dispatchEvent({
            type: "rest"
        }))) : !u && this._updatedLastTime && this.dispatchEvent({
            type: "sleep"
        }), this._lastDistance = this._spherical.radius, this._lastZoom = this._zoom, this._updatedLastTime = u, this._needsUpdate = !1, u
    }
    toJSON() {
        return JSON.stringify({
            enabled: this._enabled,
            minDistance: this.minDistance,
            maxDistance: Lt(this.maxDistance),
            minZoom: this.minZoom,
            maxZoom: Lt(this.maxZoom),
            minPolarAngle: this.minPolarAngle,
            maxPolarAngle: Lt(this.maxPolarAngle),
            minAzimuthAngle: Lt(this.minAzimuthAngle),
            maxAzimuthAngle: Lt(this.maxAzimuthAngle),
            smoothTime: this.smoothTime,
            draggingSmoothTime: this.draggingSmoothTime,
            dollySpeed: this.dollySpeed,
            truckSpeed: this.truckSpeed,
            dollyToCursor: this.dollyToCursor,
            target: this._targetEnd.toArray(),
            position: P.setFromSpherical(this._sphericalEnd).add(this._targetEnd).toArray(),
            zoom: this._zoomEnd,
            focalOffset: this._focalOffsetEnd.toArray(),
            target0: this._target0.toArray(),
            position0: this._position0.toArray(),
            zoom0: this._zoom0,
            focalOffset0: this._focalOffset0.toArray()
        })
    }
    fromJSON(e, t = !1) {
        const i = JSON.parse(e);
        this.enabled = i.enabled, this.minDistance = i.minDistance, this.maxDistance = wt(i.maxDistance), this.minZoom = i.minZoom, this.maxZoom = wt(i.maxZoom), this.minPolarAngle = i.minPolarAngle, this.maxPolarAngle = wt(i.maxPolarAngle), this.minAzimuthAngle = wt(i.minAzimuthAngle), this.maxAzimuthAngle = wt(i.maxAzimuthAngle), this.smoothTime = i.smoothTime, this.draggingSmoothTime = i.draggingSmoothTime, this.dollySpeed = i.dollySpeed, this.truckSpeed = i.truckSpeed, this.dollyToCursor = i.dollyToCursor, this._target0.fromArray(i.target0), this._position0.fromArray(i.position0), this._zoom0 = i.zoom0, this._focalOffset0.fromArray(i.focalOffset0), this.moveTo(i.target[0], i.target[1], i.target[2], t), me.setFromVector3(P.fromArray(i.position).sub(this._targetEnd).applyQuaternion(this._yAxisUpSpace)), this.rotateTo(me.theta, me.phi, t), this.dollyTo(me.radius, t), this.zoomTo(i.zoom, t), this.setFocalOffset(i.focalOffset[0], i.focalOffset[1], i.focalOffset[2], t), this._needsUpdate = !0
    }
    connect(e) {
        if (this._domElement) {
            console.warn("camera-controls is already connected.");
            return
        }
        e.setAttribute("data-camera-controls-version", Ea), this._addAllEventListeners(e), this._getClientRect(this._elementRect)
    }
    disconnect() {
        this.cancel(), this._removeAllEventListeners(), this._domElement && (this._domElement.removeAttribute("data-camera-controls-version"), this._domElement = void 0)
    }
    dispose() {
        this.removeAllEventListeners(), this.disconnect()
    }
    _getTargetDirection(e) {
        return e.setFromSpherical(this._spherical).divideScalar(this._spherical.radius).applyQuaternion(this._yAxisUpSpaceInverse)
    }
    _getCameraDirection(e) {
        return this._getTargetDirection(e).negate()
    }
    _findPointerById(e) {
        return this._activePointers.find(t => t.pointerId === e)
    }
    _findPointerByMouseButton(e) {
        return this._activePointers.find(t => t.mouseButton === e)
    }
    _disposePointer(e) {
        this._activePointers.splice(this._activePointers.indexOf(e), 1)
    }
    _encloseToBoundary(e, t, i) {
        const n = t.lengthSq();
        if (n === 0) return e;
        const r = J.copy(t).add(e),
            a = this._boundary.clampPoint(r, At).sub(r),
            c = a.lengthSq();
        if (c === 0) return e.add(t);
        if (c === n) return e;
        if (i === 0) return e.add(t).add(a); {
            const l = 1 + i * c / t.dot(a);
            return e.add(J.copy(t).multiplyScalar(l)).add(a.multiplyScalar(1 - i))
        }
    }
    _updateNearPlaneCorners() {
        if (st(this._camera)) {
            const e = this._camera,
                t = e.near,
                i = e.getEffectiveFOV() * Ut,
                n = Math.tan(i * .5) * t,
                r = n * e.aspect;
            this._nearPlaneCorners[0].set(-r, -n, 0), this._nearPlaneCorners[1].set(r, -n, 0), this._nearPlaneCorners[2].set(r, n, 0), this._nearPlaneCorners[3].set(-r, n, 0)
        } else if (je(this._camera)) {
            const e = this._camera,
                t = 1 / e.zoom,
                i = e.left * t,
                n = e.right * t,
                r = e.top * t,
                o = e.bottom * t;
            this._nearPlaneCorners[0].set(i, r, 0), this._nearPlaneCorners[1].set(n, r, 0), this._nearPlaneCorners[2].set(n, o, 0), this._nearPlaneCorners[3].set(i, o, 0)
        }
    }
    _collisionTest() {
        let e = 1 / 0;
        if (!(this.colliderMeshes.length >= 1) || Js(this._camera, "_collisionTest")) return e;
        const i = this._getTargetDirection(Pt);
        js.lookAt(An, i, this._camera.up);
        for (let n = 0; n < 4; n++) {
            const r = J.copy(this._nearPlaneCorners[n]);
            r.applyMatrix4(js);
            const o = At.addVectors(this._target, r);
            hs.set(o, i), hs.far = this._spherical.radius + 1;
            const a = hs.intersectObjects(this.colliderMeshes);
            a.length !== 0 && a[0].distance < e && (e = a[0].distance)
        }
        return e
    }
    _getClientRect(e) {
        if (!this._domElement) return;
        const t = this._domElement.getBoundingClientRect();
        return e.x = t.left, e.y = t.top, this._viewport ? (e.x += this._viewport.x, e.y += t.height - this._viewport.w - this._viewport.y, e.width = this._viewport.z, e.height = this._viewport.w) : (e.width = t.width, e.height = t.height), e
    }
    _createOnRestPromise(e) {
        return e ? Promise.resolve() : (this._hasRested = !1, this.dispatchEvent({
            type: "transitionstart"
        }), new Promise(t => {
            const i = () => {
                this.removeEventListener("rest", i), t()
            };
            this.addEventListener("rest", i)
        }))
    }
    _addAllEventListeners(e) {}
    _removeAllEventListeners() {}
    get dampingFactor() {
        return console.warn(".dampingFactor has been deprecated. use smoothTime (in seconds) instead."), 0
    }
    set dampingFactor(e) {
        console.warn(".dampingFactor has been deprecated. use smoothTime (in seconds) instead.")
    }
    get draggingDampingFactor() {
        return console.warn(".draggingDampingFactor has been deprecated. use draggingSmoothTime (in seconds) instead."), 0
    }
    set draggingDampingFactor(e) {
        console.warn(".draggingDampingFactor has been deprecated. use draggingSmoothTime (in seconds) instead.")
    }
    static createBoundingSphere(e, t = new U.Sphere) {
        const i = t,
            n = i.center;
        gt.makeEmpty(), e.traverseVisible(o => {
            o.isMesh && gt.expandByObject(o)
        }), gt.getCenter(n);
        let r = 0;
        return e.traverseVisible(o => {
            if (!o.isMesh) return;
            const a = o;
            if (!a.geometry) return;
            const c = a.geometry.clone();
            c.applyMatrix4(a.matrixWorld);
            const u = c.attributes.position;
            for (let f = 0, p = u.count; f < p; f++) P.fromBufferAttribute(u, f), r = Math.max(r, n.distanceToSquared(P))
        }), i.radius = Math.sqrt(r), i
    }
};
const _a = x.forwardRef((s, e) => {
    x.useMemo(() => {
        const S = {
            Box3: Qn,
            MathUtils: {
                clamp: Ai.clamp
            },
            Matrix4: zt,
            Quaternion: pi,
            Raycaster: go,
            Sphere: Vn,
            Spherical: Ao,
            Vector2: Z,
            Vector3: Pe,
            Vector4: ci
        };
        Qs.install({
            THREE: S
        }), vi({
            CameraControlsImpl: Qs
        })
    }, []);
    const {
        camera: t,
        domElement: i,
        makeDefault: n,
        onStart: r,
        onEnd: o,
        onChange: a,
        regress: c,
        ...l
    } = s, u = X(S => S.camera), f = X(S => S.gl), p = X(S => S.invalidate), A = X(S => S.events), v = X(S => S.setEvents), _ = X(S => S.set), T = X(S => S.get), g = X(S => S.performance), B = t || u, y = i || A.connected || f.domElement, b = x.useMemo(() => new Qs(B), [B]);
    return Fe((S, R) => {
        b.enabled && b.update(R)
    }, -1), x.useEffect(() => (b.connect(y), () => {
        b.disconnect()
    }), [y, b]), x.useEffect(() => {
        const S = F => {
                p(), c && g.regress(), a && a(F)
            },
            R = F => {
                r && r(F)
            },
            D = F => {
                o && o(F)
            };
        return b.addEventListener("update", S), b.addEventListener("controlstart", R), b.addEventListener("controlend", D), b.addEventListener("control", S), b.addEventListener("transitionstart", S), b.addEventListener("wake", S), () => {
            b.removeEventListener("update", S), b.removeEventListener("controlstart", R), b.removeEventListener("controlend", D), b.removeEventListener("control", S), b.removeEventListener("transitionstart", S), b.removeEventListener("wake", S)
        }
    }, [b, r, o, p, v, c, a]), x.useEffect(() => {
        if (n) {
            const S = T().controls;
            return _({
                controls: b
            }), () => _({
                controls: S
            })
        }
    }, [n, b]), x.createElement("primitive", Xt({
        ref: e,
        object: b
    }, l))
});

function Vs(s, e, t, i) {
    return new(t || (t = Promise))((function(n, r) {
        function o(l) {
            try {
                c(i.next(l))
            } catch (u) {
                r(u)
            }
        }

        function a(l) {
            try {
                c(i.throw(l))
            } catch (u) {
                r(u)
            }
        }

        function c(l) {
            var u;
            l.done ? n(l.value) : (u = l.value, u instanceof t ? u : new t((function(f) {
                f(u)
            }))).then(o, a)
        }
        c((i = i.apply(s, [])).next())
    }))
}
const Ta = ["geforce 320m", "geforce 8600", "geforce 8600m gt", "geforce 8800 gs", "geforce 8800 gt", "geforce 9400", "geforce 9400m g", "geforce 9400m", "geforce 9600m gt", "geforce 9600m", "geforce fx go5200", "geforce gt 120", "geforce gt 130", "geforce gt 330m", "geforce gtx 285", "google swiftshader", "intel g41", "intel g45", "intel gma 4500mhd", "intel gma x3100", "intel hd 3000", "intel q45", "legacy", "mali-2", "mali-3", "mali-4", "quadro fx 1500", "quadro fx 4", "quadro fx 5", "radeon hd 2400", "radeon hd 2600", "radeon hd 4670", "radeon hd 4850", "radeon hd 4870", "radeon hd 5670", "radeon hd 5750", "radeon hd 6290", "radeon hd 6300", "radeon hd 6310", "radeon hd 6320", "radeon hd 6490m", "radeon hd 6630m", "radeon hd 6750m", "radeon hd 6770m", "radeon hd 6970m", "sgx 543", "sgx543"];

function Cn(s) {
    return s = s.toLowerCase().replace(/.*angle ?\((.+)\)(?: on vulkan [0-9.]+)?$/i, "$1").replace(/\s(\d{1,2}gb|direct3d.+$)|\(r\)| \([^)]+\)$/g, "").replace(/(?:vulkan|opengl) \d+\.\d+(?:\.\d+)?(?: \((.*)\))?/, "$1")
}
const rr = typeof window > "u",
    Oe = (() => {
        if (rr) return;
        const {
            userAgent: s,
            platform: e,
            maxTouchPoints: t
        } = window.navigator, i = /(iphone|ipod|ipad)/i.test(s), n = e === "iPad" || e === "MacIntel" && t > 0 && !window.MSStream;
        return {
            isIpad: n,
            isMobile: /android/i.test(s) || i || n,
            isSafari12: /Version\/12.+Safari/.test(s),
            isFirefox: /Firefox/.test(s)
        }
    })();

function ya(s, e, t) {
    if (!t) return [e];
    const i = (function(l) {
            const u = `
    precision highp float;
    attribute vec3 aPosition;
    varying float vvv;
    void main() {
      vvv = 0.31622776601683794;
      gl_Position = vec4(aPosition, 1.0);
    }
  `,
                f = `
    precision highp float;
    varying float vvv;
    void main() {
      vec4 enc = vec4(1.0, 255.0, 65025.0, 16581375.0) * vvv;
      enc = fract(enc);
      enc -= enc.yzww * vec4(1.0 / 255.0, 1.0 / 255.0, 1.0 / 255.0, 0.0);
      gl_FragColor = enc;
    }
  `,
                p = l.createShader(35633),
                A = l.createShader(35632),
                v = l.createProgram();
            if (!(A && p && v)) return;
            l.shaderSource(p, u), l.shaderSource(A, f), l.compileShader(p), l.compileShader(A), l.attachShader(v, p), l.attachShader(v, A), l.linkProgram(v), l.detachShader(v, p), l.detachShader(v, A), l.deleteShader(p), l.deleteShader(A), l.useProgram(v);
            const _ = l.createBuffer();
            l.bindBuffer(34962, _), l.bufferData(34962, new Float32Array([-1, -1, 0, 3, -1, 0, -1, 3, 0]), 35044);
            const T = l.getAttribLocation(v, "aPosition");
            l.vertexAttribPointer(T, 3, 5126, !1, 0, 0), l.enableVertexAttribArray(T), l.clearColor(1, 1, 1, 1), l.clear(16384), l.viewport(0, 0, 1, 1), l.drawArrays(4, 0, 3);
            const g = new Uint8Array(4);
            return l.readPixels(0, 0, 1, 1, 6408, 5121, g), l.deleteProgram(v), l.deleteBuffer(_), g.join("")
        })(s),
        n = "801621810",
        r = "8016218135",
        o = "80162181161",
        a = Oe ? .isIpad ? [
            ["a7", o, 12],
            ["a8", r, 15],
            ["a8x", r, 15],
            ["a9", r, 15],
            ["a9x", r, 15],
            ["a10", r, 15],
            ["a10x", r, 15],
            ["a12", n, 15],
            ["a12x", n, 15],
            ["a12z", n, 15],
            ["a14", n, 15],
            ["a15", n, 15],
            ["m1", n, 15],
            ["m2", n, 15]
        ] : [
            ["a7", o, 12],
            ["a8", r, 12],
            ["a9", r, 15],
            ["a10", r, 15],
            ["a11", n, 15],
            ["a12", n, 15],
            ["a13", n, 15],
            ["a14", n, 15],
            ["a15", n, 15],
            ["a16", n, 15],
            ["a17", n, 15]
        ];
    let c;
    return i === "80162181255" ? c = a.filter((([, , l]) => l >= 14)) : (c = a.filter((([, l]) => l === i)), c.length || (c = a)), c.map((([l]) => `apple ${l} gpu`))
}
let _n = class extends Error {
    constructor(e) {
        super(e), Object.setPrototypeOf(this, new.target.prototype)
    }
};
const Ws = [],
    Tn = [];

function ba(s, e) {
    if (s === e) return 0;
    const t = s;
    s.length > e.length && (s = e, e = t);
    let i = s.length,
        n = e.length;
    for (; i > 0 && s.charCodeAt(~-i) === e.charCodeAt(~-n);) i--, n--;
    let r, o = 0;
    for (; o < i && s.charCodeAt(o) === e.charCodeAt(o);) o++;
    if (i -= o, n -= o, i === 0) return n;
    let a, c, l = 0,
        u = 0,
        f = 0;
    for (; u < i;) Tn[u] = s.charCodeAt(o + u), Ws[u] = ++u;
    for (; f < n;)
        for (r = e.charCodeAt(o + f), a = f++, l = f, u = 0; u < i; u++) c = r === Tn[u] ? a : a + 1, a = Ws[u], l = Ws[u] = a > l ? c > l ? l + 1 : c : c > a ? a + 1 : c;
    return l
}

function Sa(s) {
    return s != null
}
const Ma = ({
        mobileTiers: s = [0, 15, 30, 60],
        desktopTiers: e = [0, 15, 30, 60],
        override: t = {},
        glContext: i,
        failIfMajorPerformanceCaveat: n = !1,
        benchmarksURL: r = "https://unpkg.com/detect-gpu@5.0.70/dist/benchmarks"
    } = {}) => Vs(void 0, void 0, void 0, (function*() {
        const o = {};
        if (rr) return {
            tier: 0,
            type: "SSR"
        };
        const {
            isIpad: a = !!Oe ? .isIpad,
            isMobile: c = !!Oe ? .isMobile,
            screenSize: l = window.screen,
            loadBenchmarks: u = (S => Vs(void 0, void 0, void 0, (function*() {
                const R = yield fetch(`${r}/${S}`).then((D => D.json()));
                if (parseInt(R.shift().split(".")[0], 10) < 4) throw new _n("Detect GPU benchmark data is out of date. Please update to version 4x");
                return R
            })))
        } = t;
        let {
            renderer: f
        } = t;
        const p = (S, R, D, F, w) => ({
            device: w,
            fps: F,
            gpu: D,
            isMobile: c,
            tier: S,
            type: R
        });
        let A, v = "";
        if (f) f = Cn(f), A = [f];
        else {
            const S = i || (function(D, F = !1) {
                const w = {
                    alpha: !1,
                    antialias: !1,
                    depth: !1,
                    failIfMajorPerformanceCaveat: F,
                    powerPreference: "high-performance",
                    stencil: !1
                };
                D && delete w.powerPreference;
                const z = window.document.createElement("canvas"),
                    Q = z.getContext("webgl", w) || z.getContext("experimental-webgl", w);
                return Q ? ? void 0
            })(Oe ? .isSafari12, n);
            if (!S) return p(0, "WEBGL_UNSUPPORTED");
            const R = Oe ? .isFirefox ? null : S.getExtension("WEBGL_debug_renderer_info");
            if (f = R ? S.getParameter(R.UNMASKED_RENDERER_WEBGL) : S.getParameter(S.RENDERER), !f) return p(1, "FALLBACK");
            v = f, f = Cn(f), A = (function(D, F, w) {
                return F === "apple gpu" ? ya(D, F, w) : [F]
            })(S, f, c)
        }
        const _ = (yield Promise.all(A.map((function(S) {
            var R;
            return Vs(this, void 0, void 0, (function*() {
                const D = (V => {
                    const ie = c ? ["adreno", "apple", "mali-t", "mali", "nvidia", "powervr", "samsung"] : ["intel", "apple", "amd", "radeon", "nvidia", "geforce", "adreno"];
                    for (const _e of ie)
                        if (V.includes(_e)) return _e
                })(S);
                if (!D) return;
                const F = `${c?"m":"d"}-${D}${a?"-ipad":""}.json`,
                    w = o[F] = (R = o[F]) !== null && R !== void 0 ? R : u(F);
                let z;
                try {
                    z = yield w
                } catch (V) {
                    if (V instanceof _n) throw V;
                    return
                }
                const Q = (function(V) {
                    var ie;
                    const _e = (V = V.replace(/\([^)]+\)/, "")).match(/\d+/) || V.match(/(\W|^)([A-Za-z]{1,3})(\W|$)/g);
                    return (ie = _e ? .join("").replace(/\W|amd/g, "")) !== null && ie !== void 0 ? ie : ""
                })(S);
                let q = z.filter((([, V]) => V === Q));
                q.length || (q = z.filter((([V]) => V.includes(S))));
                const de = q.length;
                if (de === 0) return;
                const Ee = S.split(/[.,()\[\]/\s]/g).sort().filter(((V, ie, _e) => ie === 0 || V !== _e[ie - 1])).join(" ");
                let Ce, [We, , , , jt] = de > 1 ? q.map((V => [V, ba(Ee, V[2])])).sort((([, V], [, ie]) => V - ie))[0][0] : q[0],
                    _t = Number.MAX_VALUE;
                const {
                    devicePixelRatio: Tt
                } = window, Es = l.width * Tt * l.height * Tt;
                for (const V of jt) {
                    const [ie, _e] = V, _s = ie * _e, ee = Math.abs(Es - _s);
                    ee < _t && (_t = ee, Ce = V)
                }
                if (!Ce) return;
                const [, , Cs, Ze] = Ce;
                return [_t, Cs, We, Ze]
            }))
        })))).filter(Sa).sort((([S = Number.MAX_VALUE, R], [D = Number.MAX_VALUE, F]) => S === D ? R - F : S - D));
        if (!_.length) {
            const S = Ta.find((R => f.includes(R)));
            return S ? p(0, "BLOCKLISTED", S) : p(1, "FALLBACK", `${f} (${v})`)
        }
        const [, T, g, B] = _[0];
        if (T === -1) return p(0, "BLOCKLISTED", g, T, B);
        const y = c ? s : e;
        let b = 0;
        for (let S = 0; S < y.length; S++) T >= y[S] && (b = S);
        return p(b, "BENCHMARK", g, T, B)
    })),
    or = s => vo(() => Ma(s), ["useDetectGPU"]);

function Ra(s, e, t = .9) {
    return e * t + s * (1 - t)
}
const xa = s => Math.sqrt(1 - Math.pow(s - 1, 2));
class Da {
    constructor({
        size: e = 256,
        maxAge: t = 750,
        radius: i = .3,
        intensity: n = .2,
        interpolate: r = 0,
        smoothing: o = 0,
        minForce: a = .3,
        blend: c = "screen",
        ease: l = xa
    } = {}) {
        this.size = e, this.maxAge = t, this.radius = i, this.intensity = n, this.ease = l, this.interpolate = r, this.smoothing = o, this.minForce = a, this.blend = c, this.trail = [], this.force = 0, this.initTexture()
    }
    initTexture() {
        this.canvas = document.createElement("canvas"), this.canvas.width = this.canvas.height = this.size;
        const e = this.canvas.getContext("2d");
        if (e === null) throw new Error("2D not available");
        this.ctx = e, this.ctx.fillStyle = "black", this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height), this.texture = new at(this.canvas), this.canvas.id = "touchTexture", this.canvas.style.width = this.canvas.style.height = `${this.canvas.width}px`
    }
    update(e) {
        this.clear(), this.trail.forEach((t, i) => {
            t.age += e * 1e3, t.age > this.maxAge && this.trail.splice(i, 1)
        }), this.trail.length || (this.force = 0), this.trail.forEach(t => {
            this.drawTouch(t)
        }), this.texture.needsUpdate = !0
    }
    clear() {
        this.ctx.globalCompositeOperation = "source-over", this.ctx.fillStyle = "black", this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height)
    }
    addTouch(e) {
        const t = this.trail[this.trail.length - 1];
        if (t) {
            const i = t.x - e.x,
                n = t.y - e.y,
                r = i * i + n * n,
                o = Math.max(this.minForce, Math.min(r * 1e4, 1));
            if (this.force = Ra(o, this.force, this.smoothing), this.interpolate) {
                const a = Math.ceil(r / Math.pow(this.radius * .5 / this.interpolate, 2));
                if (a > 1)
                    for (let c = 1; c < a; c++) this.trail.push({
                        x: t.x - i / a * c,
                        y: t.y - n / a * c,
                        age: 0,
                        force: o
                    })
            }
        }
        this.trail.push({
            x: e.x,
            y: e.y,
            age: 0,
            force: this.force
        })
    }
    drawTouch(e) {
        const t = {
            x: e.x * this.size,
            y: (1 - e.y) * this.size
        };
        let i = 1;
        e.age < this.maxAge * .3 ? i = this.ease(e.age / (this.maxAge * .3)) : i = this.ease(1 - (e.age - this.maxAge * .3) / (this.maxAge * .7)), i *= e.force, this.ctx.globalCompositeOperation = this.blend;
        const n = this.size * this.radius * i,
            r = this.ctx.createRadialGradient(t.x, t.y, Math.max(0, n * .25), t.x, t.y, Math.max(0, n));
        r.addColorStop(0, `rgba(255, 255, 255, ${this.intensity})`), r.addColorStop(1, "rgba(0, 0, 0, 0.0)"), this.ctx.beginPath(), this.ctx.fillStyle = r, this.ctx.arc(t.x, t.y, Math.max(0, n), 0, Math.PI * 2), this.ctx.fill()
    }
}

function Oa(s = {}) {
    const {
        size: e,
        maxAge: t,
        radius: i,
        intensity: n,
        interpolate: r,
        smoothing: o,
        minForce: a,
        blend: c,
        ease: l
    } = s, u = x.useMemo(() => new Da(s), [e, t, i, n, r, o, a, c, l]);
    Fe((p, A) => {
        u.update(A)
    });
    const f = x.useCallback(p => u.addTouch(p.uv), [u]);
    return [u.texture, f]
}

function Ia({
    all: s,
    scene: e,
    camera: t
}) {
    const i = X(({
            gl: o
        }) => o),
        n = X(({
            camera: o
        }) => o),
        r = X(({
            scene: o
        }) => o);
    return x.useLayoutEffect(() => {
        const o = [];
        s && (e || r).traverse(l => {
            l.visible === !1 && (o.push(l), l.visible = !0)
        }), i.compile(e || r, t || n);
        const a = new Bo(128);
        new Eo(.01, 1e5, a).update(i, e || r), a.dispose(), o.forEach(l => l.visible = !1)
    }, []), null
}

function Fa({
    pixelated: s
}) {
    const e = X(o => o.gl),
        t = X(o => o.internal.active),
        i = X(o => o.performance.current),
        n = X(o => o.viewport.initialDpr),
        r = X(o => o.setDpr);
    return x.useEffect(() => {
        const o = e.domElement;
        return () => {
            t && r(n), s && o && (o.style.imageRendering = "auto")
        }
    }, []), x.useEffect(() => {
        r(i * n), s && e.domElement && (e.domElement.style.imageRendering = i === 1 ? "auto" : "pixelated")
    }, [i]), null
}

function Ua() {
    const s = X(i => i.get),
        e = X(i => i.setEvents),
        t = X(i => i.performance.current);
    return x.useEffect(() => {
        const i = s().events.enabled;
        return () => e({
            enabled: i
        })
    }, []), x.useEffect(() => e({
        enabled: t === 1
    }), [t]), null
}
var La = (() => {
        const s = new Float32Array([-1, -1, 0, 3, -1, 0, -1, 3, 0]),
            e = new Float32Array([0, 0, 2, 0, 0, 2]),
            t = new mi;
        return t.setAttribute("position", new ot(s, 3)), t.setAttribute("uv", new ot(e, 2)), t
    })(),
    ue = class di {
        static get fullscreenGeometry() {
            return La
        }
        constructor(e = "Pass", t = new ji, i = new Yn) {
            this.name = e, this.renderer = null, this.scene = t, this.camera = i, this.screen = null, this.rtt = !0, this.needsSwap = !0, this.needsDepthBlit = !1, this.needsDepthTexture = !1, this.enabled = !0
        }
        get renderToScreen() {
            return !this.rtt
        }
        set renderToScreen(e) {
            if (this.rtt === e) {
                const t = this.fullscreenMaterial;
                t !== null && (t.needsUpdate = !0), this.rtt = !e
            }
        }
        set mainScene(e) {}
        set mainCamera(e) {}
        setRenderer(e) {
            this.renderer = e
        }
        isEnabled() {
            return this.enabled
        }
        setEnabled(e) {
            this.enabled = e
        }
        get fullscreenMaterial() {
            return this.screen !== null ? this.screen.material : null
        }
        set fullscreenMaterial(e) {
            let t = this.screen;
            t !== null ? t.material = e : (t = new Kn(di.fullscreenGeometry, e), t.frustumCulled = !1, this.scene === null && (this.scene = new ji), this.scene.add(t), this.screen = t)
        }
        getFullscreenMaterial() {
            return this.fullscreenMaterial
        }
        setFullscreenMaterial(e) {
            this.fullscreenMaterial = e
        }
        getDepthTexture() {
            return null
        }
        setDepthTexture(e, t = Ct) {}
        render(e, t, i, n, r) {
            throw new Error("Render method not implemented!")
        }
        setSize(e, t) {}
        initialize(e, t, i) {}
        dispose() {
            for (const e of Object.keys(this)) {
                const t = this[e];
                (t instanceof Be || t instanceof Kt || t instanceof at || t instanceof di) && this[e].dispose()
            }
            this.fullscreenMaterial !== null && this.fullscreenMaterial.dispose()
        }
    },
    wa = class extends ue {
        constructor() {
            super("ClearMaskPass", null, null), this.needsSwap = !1
        }
        render(s, e, t, i, n) {
            const r = s.state.buffers.stencil;
            r.setLocked(!1), r.setTest(!1)
        }
    },
    Pa = `#ifdef COLOR_WRITE
#include <common>
#include <dithering_pars_fragment>
#ifdef FRAMEBUFFER_PRECISION_HIGH
uniform mediump sampler2D inputBuffer;
#else
uniform lowp sampler2D inputBuffer;
#endif
#endif
#ifdef DEPTH_WRITE
#include <packing>
#ifdef GL_FRAGMENT_PRECISION_HIGH
uniform highp sampler2D depthBuffer;
#else
uniform mediump sampler2D depthBuffer;
#endif
float readDepth(const in vec2 uv){
#if DEPTH_PACKING == 3201
return unpackRGBAToDepth(texture2D(depthBuffer,uv));
#else
return texture2D(depthBuffer,uv).r;
#endif
}
#endif
#ifdef USE_WEIGHTS
uniform vec4 channelWeights;
#endif
uniform float opacity;varying vec2 vUv;void main(){
#ifdef COLOR_WRITE
vec4 texel=texture2D(inputBuffer,vUv);
#ifdef USE_WEIGHTS
texel*=channelWeights;
#endif
gl_FragColor=opacity*texel;
#ifdef COLOR_SPACE_CONVERSION
#include <colorspace_fragment>
#endif
#include <dithering_fragment>
#else
gl_FragColor=vec4(0.0);
#endif
#ifdef DEPTH_WRITE
gl_FragDepth=readDepth(vUv);
#endif
}`,
    ar = "varying vec2 vUv;void main(){vUv=position.xy*0.5+0.5;gl_Position=vec4(position.xy,1.0,1.0);}",
    cr = class extends Ne {
        constructor() {
            super({
                name: "CopyMaterial",
                defines: {
                    COLOR_SPACE_CONVERSION: "1",
                    DEPTH_PACKING: "0",
                    COLOR_WRITE: "1"
                },
                uniforms: {
                    inputBuffer: new G(null),
                    depthBuffer: new G(null),
                    channelWeights: new G(null),
                    opacity: new G(1)
                },
                blending: lt,
                toneMapped: !1,
                depthWrite: !1,
                depthTest: !1,
                fragmentShader: Pa,
                vertexShader: ar
            }), this.depthFunc = yo
        }
        get inputBuffer() {
            return this.uniforms.inputBuffer.value
        }
        set inputBuffer(s) {
            const e = s !== null;
            this.colorWrite !== e && (e ? this.defines.COLOR_WRITE = !0 : delete this.defines.COLOR_WRITE, this.colorWrite = e, this.needsUpdate = !0), this.uniforms.inputBuffer.value = s
        }
        get depthBuffer() {
            return this.uniforms.depthBuffer.value
        }
        set depthBuffer(s) {
            const e = s !== null;
            this.depthWrite !== e && (e ? this.defines.DEPTH_WRITE = !0 : delete this.defines.DEPTH_WRITE, this.depthTest = e, this.depthWrite = e, this.needsUpdate = !0), this.uniforms.depthBuffer.value = s
        }
        set depthPacking(s) {
            this.defines.DEPTH_PACKING = s.toFixed(0), this.needsUpdate = !0
        }
        get colorSpaceConversion() {
            return this.defines.COLOR_SPACE_CONVERSION !== void 0
        }
        set colorSpaceConversion(s) {
            this.colorSpaceConversion !== s && (s ? this.defines.COLOR_SPACE_CONVERSION = !0 : delete this.defines.COLOR_SPACE_CONVERSION, this.needsUpdate = !0)
        }
        get channelWeights() {
            return this.uniforms.channelWeights.value
        }
        set channelWeights(s) {
            s !== null ? (this.defines.USE_WEIGHTS = "1", this.uniforms.channelWeights.value = s) : delete this.defines.USE_WEIGHTS, this.needsUpdate = !0
        }
        setInputBuffer(s) {
            this.uniforms.inputBuffer.value = s
        }
        getOpacity(s) {
            return this.uniforms.opacity.value
        }
        setOpacity(s) {
            this.uniforms.opacity.value = s
        }
    },
    Ga = class extends ue {
        constructor(s, e = !0) {
            super("CopyPass"), this.fullscreenMaterial = new cr, this.needsSwap = !1, this.renderTarget = s, s === void 0 && (this.renderTarget = new Be(1, 1, {
                minFilter: Ve,
                magFilter: Ve,
                stencilBuffer: !1,
                depthBuffer: !1
            }), this.renderTarget.texture.name = "CopyPass.Target"), this.autoResize = e
        }
        get resize() {
            return this.autoResize
        }
        set resize(s) {
            this.autoResize = s
        }
        get texture() {
            return this.renderTarget.texture
        }
        getTexture() {
            return this.renderTarget.texture
        }
        setAutoResizeEnabled(s) {
            this.autoResize = s
        }
        render(s, e, t, i, n) {
            this.fullscreenMaterial.inputBuffer = e.texture, s.setRenderTarget(this.renderToScreen ? null : this.renderTarget), s.render(this.scene, this.camera)
        }
        setSize(s, e) {
            this.autoResize && this.renderTarget.setSize(s, e)
        }
        initialize(s, e, t) {
            t !== void 0 && (this.renderTarget.texture.type = t, t !== Qe ? this.fullscreenMaterial.defines.FRAMEBUFFER_PRECISION_HIGH = "1" : s !== null && s.outputColorSpace === ne && (this.renderTarget.texture.colorSpace = ne))
        }
    },
    yn = new ve,
    lr = class extends ue {
        constructor(s = !0, e = !0, t = !1) {
            super("ClearPass", null, null), this.needsSwap = !1, this.color = s, this.depth = e, this.stencil = t, this.overrideClearColor = null, this.overrideClearAlpha = -1
        }
        setClearFlags(s, e, t) {
            this.color = s, this.depth = e, this.stencil = t
        }
        getOverrideClearColor() {
            return this.overrideClearColor
        }
        setOverrideClearColor(s) {
            this.overrideClearColor = s
        }
        getOverrideClearAlpha() {
            return this.overrideClearAlpha
        }
        setOverrideClearAlpha(s) {
            this.overrideClearAlpha = s
        }
        render(s, e, t, i, n) {
            const r = this.overrideClearColor,
                o = this.overrideClearAlpha,
                a = s.getClearAlpha(),
                c = r !== null,
                l = o >= 0;
            c ? (s.getClearColor(yn), s.setClearColor(r, l ? o : a)) : l && s.setClearAlpha(o), s.setRenderTarget(this.renderToScreen ? null : e), s.clear(this.color, this.depth, this.stencil), c ? s.setClearColor(yn, a) : l && s.setClearAlpha(a)
        }
    },
    Ha = class extends ue {
        constructor(s, e) {
            super("MaskPass", s, e), this.needsSwap = !1, this.clearPass = new lr(!1, !1, !0), this.inverse = !1
        }
        set mainScene(s) {
            this.scene = s
        }
        set mainCamera(s) {
            this.camera = s
        }
        get inverted() {
            return this.inverse
        }
        set inverted(s) {
            this.inverse = s
        }
        get clear() {
            return this.clearPass.enabled
        }
        set clear(s) {
            this.clearPass.enabled = s
        }
        getClearPass() {
            return this.clearPass
        }
        isInverted() {
            return this.inverted
        }
        setInverted(s) {
            this.inverted = s
        }
        render(s, e, t, i, n) {
            const r = s.getContext(),
                o = s.state.buffers,
                a = this.scene,
                c = this.camera,
                l = this.clearPass,
                u = this.inverted ? 0 : 1,
                f = 1 - u;
            o.color.setMask(!1), o.depth.setMask(!1), o.color.setLocked(!0), o.depth.setLocked(!0), o.stencil.setTest(!0), o.stencil.setOp(r.REPLACE, r.REPLACE, r.REPLACE), o.stencil.setFunc(r.ALWAYS, u, 4294967295), o.stencil.setClear(f), o.stencil.setLocked(!0), this.clearPass.enabled && (this.renderToScreen ? l.render(s, null) : (l.render(s, e), l.render(s, t))), this.renderToScreen ? (s.setRenderTarget(null), s.render(a, c)) : (s.setRenderTarget(e), s.render(a, c), s.setRenderTarget(t), s.render(a, c)), o.color.setLocked(!1), o.depth.setLocked(!1), o.stencil.setLocked(!1), o.stencil.setFunc(r.EQUAL, 1, 4294967295), o.stencil.setOp(r.KEEP, r.KEEP, r.KEEP), o.stencil.setLocked(!0)
        }
    };

function Na(s, e) {
    const t = s.getContext();
    if (e <= 0 || typeof t.renderbufferStorageMultisample != "function") return 0;
    const i = t.getParameter(t.MAX_SAMPLES),
        n = Math.min(e, i);
    if (n <= 0) return 0;
    const r = t.getParameter(t.RENDERBUFFER_BINDING),
        o = t.createRenderbuffer();
    try {
        return t.bindRenderbuffer(t.RENDERBUFFER, o), t.renderbufferStorageMultisample(t.RENDERBUFFER, n, t.RGBA8, 1, 1), n
    } catch {
        return 0
    } finally {
        t.bindRenderbuffer(t.RENDERBUFFER, r), t.deleteRenderbuffer(o)
    }
}
var Zs = 1 / 1e3,
    ka = 1e3,
    Ja = class {
        constructor() {
            this.startTime = performance.now(), this.previousTime = 0, this.currentTime = 0, this._delta = 0, this._elapsed = 0, this._fixedDelta = 1e3 / 60, this.timescale = 1, this.useFixedDelta = !1, this._autoReset = !1
        }
        get autoReset() {
            return this._autoReset
        }
        set autoReset(s) {
            typeof document < "u" && document.hidden !== void 0 && (s ? document.addEventListener("visibilitychange", this) : document.removeEventListener("visibilitychange", this), this._autoReset = s)
        }
        get delta() {
            return this._delta * Zs
        }
        get fixedDelta() {
            return this._fixedDelta * Zs
        }
        set fixedDelta(s) {
            this._fixedDelta = s * ka
        }
        get elapsed() {
            return this._elapsed * Zs
        }
        update(s) {
            this.useFixedDelta ? this._delta = this.fixedDelta : (this.previousTime = this.currentTime, this.currentTime = (s !== void 0 ? s : performance.now()) - this.startTime, this._delta = this.currentTime - this.previousTime), this._delta *= this.timescale, this._elapsed += this._delta
        }
        reset() {
            this._delta = 0, this._elapsed = 0, this.currentTime = performance.now() - this.startTime
        }
        getDelta() {
            return this.delta
        }
        getElapsed() {
            return this.elapsed
        }
        handleEvent(s) {
            document.hidden || (this.currentTime = performance.now() - this.startTime)
        }
        dispose() {
            this.autoReset = !1
        }
    },
    Ka = class {
        constructor(e = null, {
            depthBuffer: t = !0,
            stencilBuffer: i = !1,
            multisampling: n = 0,
            frameBufferType: r = Qe
        } = {}) {
            this.renderer = null, this.inputBuffer = this.createBuffer(t, i, r, n), this.outputBuffer = this.inputBuffer.clone(), this.copyPass = new Ga, this.depthRenderTarget = null, this.passes = [], this.timer = new Ja, this.autoRenderToScreen = !0, this.setRenderer(e)
        }
        get stableDepthTexture() {
            return this.depthRenderTarget === null ? null : this.depthRenderTarget.depthTexture
        }
        get multisampling() {
            return this.inputBuffer.samples
        }
        set multisampling(e) {
            const t = this.renderer === null ? e : Na(this.renderer, e);
            this.multisampling !== t && (this.inputBuffer.samples = t, this.outputBuffer.samples = t, this.inputBuffer.dispose(), this.outputBuffer.dispose())
        }
        getTimer() {
            return this.timer
        }
        getRenderer() {
            return this.renderer
        }
        setRenderer(e) {
            if (this.renderer = e, e !== null) {
                const t = e.getSize(new Z),
                    i = e.getContext().getContextAttributes().alpha,
                    n = this.inputBuffer.texture.type;
                n === Qe && e.outputColorSpace === ne && (this.inputBuffer.texture.colorSpace = ne, this.outputBuffer.texture.colorSpace = ne, this.inputBuffer.dispose(), this.outputBuffer.dispose());
                const r = this.multisampling;
                this.multisampling = r, e.autoClear = !1, this.setSize(t.width, t.height);
                for (const o of this.passes) o.initialize(e, i, n)
            }
        }
        replaceRenderer(e, t = !0) {
            const i = this.renderer,
                n = i.domElement.parentNode;
            return this.setRenderer(e), t && n !== null && (n.removeChild(i.domElement), n.appendChild(e.domElement)), i
        }
        createDepthTexture() {
            const e = new ps;
            e.name = "EffectComposer.InputDepth", this.inputBuffer.stencilBuffer ? (e.format = Co, e.type = _o) : e.type = gi;
            const t = new ps;
            t.format = e.format, t.type = e.type, t.name = "EffectComposer.OutputDepth";
            const i = new ps;
            i.format = e.format, i.type = e.type, i.name = "EffectComposer.StableDepth", this.inputBuffer.depthTexture = e, this.outputBuffer.depthTexture = t, this.inputBuffer.dispose(), this.outputBuffer.dispose();
            const {
                width: n,
                height: r
            } = this.inputBuffer;
            this.depthRenderTarget = new Be(n, r, {
                depthBuffer: !0,
                stencilBuffer: this.inputBuffer.stencilBuffer,
                depthTexture: i
            })
        }
        blitDepthBuffer(e) {
            const t = this.renderer,
                i = this.depthRenderTarget,
                n = t.properties,
                r = t.getContext();
            t.setRenderTarget(i);
            const o = n.get(e).__webglFramebuffer,
                a = n.get(i).__webglFramebuffer,
                c = e.stencilBuffer ? r.DEPTH_BUFFER_BIT | r.STENCIL_BUFFER_BIT : r.DEPTH_BUFFER_BIT;
            r.bindFramebuffer(r.READ_FRAMEBUFFER, o), r.bindFramebuffer(r.DRAW_FRAMEBUFFER, a), r.blitFramebuffer(0, 0, e.width, e.height, 0, 0, i.width, i.height, c, r.NEAREST), r.bindFramebuffer(r.READ_FRAMEBUFFER, null), r.bindFramebuffer(r.DRAW_FRAMEBUFFER, null), t.setRenderTarget(null)
        }
        deleteDepthTexture() {
            const e = this.stableDepthTexture;
            for (const t of this.passes) t.getDepthTexture() === e && t.setDepthTexture(null);
            this.depthRenderTarget !== null && (this.depthRenderTarget.dispose(), this.depthRenderTarget = null), this.inputBuffer.depthTexture !== null && (this.inputBuffer.depthTexture.dispose(), this.inputBuffer.depthTexture = null), this.outputBuffer.depthTexture !== null && (this.outputBuffer.depthTexture.dispose(), this.outputBuffer.depthTexture = null)
        }
        createBuffer(e, t, i, n) {
            const r = this.renderer,
                o = r === null ? new Z : r.getDrawingBufferSize(new Z),
                a = new Be(o.width, o.height, {
                    minFilter: Ve,
                    magFilter: Ve,
                    samples: n,
                    stencilBuffer: t,
                    depthBuffer: e,
                    type: i
                });
            return i === Qe && r !== null && r.outputColorSpace === ne && (a.texture.colorSpace = ne), a.texture.name = "EffectComposer.Buffer", a.texture.generateMipmaps = !1, a
        }
        setMainScene(e) {
            for (const t of this.passes) t.mainScene = e
        }
        setMainCamera(e) {
            for (const t of this.passes) t.mainCamera = e
        }
        addPass(e, t) {
            const i = this.passes,
                n = this.renderer,
                r = n.getDrawingBufferSize(new Z),
                o = n.getContext().getContextAttributes().alpha,
                a = this.inputBuffer.texture.type;
            if (e.renderer = n, e.setSize(r.width, r.height), e.initialize(n, o, a), this.autoRenderToScreen && (i.length > 0 && (i[i.length - 1].renderToScreen = !1), e.renderToScreen && (this.autoRenderToScreen = !1)), t !== void 0 ? i.splice(t, 0, e) : i.push(e), this.autoRenderToScreen && (i[i.length - 1].renderToScreen = !0), e.needsDepthTexture || this.depthRenderTarget !== null)
                if (this.depthRenderTarget === null) {
                    this.createDepthTexture();
                    for (const c of i) c.setDepthTexture(this.stableDepthTexture)
                } else e.setDepthTexture(this.stableDepthTexture)
        }
        removePass(e) {
            const t = this.passes,
                i = t.indexOf(e);
            if (i !== -1 && t.splice(i, 1).length > 0) {
                const o = this.stableDepthTexture;
                if (o !== null) {
                    const a = (l, u) => l || u.needsDepthTexture;
                    t.reduce(a, !1) || (e.getDepthTexture() === o && e.setDepthTexture(null), this.deleteDepthTexture())
                }
                this.autoRenderToScreen && i === t.length && (e.renderToScreen = !1, t.length > 0 && (t[t.length - 1].renderToScreen = !0))
            }
        }
        removeAllPasses() {
            const e = this.passes;
            this.deleteDepthTexture(), e.length > 0 && (this.autoRenderToScreen && (e[e.length - 1].renderToScreen = !1), this.passes = [])
        }
        render(e) {
            const t = this.renderer,
                i = this.copyPass;
            let n = this.inputBuffer,
                r = this.outputBuffer,
                o, a = !1;
            e === void 0 && (this.timer.update(), e = this.timer.getDelta());
            for (const c of this.passes)
                if (c.enabled) {
                    if (c.render(t, n, r, e, a), c.needsDepthBlit && this.depthRenderTarget !== null && this.blitDepthBuffer(n), c.needsSwap) {
                        if (a) {
                            i.renderToScreen = c.renderToScreen;
                            const l = t.getContext(),
                                u = t.state.buffers.stencil;
                            u.setFunc(l.NOTEQUAL, 1, 4294967295), i.render(t, n, r, e, a), u.setFunc(l.EQUAL, 1, 4294967295)
                        }
                        o = n, n = r, r = o
                    }
                    c instanceof Ha ? a = !0 : c instanceof wa && (a = !1)
                }
        }
        setSize(e, t, i) {
            const n = this.renderer,
                r = n.getSize(new Z);
            (e === void 0 || t === void 0) && (e = r.width, t = r.height), (r.width !== e || r.height !== t) && n.setSize(e, t, i);
            const o = n.getDrawingBufferSize(new Z);
            this.inputBuffer.setSize(o.width, o.height), this.outputBuffer.setSize(o.width, o.height), this.depthRenderTarget !== null && this.depthRenderTarget.setSize(o.width, o.height);
            for (const a of this.passes) a.setSize(o.width, o.height)
        }
        reset() {
            this.dispose(), this.autoRenderToScreen = !0
        }
        dispose() {
            for (const e of this.passes) e.dispose();
            this.deleteDepthTexture(), this.inputBuffer.dispose(), this.outputBuffer.dispose(), this.copyPass.dispose(), this.timer.dispose(), this.passes = [], ue.fullscreenGeometry.dispose()
        }
    },
    He = {
        NONE: 0,
        DEPTH: 1,
        CONVOLUTION: 2
    },
    K = {
        FRAGMENT_HEAD: "FRAGMENT_HEAD",
        FRAGMENT_MAIN_UV: "FRAGMENT_MAIN_UV",
        FRAGMENT_MAIN_IMAGE: "FRAGMENT_MAIN_IMAGE",
        VERTEX_HEAD: "VERTEX_HEAD",
        VERTEX_MAIN_SUPPORT: "VERTEX_MAIN_SUPPORT"
    },
    za = class {
        constructor() {
            this.shaderParts = new Map([
                [K.FRAGMENT_HEAD, null],
                [K.FRAGMENT_MAIN_UV, null],
                [K.FRAGMENT_MAIN_IMAGE, null],
                [K.VERTEX_HEAD, null],
                [K.VERTEX_MAIN_SUPPORT, null]
            ]), this.defines = new Map, this.uniforms = new Map, this.blendModes = new Map, this.extensions = new Set, this.attributes = He.NONE, this.varyings = new Set, this.uvTransformation = !1, this.readDepth = !1, this.colorSpace = Zn
        }
    },
    qs = !1,
    bn = class {
        constructor(s = null) {
            this.originalMaterials = new Map, this.material = null, this.materials = null, this.materialsBackSide = null, this.materialsDoubleSide = null, this.materialsFlatShaded = null, this.materialsFlatShadedBackSide = null, this.materialsFlatShadedDoubleSide = null, this.setMaterial(s), this.meshCount = 0, this.replaceMaterial = e => {
                if (e.isMesh) {
                    let t;
                    if (e.material.flatShading) switch (e.material.side) {
                        case Nt:
                            t = this.materialsFlatShadedDoubleSide;
                            break;
                        case ns:
                            t = this.materialsFlatShadedBackSide;
                            break;
                        default:
                            t = this.materialsFlatShaded;
                            break
                    } else switch (e.material.side) {
                        case Nt:
                            t = this.materialsDoubleSide;
                            break;
                        case ns:
                            t = this.materialsBackSide;
                            break;
                        default:
                            t = this.materials;
                            break
                    }
                    this.originalMaterials.set(e, e.material), e.isSkinnedMesh ? e.material = t[2] : e.isInstancedMesh ? e.material = t[1] : e.material = t[0], ++this.meshCount
                }
            }
        }
        cloneMaterial(s) {
            if (!(s instanceof Ne)) return s.clone();
            const e = s.uniforms,
                t = new Map;
            for (const n in e) {
                const r = e[n].value;
                r.isRenderTargetTexture && (e[n].value = null, t.set(n, r))
            }
            const i = s.clone();
            for (const n of t) e[n[0]].value = n[1], i.uniforms[n[0]].value = n[1];
            return i
        }
        setMaterial(s) {
            if (this.disposeMaterials(), this.material = s, s !== null) {
                const e = this.materials = [this.cloneMaterial(s), this.cloneMaterial(s), this.cloneMaterial(s)];
                for (const t of e) t.uniforms = Object.assign({}, s.uniforms), t.side = jn;
                e[2].skinning = !0, this.materialsBackSide = e.map(t => {
                    const i = this.cloneMaterial(t);
                    return i.uniforms = Object.assign({}, s.uniforms), i.side = ns, i
                }), this.materialsDoubleSide = e.map(t => {
                    const i = this.cloneMaterial(t);
                    return i.uniforms = Object.assign({}, s.uniforms), i.side = Nt, i
                }), this.materialsFlatShaded = e.map(t => {
                    const i = this.cloneMaterial(t);
                    return i.uniforms = Object.assign({}, s.uniforms), i.flatShading = !0, i
                }), this.materialsFlatShadedBackSide = e.map(t => {
                    const i = this.cloneMaterial(t);
                    return i.uniforms = Object.assign({}, s.uniforms), i.flatShading = !0, i.side = ns, i
                }), this.materialsFlatShadedDoubleSide = e.map(t => {
                    const i = this.cloneMaterial(t);
                    return i.uniforms = Object.assign({}, s.uniforms), i.flatShading = !0, i.side = Nt, i
                })
            }
        }
        render(s, e, t) {
            const i = s.shadowMap.enabled;
            if (s.shadowMap.enabled = !1, qs) {
                const n = this.originalMaterials;
                this.meshCount = 0, e.traverse(this.replaceMaterial), s.render(e, t);
                for (const r of n) r[0].material = r[1];
                this.meshCount !== n.size && n.clear()
            } else {
                const n = e.overrideMaterial;
                e.overrideMaterial = this.material, s.render(e, t), e.overrideMaterial = n
            }
            s.shadowMap.enabled = i
        }
        disposeMaterials() {
            if (this.material !== null) {
                const s = this.materials.concat(this.materialsBackSide).concat(this.materialsDoubleSide).concat(this.materialsFlatShaded).concat(this.materialsFlatShadedBackSide).concat(this.materialsFlatShadedDoubleSide);
                for (const e of s) e.dispose()
            }
        }
        dispose() {
            this.originalMaterials.clear(), this.disposeMaterials()
        }
        static get workaroundEnabled() {
            return qs
        }
        static set workaroundEnabled(s) {
            qs = s
        }
    },
    Ye = -1,
    re = class extends Bi {
        constructor(s = null, e = Ye, t = Ye, i = 1) {
            super(), s !== null && this.addEventListener("change", () => s.setSize(this.baseSize.width, this.baseSize.height)), this.baseSize = new Z(1, 1), this.preferredSize = new Z(e, t), this.target = this.preferredSize, this.s = i, this.effectiveSize = new Z, this.addEventListener("change", () => this.updateEffectiveSize()), this.updateEffectiveSize()
        }
        updateEffectiveSize() {
            const s = this.baseSize,
                e = this.preferredSize,
                t = this.effectiveSize,
                i = this.scale;
            e.width !== Ye ? t.width = e.width : e.height !== Ye ? t.width = Math.round(e.height * (s.width / Math.max(s.height, 1))) : t.width = Math.round(s.width * i), e.height !== Ye ? t.height = e.height : e.width !== Ye ? t.height = Math.round(e.width / Math.max(s.width / Math.max(s.height, 1), 1)) : t.height = Math.round(s.height * i)
        }
        get width() {
            return this.effectiveSize.width
        }
        set width(s) {
            this.preferredWidth = s
        }
        get height() {
            return this.effectiveSize.height
        }
        set height(s) {
            this.preferredHeight = s
        }
        getWidth() {
            return this.width
        }
        getHeight() {
            return this.height
        }
        get scale() {
            return this.s
        }
        set scale(s) {
            this.s !== s && (this.s = s, this.preferredSize.setScalar(Ye), this.dispatchEvent({
                type: "change"
            }))
        }
        getScale() {
            return this.scale
        }
        setScale(s) {
            this.scale = s
        }
        get baseWidth() {
            return this.baseSize.width
        }
        set baseWidth(s) {
            this.baseSize.width !== s && (this.baseSize.width = s, this.dispatchEvent({
                type: "change"
            }))
        }
        getBaseWidth() {
            return this.baseWidth
        }
        setBaseWidth(s) {
            this.baseWidth = s
        }
        get baseHeight() {
            return this.baseSize.height
        }
        set baseHeight(s) {
            this.baseSize.height !== s && (this.baseSize.height = s, this.dispatchEvent({
                type: "change"
            }))
        }
        getBaseHeight() {
            return this.baseHeight
        }
        setBaseHeight(s) {
            this.baseHeight = s
        }
        setBaseSize(s, e) {
            (this.baseSize.width !== s || this.baseSize.height !== e) && (this.baseSize.set(s, e), this.dispatchEvent({
                type: "change"
            }))
        }
        get preferredWidth() {
            return this.preferredSize.width
        }
        set preferredWidth(s) {
            this.preferredSize.width !== s && (this.preferredSize.width = s, this.dispatchEvent({
                type: "change"
            }))
        }
        getPreferredWidth() {
            return this.preferredWidth
        }
        setPreferredWidth(s) {
            this.preferredWidth = s
        }
        get preferredHeight() {
            return this.preferredSize.height
        }
        set preferredHeight(s) {
            this.preferredSize.height !== s && (this.preferredSize.height = s, this.dispatchEvent({
                type: "change"
            }))
        }
        getPreferredHeight() {
            return this.preferredHeight
        }
        setPreferredHeight(s) {
            this.preferredHeight = s
        }
        setPreferredSize(s, e) {
            (this.preferredSize.width !== s || this.preferredSize.height !== e) && (this.preferredSize.set(s, e), this.dispatchEvent({
                type: "change"
            }))
        }
        copy(s) {
            this.s = s.scale, this.baseSize.set(s.baseWidth, s.baseHeight), this.preferredSize.set(s.preferredWidth, s.preferredHeight), this.dispatchEvent({
                type: "change"
            })
        }
        static get AUTO_SIZE() {
            return Ye
        }
    },
    N = {
        ADD: 0,
        ALPHA: 1,
        AVERAGE: 2,
        COLOR: 3,
        COLOR_BURN: 4,
        COLOR_DODGE: 5,
        DARKEN: 6,
        DIFFERENCE: 7,
        DIVIDE: 8,
        DST: 9,
        EXCLUSION: 10,
        HARD_LIGHT: 11,
        HARD_MIX: 12,
        HUE: 13,
        INVERT: 14,
        INVERT_RGB: 15,
        LIGHTEN: 16,
        LINEAR_BURN: 17,
        LINEAR_DODGE: 18,
        LINEAR_LIGHT: 19,
        LUMINOSITY: 20,
        MULTIPLY: 21,
        NEGATION: 22,
        NORMAL: 23,
        OVERLAY: 24,
        PIN_LIGHT: 25,
        REFLECT: 26,
        SATURATION: 27,
        SCREEN: 28,
        SOFT_LIGHT: 29,
        SRC: 30,
        SUBTRACT: 31,
        VIVID_LIGHT: 32
    },
    Ya = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=dst.rgb+src.rgb;return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    Xa = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){return mix(dst,src,src.a*opacity);}",
    ja = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=(dst.rgb+src.rgb)*0.5;return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    Qa = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 a=RGBToHSL(dst.rgb);vec3 b=RGBToHSL(src.rgb);vec3 c=HSLToRGB(vec3(b.xy,a.z));return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    Va = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 a=dst.rgb,b=src.rgb;vec3 c=mix(step(0.0,b)*(1.0-min(vec3(1.0),(1.0-a)/max(b,1e-9))),vec3(1.0),step(1.0,a));return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    Wa = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 a=dst.rgb,b=src.rgb;vec3 c=step(0.0,a)*mix(min(vec3(1.0),a/max(1.0-b,1e-9)),vec3(1.0),step(1.0,b));return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    Za = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=min(dst.rgb,src.rgb);return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    qa = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=abs(dst.rgb-src.rgb);return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    $a = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=dst.rgb/max(src.rgb,1e-9);return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    ec = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=dst.rgb+src.rgb-2.0*dst.rgb*src.rgb;return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    tc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 a=min(dst.rgb,1.0);vec3 b=min(src.rgb,1.0);vec3 c=mix(2.0*a*b,1.0-2.0*(1.0-a)*(1.0-b),step(0.5,b));return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    sc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=step(1.0,dst.rgb+src.rgb);return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    ic = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 a=RGBToHSL(dst.rgb);vec3 b=RGBToHSL(src.rgb);vec3 c=HSLToRGB(vec3(b.x,a.yz));return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    nc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=max(1.0-src.rgb,0.0);return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    rc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=src.rgb*max(1.0-dst.rgb,0.0);return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    oc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=max(dst.rgb,src.rgb);return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    ac = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=clamp(src.rgb+dst.rgb-1.0,0.0,1.0);return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    cc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=min(dst.rgb+src.rgb,1.0);return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    lc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=clamp(2.0*src.rgb+dst.rgb-1.0,0.0,1.0);return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    hc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 a=RGBToHSL(dst.rgb);vec3 b=RGBToHSL(src.rgb);vec3 c=HSLToRGB(vec3(a.xy,b.z));return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    uc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=dst.rgb*src.rgb;return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    dc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=max(1.0-abs(1.0-dst.rgb-src.rgb),0.0);return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    fc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){return mix(dst,src,opacity);}",
    pc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 a=2.0*src.rgb*dst.rgb;vec3 b=1.0-2.0*(1.0-src.rgb)*(1.0-dst.rgb);vec3 c=mix(a,b,step(0.5,dst.rgb));return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    mc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 src2=2.0*src.rgb;vec3 c=mix(mix(src2,dst.rgb,step(0.5*dst.rgb,src.rgb)),max(src2-1.0,vec3(0.0)),step(dst.rgb,src2-1.0));return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    Ac = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 a=min(dst.rgb*dst.rgb/max(1.0-src.rgb,1e-9),1.0);vec3 c=mix(a,src.rgb,step(1.0,src.rgb));return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    gc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 a=RGBToHSL(dst.rgb);vec3 b=RGBToHSL(src.rgb);vec3 c=HSLToRGB(vec3(a.x,b.y,a.z));return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    vc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=dst.rgb+src.rgb-min(dst.rgb*src.rgb,1.0);return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    Bc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 src2=2.0*src.rgb;vec3 d=dst.rgb+(src2-1.0);vec3 w=step(0.5,src.rgb);vec3 a=dst.rgb-(1.0-src2)*dst.rgb*(1.0-dst.rgb);vec3 b=mix(d*(sqrt(dst.rgb)-dst.rgb),d*dst.rgb*((16.0*dst.rgb-12.0)*dst.rgb+3.0),w*(1.0-step(0.25,dst.rgb)));vec3 c=mix(a,b,w);return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    Ec = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){return src;}",
    Cc = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=max(dst.rgb-src.rgb,0.0);return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    _c = "vec4 blend(const in vec4 dst,const in vec4 src,const in float opacity){vec3 c=mix(max(1.0-min((1.0-dst.rgb)/(2.0*src.rgb),1.0),0.0),min(dst.rgb/(2.0*(1.0-src.rgb)),1.0),step(0.5,src.rgb));return mix(dst,vec4(c,max(dst.a,src.a)),opacity);}",
    Tc = new Map([
        [N.ADD, Ya],
        [N.ALPHA, Xa],
        [N.AVERAGE, ja],
        [N.COLOR, Qa],
        [N.COLOR_BURN, Va],
        [N.COLOR_DODGE, Wa],
        [N.DARKEN, Za],
        [N.DIFFERENCE, qa],
        [N.DIVIDE, $a],
        [N.DST, null],
        [N.EXCLUSION, ec],
        [N.HARD_LIGHT, tc],
        [N.HARD_MIX, sc],
        [N.HUE, ic],
        [N.INVERT, nc],
        [N.INVERT_RGB, rc],
        [N.LIGHTEN, oc],
        [N.LINEAR_BURN, ac],
        [N.LINEAR_DODGE, cc],
        [N.LINEAR_LIGHT, lc],
        [N.LUMINOSITY, hc],
        [N.MULTIPLY, uc],
        [N.NEGATION, dc],
        [N.NORMAL, fc],
        [N.OVERLAY, pc],
        [N.PIN_LIGHT, mc],
        [N.REFLECT, Ac],
        [N.SATURATION, gc],
        [N.SCREEN, vc],
        [N.SOFT_LIGHT, Bc],
        [N.SRC, Ec],
        [N.SUBTRACT, Cc],
        [N.VIVID_LIGHT, _c]
    ]),
    yc = class extends Bi {
        constructor(s, e = 1) {
            super(), this._blendFunction = s, this.opacity = new G(e)
        }
        getOpacity() {
            return this.opacity.value
        }
        setOpacity(s) {
            this.opacity.value = s
        }
        get blendFunction() {
            return this._blendFunction
        }
        set blendFunction(s) {
            this._blendFunction = s, this.dispatchEvent({
                type: "change"
            })
        }
        getBlendFunction() {
            return this.blendFunction
        }
        setBlendFunction(s) {
            this.blendFunction = s
        }
        getShaderCode() {
            return Tc.get(this.blendFunction)
        }
    },
    Et = class extends Bi {
        constructor(s, e, {
            attributes: t = He.NONE,
            blendFunction: i = N.NORMAL,
            defines: n = new Map,
            uniforms: r = new Map,
            extensions: o = null,
            vertexShader: a = null
        } = {}) {
            super(), this.name = s, this.renderer = null, this.attributes = t, this.fragmentShader = e, this.vertexShader = a, this.defines = n, this.uniforms = r, this.extensions = o, this.blendMode = new yc(i), this.blendMode.addEventListener("change", c => this.setChanged()), this._inputColorSpace = Zn, this._outputColorSpace = qn
        }
        get inputColorSpace() {
            return this._inputColorSpace
        }
        set inputColorSpace(s) {
            this._inputColorSpace = s, this.setChanged()
        }
        get outputColorSpace() {
            return this._outputColorSpace
        }
        set outputColorSpace(s) {
            this._outputColorSpace = s, this.setChanged()
        }
        set mainScene(s) {}
        set mainCamera(s) {}
        getName() {
            return this.name
        }
        setRenderer(s) {
            this.renderer = s
        }
        getDefines() {
            return this.defines
        }
        getUniforms() {
            return this.uniforms
        }
        getExtensions() {
            return this.extensions
        }
        getBlendMode() {
            return this.blendMode
        }
        getAttributes() {
            return this.attributes
        }
        setAttributes(s) {
            this.attributes = s, this.setChanged()
        }
        getFragmentShader() {
            return this.fragmentShader
        }
        setFragmentShader(s) {
            this.fragmentShader = s, this.setChanged()
        }
        getVertexShader() {
            return this.vertexShader
        }
        setVertexShader(s) {
            this.vertexShader = s, this.setChanged()
        }
        setChanged() {
            this.dispatchEvent({
                type: "change"
            })
        }
        setDepthTexture(s, e = Ct) {}
        update(s, e, t) {}
        setSize(s, e) {}
        initialize(s, e, t) {}
        dispose() {
            for (const s of Object.keys(this)) {
                const e = this[s];
                (e instanceof Be || e instanceof Kt || e instanceof at || e instanceof ue) && this[s].dispose()
            }
        }
    },
    yi = {
        MEDIUM: 2,
        LARGE: 3
    },
    bc = `#ifdef FRAMEBUFFER_PRECISION_HIGH
uniform mediump sampler2D inputBuffer;
#else
uniform lowp sampler2D inputBuffer;
#endif
varying vec2 vUv0;varying vec2 vUv1;varying vec2 vUv2;varying vec2 vUv3;void main(){vec4 sum=texture2D(inputBuffer,vUv0);sum+=texture2D(inputBuffer,vUv1);sum+=texture2D(inputBuffer,vUv2);sum+=texture2D(inputBuffer,vUv3);gl_FragColor=sum*0.25;
#include <colorspace_fragment>
}`,
    Sc = "uniform vec4 texelSize;uniform float kernel;uniform float scale;varying vec2 vUv0;varying vec2 vUv1;varying vec2 vUv2;varying vec2 vUv3;void main(){vec2 uv=position.xy*0.5+0.5;vec2 dUv=(texelSize.xy*vec2(kernel)+texelSize.zw)*scale;vUv0=vec2(uv.x-dUv.x,uv.y+dUv.y);vUv1=vec2(uv.x+dUv.x,uv.y+dUv.y);vUv2=vec2(uv.x+dUv.x,uv.y-dUv.y);vUv3=vec2(uv.x-dUv.x,uv.y-dUv.y);gl_Position=vec4(position.xy,1.0,1.0);}",
    Mc = [new Float32Array([0, 0]), new Float32Array([0, 1, 1]), new Float32Array([0, 1, 1, 2]), new Float32Array([0, 1, 2, 2, 3]), new Float32Array([0, 1, 2, 3, 4, 4, 5]), new Float32Array([0, 1, 2, 3, 4, 5, 7, 8, 9, 10])],
    Rc = class extends Ne {
        constructor(s = new ci) {
            super({
                name: "KawaseBlurMaterial",
                uniforms: {
                    inputBuffer: new G(null),
                    texelSize: new G(new ci),
                    scale: new G(1),
                    kernel: new G(0)
                },
                blending: lt,
                toneMapped: !1,
                depthWrite: !1,
                depthTest: !1,
                fragmentShader: bc,
                vertexShader: Sc
            }), this.setTexelSize(s.x, s.y), this.kernelSize = yi.MEDIUM
        }
        set inputBuffer(s) {
            this.uniforms.inputBuffer.value = s
        }
        setInputBuffer(s) {
            this.inputBuffer = s
        }
        get kernelSequence() {
            return Mc[this.kernelSize]
        }
        get scale() {
            return this.uniforms.scale.value
        }
        set scale(s) {
            this.uniforms.scale.value = s
        }
        getScale() {
            return this.uniforms.scale.value
        }
        setScale(s) {
            this.uniforms.scale.value = s
        }
        getKernel() {
            return null
        }
        get kernel() {
            return this.uniforms.kernel.value
        }
        set kernel(s) {
            this.uniforms.kernel.value = s
        }
        setKernel(s) {
            this.kernel = s
        }
        setTexelSize(s, e) {
            this.uniforms.texelSize.value.set(s, e, s * .5, e * .5)
        }
        setSize(s, e) {
            const t = 1 / s,
                i = 1 / e;
            this.uniforms.texelSize.value.set(t, i, t * .5, i * .5)
        }
    },
    xc = class extends ue {
        constructor({
            kernelSize: s = yi.MEDIUM,
            resolutionScale: e = .5,
            width: t = re.AUTO_SIZE,
            height: i = re.AUTO_SIZE,
            resolutionX: n = t,
            resolutionY: r = i
        } = {}) {
            super("KawaseBlurPass"), this.renderTargetA = new Be(1, 1, {
                depthBuffer: !1
            }), this.renderTargetA.texture.name = "Blur.Target.A", this.renderTargetB = this.renderTargetA.clone(), this.renderTargetB.texture.name = "Blur.Target.B";
            const o = this.resolution = new re(this, n, r, e);
            o.addEventListener("change", a => this.setSize(o.baseWidth, o.baseHeight)), this._blurMaterial = new Rc, this._blurMaterial.kernelSize = s, this.copyMaterial = new cr
        }
        getResolution() {
            return this.resolution
        }
        get blurMaterial() {
            return this._blurMaterial
        }
        set blurMaterial(s) {
            this._blurMaterial = s
        }
        get dithering() {
            return this.copyMaterial.dithering
        }
        set dithering(s) {
            this.copyMaterial.dithering = s
        }
        get kernelSize() {
            return this.blurMaterial.kernelSize
        }
        set kernelSize(s) {
            this.blurMaterial.kernelSize = s
        }
        get width() {
            return this.resolution.width
        }
        set width(s) {
            this.resolution.preferredWidth = s
        }
        get height() {
            return this.resolution.height
        }
        set height(s) {
            this.resolution.preferredHeight = s
        }
        get scale() {
            return this.blurMaterial.scale
        }
        set scale(s) {
            this.blurMaterial.scale = s
        }
        getScale() {
            return this.blurMaterial.scale
        }
        setScale(s) {
            this.blurMaterial.scale = s
        }
        getKernelSize() {
            return this.kernelSize
        }
        setKernelSize(s) {
            this.kernelSize = s
        }
        getResolutionScale() {
            return this.resolution.scale
        }
        setResolutionScale(s) {
            this.resolution.scale = s
        }
        render(s, e, t, i, n) {
            const r = this.scene,
                o = this.camera,
                a = this.renderTargetA,
                c = this.renderTargetB,
                l = this.blurMaterial,
                u = l.kernelSequence;
            let f = e;
            this.fullscreenMaterial = l;
            for (let p = 0, A = u.length; p < A; ++p) {
                const v = (p & 1) === 0 ? a : c;
                l.kernel = u[p], l.inputBuffer = f.texture, s.setRenderTarget(v), s.render(r, o), f = v
            }
            this.fullscreenMaterial = this.copyMaterial, this.copyMaterial.inputBuffer = f.texture, s.setRenderTarget(this.renderToScreen ? null : t), s.render(r, o)
        }
        setSize(s, e) {
            const t = this.resolution;
            t.setBaseSize(s, e);
            const i = t.width,
                n = t.height;
            this.renderTargetA.setSize(i, n), this.renderTargetB.setSize(i, n), this.blurMaterial.setSize(s, e)
        }
        initialize(s, e, t) {
            t !== void 0 && (this.renderTargetA.texture.type = t, this.renderTargetB.texture.type = t, t !== Qe ? (this.blurMaterial.defines.FRAMEBUFFER_PRECISION_HIGH = "1", this.copyMaterial.defines.FRAMEBUFFER_PRECISION_HIGH = "1") : s !== null && s.outputColorSpace === ne && (this.renderTargetA.texture.colorSpace = ne, this.renderTargetB.texture.colorSpace = ne))
        }
        static get AUTO_SIZE() {
            return re.AUTO_SIZE
        }
    },
    Dc = `#include <common>
#ifdef FRAMEBUFFER_PRECISION_HIGH
uniform mediump sampler2D inputBuffer;
#else
uniform lowp sampler2D inputBuffer;
#endif
#ifdef RANGE
uniform vec2 range;
#elif defined(THRESHOLD)
uniform float threshold;uniform float smoothing;
#endif
varying vec2 vUv;void main(){vec4 texel=texture2D(inputBuffer,vUv);float l=luminance(texel.rgb);float mask=1.0;
#ifdef RANGE
float low=step(range.x,l);float high=step(l,range.y);mask=low*high;
#elif defined(THRESHOLD)
mask=smoothstep(threshold,threshold+smoothing,l);
#endif
#ifdef COLOR
gl_FragColor=texel*mask;
#else
gl_FragColor=vec4(l*mask);
#endif
}`,
    Oc = class extends Ne {
        constructor(s = !1, e = null) {
            super({
                name: "LuminanceMaterial",
                defines: {
                    THREE_REVISION: fi.replace(/\D+/g, "")
                },
                uniforms: {
                    inputBuffer: new G(null),
                    threshold: new G(0),
                    smoothing: new G(1),
                    range: new G(null)
                },
                blending: lt,
                toneMapped: !1,
                depthWrite: !1,
                depthTest: !1,
                fragmentShader: Dc,
                vertexShader: ar
            }), this.colorOutput = s, this.luminanceRange = e
        }
        set inputBuffer(s) {
            this.uniforms.inputBuffer.value = s
        }
        setInputBuffer(s) {
            this.uniforms.inputBuffer.value = s
        }
        get threshold() {
            return this.uniforms.threshold.value
        }
        set threshold(s) {
            this.smoothing > 0 || s > 0 ? this.defines.THRESHOLD = "1" : delete this.defines.THRESHOLD, this.uniforms.threshold.value = s
        }
        getThreshold() {
            return this.threshold
        }
        setThreshold(s) {
            this.threshold = s
        }
        get smoothing() {
            return this.uniforms.smoothing.value
        }
        set smoothing(s) {
            this.threshold > 0 || s > 0 ? this.defines.THRESHOLD = "1" : delete this.defines.THRESHOLD, this.uniforms.smoothing.value = s
        }
        getSmoothingFactor() {
            return this.smoothing
        }
        setSmoothingFactor(s) {
            this.smoothing = s
        }
        get useThreshold() {
            return this.threshold > 0 || this.smoothing > 0
        }
        set useThreshold(s) {}
        get colorOutput() {
            return this.defines.COLOR !== void 0
        }
        set colorOutput(s) {
            s ? this.defines.COLOR = "1" : delete this.defines.COLOR, this.needsUpdate = !0
        }
        isColorOutputEnabled(s) {
            return this.colorOutput
        }
        setColorOutputEnabled(s) {
            this.colorOutput = s
        }
        get useRange() {
            return this.luminanceRange !== null
        }
        set useRange(s) {
            this.luminanceRange = null
        }
        get luminanceRange() {
            return this.uniforms.range.value
        }
        set luminanceRange(s) {
            s !== null ? this.defines.RANGE = "1" : delete this.defines.RANGE, this.uniforms.range.value = s, this.needsUpdate = !0
        }
        getLuminanceRange() {
            return this.luminanceRange
        }
        setLuminanceRange(s) {
            this.luminanceRange = s
        }
    },
    Ic = class extends ue {
        constructor({
            renderTarget: s,
            luminanceRange: e,
            colorOutput: t,
            resolutionScale: i = 1,
            width: n = re.AUTO_SIZE,
            height: r = re.AUTO_SIZE,
            resolutionX: o = n,
            resolutionY: a = r
        } = {}) {
            super("LuminancePass"), this.fullscreenMaterial = new Oc(t, e), this.needsSwap = !1, this.renderTarget = s, this.renderTarget === void 0 && (this.renderTarget = new Be(1, 1, {
                depthBuffer: !1
            }), this.renderTarget.texture.name = "LuminancePass.Target");
            const c = this.resolution = new re(this, o, a, i);
            c.addEventListener("change", l => this.setSize(c.baseWidth, c.baseHeight))
        }
        get texture() {
            return this.renderTarget.texture
        }
        getTexture() {
            return this.renderTarget.texture
        }
        getResolution() {
            return this.resolution
        }
        render(s, e, t, i, n) {
            const r = this.fullscreenMaterial;
            r.inputBuffer = e.texture, s.setRenderTarget(this.renderToScreen ? null : this.renderTarget), s.render(this.scene, this.camera)
        }
        setSize(s, e) {
            const t = this.resolution;
            t.setBaseSize(s, e), this.renderTarget.setSize(t.width, t.height)
        }
        initialize(s, e, t) {
            t !== void 0 && t !== Qe && (this.renderTarget.texture.type = t, this.fullscreenMaterial.defines.FRAMEBUFFER_PRECISION_HIGH = "1")
        }
    },
    Fc = `#ifdef FRAMEBUFFER_PRECISION_HIGH
uniform mediump sampler2D inputBuffer;
#else
uniform lowp sampler2D inputBuffer;
#endif
#define WEIGHT_INNER 0.125
#define WEIGHT_OUTER 0.05556
varying vec2 vUv;varying vec2 vUv00;varying vec2 vUv01;varying vec2 vUv02;varying vec2 vUv03;varying vec2 vUv04;varying vec2 vUv05;varying vec2 vUv06;varying vec2 vUv07;varying vec2 vUv08;varying vec2 vUv09;varying vec2 vUv10;varying vec2 vUv11;float clampToBorder(const in vec2 uv){return float(uv.s>=0.0&&uv.s<=1.0&&uv.t>=0.0&&uv.t<=1.0);}void main(){vec4 c=vec4(0.0);vec4 w=WEIGHT_INNER*vec4(clampToBorder(vUv00),clampToBorder(vUv01),clampToBorder(vUv02),clampToBorder(vUv03));c+=w.x*texture2D(inputBuffer,vUv00);c+=w.y*texture2D(inputBuffer,vUv01);c+=w.z*texture2D(inputBuffer,vUv02);c+=w.w*texture2D(inputBuffer,vUv03);w=WEIGHT_OUTER*vec4(clampToBorder(vUv04),clampToBorder(vUv05),clampToBorder(vUv06),clampToBorder(vUv07));c+=w.x*texture2D(inputBuffer,vUv04);c+=w.y*texture2D(inputBuffer,vUv05);c+=w.z*texture2D(inputBuffer,vUv06);c+=w.w*texture2D(inputBuffer,vUv07);w=WEIGHT_OUTER*vec4(clampToBorder(vUv08),clampToBorder(vUv09),clampToBorder(vUv10),clampToBorder(vUv11));c+=w.x*texture2D(inputBuffer,vUv08);c+=w.y*texture2D(inputBuffer,vUv09);c+=w.z*texture2D(inputBuffer,vUv10);c+=w.w*texture2D(inputBuffer,vUv11);c+=WEIGHT_OUTER*texture2D(inputBuffer,vUv);gl_FragColor=c;
#include <colorspace_fragment>
}`,
    Uc = "uniform vec2 texelSize;varying vec2 vUv;varying vec2 vUv00;varying vec2 vUv01;varying vec2 vUv02;varying vec2 vUv03;varying vec2 vUv04;varying vec2 vUv05;varying vec2 vUv06;varying vec2 vUv07;varying vec2 vUv08;varying vec2 vUv09;varying vec2 vUv10;varying vec2 vUv11;void main(){vUv=position.xy*0.5+0.5;vUv00=vUv+texelSize*vec2(-1.0,1.0);vUv01=vUv+texelSize*vec2(1.0,1.0);vUv02=vUv+texelSize*vec2(-1.0,-1.0);vUv03=vUv+texelSize*vec2(1.0,-1.0);vUv04=vUv+texelSize*vec2(-2.0,2.0);vUv05=vUv+texelSize*vec2(0.0,2.0);vUv06=vUv+texelSize*vec2(2.0,2.0);vUv07=vUv+texelSize*vec2(-2.0,0.0);vUv08=vUv+texelSize*vec2(2.0,0.0);vUv09=vUv+texelSize*vec2(-2.0,-2.0);vUv10=vUv+texelSize*vec2(0.0,-2.0);vUv11=vUv+texelSize*vec2(2.0,-2.0);gl_Position=vec4(position.xy,1.0,1.0);}",
    Lc = class extends Ne {
        constructor() {
            super({
                name: "DownsamplingMaterial",
                uniforms: {
                    inputBuffer: new G(null),
                    texelSize: new G(new Z)
                },
                blending: lt,
                toneMapped: !1,
                depthWrite: !1,
                depthTest: !1,
                fragmentShader: Fc,
                vertexShader: Uc
            })
        }
        set inputBuffer(s) {
            this.uniforms.inputBuffer.value = s
        }
        setSize(s, e) {
            this.uniforms.texelSize.value.set(1 / s, 1 / e)
        }
    },
    wc = `#ifdef FRAMEBUFFER_PRECISION_HIGH
uniform mediump sampler2D inputBuffer;uniform mediump sampler2D supportBuffer;
#else
uniform lowp sampler2D inputBuffer;uniform lowp sampler2D supportBuffer;
#endif
uniform float radius;varying vec2 vUv;varying vec2 vUv0;varying vec2 vUv1;varying vec2 vUv2;varying vec2 vUv3;varying vec2 vUv4;varying vec2 vUv5;varying vec2 vUv6;varying vec2 vUv7;void main(){vec4 c=vec4(0.0);c+=texture2D(inputBuffer,vUv0)*0.0625;c+=texture2D(inputBuffer,vUv1)*0.125;c+=texture2D(inputBuffer,vUv2)*0.0625;c+=texture2D(inputBuffer,vUv3)*0.125;c+=texture2D(inputBuffer,vUv)*0.25;c+=texture2D(inputBuffer,vUv4)*0.125;c+=texture2D(inputBuffer,vUv5)*0.0625;c+=texture2D(inputBuffer,vUv6)*0.125;c+=texture2D(inputBuffer,vUv7)*0.0625;vec4 baseColor=texture2D(supportBuffer,vUv);gl_FragColor=mix(baseColor,c,radius);
#include <colorspace_fragment>
}`,
    Pc = "uniform vec2 texelSize;varying vec2 vUv;varying vec2 vUv0;varying vec2 vUv1;varying vec2 vUv2;varying vec2 vUv3;varying vec2 vUv4;varying vec2 vUv5;varying vec2 vUv6;varying vec2 vUv7;void main(){vUv=position.xy*0.5+0.5;vUv0=vUv+texelSize*vec2(-1.0,1.0);vUv1=vUv+texelSize*vec2(0.0,1.0);vUv2=vUv+texelSize*vec2(1.0,1.0);vUv3=vUv+texelSize*vec2(-1.0,0.0);vUv4=vUv+texelSize*vec2(1.0,0.0);vUv5=vUv+texelSize*vec2(-1.0,-1.0);vUv6=vUv+texelSize*vec2(0.0,-1.0);vUv7=vUv+texelSize*vec2(1.0,-1.0);gl_Position=vec4(position.xy,1.0,1.0);}",
    Gc = class extends Ne {
        constructor() {
            super({
                name: "UpsamplingMaterial",
                uniforms: {
                    inputBuffer: new G(null),
                    supportBuffer: new G(null),
                    texelSize: new G(new Z),
                    radius: new G(.85)
                },
                blending: lt,
                toneMapped: !1,
                depthWrite: !1,
                depthTest: !1,
                fragmentShader: wc,
                vertexShader: Pc
            })
        }
        set inputBuffer(s) {
            this.uniforms.inputBuffer.value = s
        }
        set supportBuffer(s) {
            this.uniforms.supportBuffer.value = s
        }
        get radius() {
            return this.uniforms.radius.value
        }
        set radius(s) {
            this.uniforms.radius.value = s
        }
        setSize(s, e) {
            this.uniforms.texelSize.value.set(1 / s, 1 / e)
        }
    },
    Hc = class extends ue {
        constructor() {
            super("MipmapBlurPass"), this.needsSwap = !1, this.renderTarget = new Be(1, 1, {
                depthBuffer: !1
            }), this.renderTarget.texture.name = "Upsampling.Mipmap0", this.downsamplingMipmaps = [], this.upsamplingMipmaps = [], this.downsamplingMaterial = new Lc, this.upsamplingMaterial = new Gc, this.resolution = new Z
        }
        get texture() {
            return this.renderTarget.texture
        }
        get levels() {
            return this.downsamplingMipmaps.length
        }
        set levels(s) {
            if (this.levels !== s) {
                const e = this.renderTarget;
                this.dispose(), this.downsamplingMipmaps = [], this.upsamplingMipmaps = [];
                for (let t = 0; t < s; ++t) {
                    const i = e.clone();
                    i.texture.name = "Downsampling.Mipmap" + t, this.downsamplingMipmaps.push(i)
                }
                this.upsamplingMipmaps.push(e);
                for (let t = 1, i = s - 1; t < i; ++t) {
                    const n = e.clone();
                    n.texture.name = "Upsampling.Mipmap" + t, this.upsamplingMipmaps.push(n)
                }
                this.setSize(this.resolution.x, this.resolution.y)
            }
        }
        get radius() {
            return this.upsamplingMaterial.radius
        }
        set radius(s) {
            this.upsamplingMaterial.radius = s
        }
        render(s, e, t, i, n) {
            const {
                scene: r,
                camera: o
            } = this, {
                downsamplingMaterial: a,
                upsamplingMaterial: c
            } = this, {
                downsamplingMipmaps: l,
                upsamplingMipmaps: u
            } = this;
            let f = e;
            this.fullscreenMaterial = a;
            for (let p = 0, A = l.length; p < A; ++p) {
                const v = l[p];
                a.setSize(f.width, f.height), a.inputBuffer = f.texture, s.setRenderTarget(v), s.render(r, o), f = v
            }
            this.fullscreenMaterial = c;
            for (let p = u.length - 1; p >= 0; --p) {
                const A = u[p];
                c.setSize(f.width, f.height), c.inputBuffer = f.texture, c.supportBuffer = l[p].texture, s.setRenderTarget(A), s.render(r, o), f = A
            }
        }
        setSize(s, e) {
            const t = this.resolution;
            t.set(s, e);
            let i = t.width,
                n = t.height;
            for (let r = 0, o = this.downsamplingMipmaps.length; r < o; ++r) i = Math.round(i * .5), n = Math.round(n * .5), this.downsamplingMipmaps[r].setSize(i, n), r < this.upsamplingMipmaps.length && this.upsamplingMipmaps[r].setSize(i, n)
        }
        initialize(s, e, t) {
            if (t !== void 0) {
                const i = this.downsamplingMipmaps.concat(this.upsamplingMipmaps);
                for (const n of i) n.texture.type = t;
                if (t !== Qe) this.downsamplingMaterial.defines.FRAMEBUFFER_PRECISION_HIGH = "1", this.upsamplingMaterial.defines.FRAMEBUFFER_PRECISION_HIGH = "1";
                else if (s !== null && s.outputColorSpace === ne)
                    for (const n of i) n.texture.colorSpace = ne
            }
        }
        dispose() {
            super.dispose();
            for (const s of this.downsamplingMipmaps.concat(this.upsamplingMipmaps)) s.dispose()
        }
    },
    Nc = `#ifdef FRAMEBUFFER_PRECISION_HIGH
uniform mediump sampler2D map;
#else
uniform lowp sampler2D map;
#endif
uniform float intensity;void mainImage(const in vec4 inputColor,const in vec2 uv,out vec4 outputColor){outputColor=texture2D(map,uv)*intensity;}`,
    kc = class extends Et {
        constructor({
            blendFunction: s = N.SCREEN,
            luminanceThreshold: e = 1,
            luminanceSmoothing: t = .03,
            mipmapBlur: i = !0,
            intensity: n = 1,
            radius: r = .85,
            levels: o = 8,
            kernelSize: a = yi.LARGE,
            resolutionScale: c = .5,
            width: l = re.AUTO_SIZE,
            height: u = re.AUTO_SIZE,
            resolutionX: f = l,
            resolutionY: p = u
        } = {}) {
            super("BloomEffect", Nc, {
                blendFunction: s,
                uniforms: new Map([
                    ["map", new G(null)],
                    ["intensity", new G(n)]
                ])
            }), this.renderTarget = new Be(1, 1, {
                depthBuffer: !1
            }), this.renderTarget.texture.name = "Bloom.Target", this.blurPass = new xc({
                kernelSize: a
            }), this.luminancePass = new Ic({
                colorOutput: !0
            }), this.luminanceMaterial.threshold = e, this.luminanceMaterial.smoothing = t, this.mipmapBlurPass = new Hc, this.mipmapBlurPass.enabled = i, this.mipmapBlurPass.radius = r, this.mipmapBlurPass.levels = o, this.uniforms.get("map").value = i ? this.mipmapBlurPass.texture : this.renderTarget.texture;
            const A = this.resolution = new re(this, f, p, c);
            A.addEventListener("change", v => this.setSize(A.baseWidth, A.baseHeight))
        }
        get texture() {
            return this.mipmapBlurPass.enabled ? this.mipmapBlurPass.texture : this.renderTarget.texture
        }
        getTexture() {
            return this.texture
        }
        getResolution() {
            return this.resolution
        }
        getBlurPass() {
            return this.blurPass
        }
        getLuminancePass() {
            return this.luminancePass
        }
        get luminanceMaterial() {
            return this.luminancePass.fullscreenMaterial
        }
        getLuminanceMaterial() {
            return this.luminancePass.fullscreenMaterial
        }
        get width() {
            return this.resolution.width
        }
        set width(s) {
            this.resolution.preferredWidth = s
        }
        get height() {
            return this.resolution.height
        }
        set height(s) {
            this.resolution.preferredHeight = s
        }
        get dithering() {
            return this.blurPass.dithering
        }
        set dithering(s) {
            this.blurPass.dithering = s
        }
        get kernelSize() {
            return this.blurPass.kernelSize
        }
        set kernelSize(s) {
            this.blurPass.kernelSize = s
        }
        get distinction() {
            return console.warn(this.name, "distinction was removed"), 1
        }
        set distinction(s) {
            console.warn(this.name, "distinction was removed")
        }
        get intensity() {
            return this.uniforms.get("intensity").value
        }
        set intensity(s) {
            this.uniforms.get("intensity").value = s
        }
        getIntensity() {
            return this.intensity
        }
        setIntensity(s) {
            this.intensity = s
        }
        getResolutionScale() {
            return this.resolution.scale
        }
        setResolutionScale(s) {
            this.resolution.scale = s
        }
        update(s, e, t) {
            const i = this.renderTarget,
                n = this.luminancePass;
            n.enabled ? (n.render(s, e), this.mipmapBlurPass.enabled ? this.mipmapBlurPass.render(s, n.renderTarget) : this.blurPass.render(s, n.renderTarget, i)) : this.mipmapBlurPass.enabled ? this.mipmapBlurPass.render(s, e) : this.blurPass.render(s, e, i)
        }
        setSize(s, e) {
            const t = this.resolution;
            t.setBaseSize(s, e), this.renderTarget.setSize(t.width, t.height), this.blurPass.resolution.copy(t), this.luminancePass.setSize(s, e), this.mipmapBlurPass.setSize(s, e)
        }
        initialize(s, e, t) {
            this.blurPass.initialize(s, e, t), this.luminancePass.initialize(s, e, t), this.mipmapBlurPass.initialize(s, e, t), t !== void 0 && (this.renderTarget.texture.type = t, s !== null && s.outputColorSpace === ne && (this.renderTarget.texture.colorSpace = ne))
        }
    },
    hr = class extends ue {
        constructor(s, e, t = null) {
            super("RenderPass", s, e), this.needsSwap = !1, this.needsDepthBlit = !0, this.clearPass = new lr, this.overrideMaterialManager = t === null ? null : new bn(t), this.ignoreBackground = !1, this.skipShadowMapUpdate = !1, this.selection = null
        }
        set mainScene(s) {
            this.scene = s
        }
        set mainCamera(s) {
            this.camera = s
        }
        get renderToScreen() {
            return super.renderToScreen
        }
        set renderToScreen(s) {
            super.renderToScreen = s, this.clearPass.renderToScreen = s
        }
        get overrideMaterial() {
            const s = this.overrideMaterialManager;
            return s !== null ? s.material : null
        }
        set overrideMaterial(s) {
            const e = this.overrideMaterialManager;
            s !== null ? e !== null ? e.setMaterial(s) : this.overrideMaterialManager = new bn(s) : e !== null && (e.dispose(), this.overrideMaterialManager = null)
        }
        getOverrideMaterial() {
            return this.overrideMaterial
        }
        setOverrideMaterial(s) {
            this.overrideMaterial = s
        }
        get clear() {
            return this.clearPass.enabled
        }
        set clear(s) {
            this.clearPass.enabled = s
        }
        getSelection() {
            return this.selection
        }
        setSelection(s) {
            this.selection = s
        }
        isBackgroundDisabled() {
            return this.ignoreBackground
        }
        setBackgroundDisabled(s) {
            this.ignoreBackground = s
        }
        isShadowMapDisabled() {
            return this.skipShadowMapUpdate
        }
        setShadowMapDisabled(s) {
            this.skipShadowMapUpdate = s
        }
        getClearPass() {
            return this.clearPass
        }
        render(s, e, t, i, n) {
            const r = this.scene,
                o = this.camera,
                a = this.selection,
                c = o.layers.mask,
                l = r.background,
                u = s.shadowMap.autoUpdate,
                f = this.renderToScreen ? null : e;
            a !== null && o.layers.set(a.getLayer()), this.skipShadowMapUpdate && (s.shadowMap.autoUpdate = !1), (this.ignoreBackground || this.clearPass.overrideClearColor !== null) && (r.background = null), this.clearPass.enabled && this.clearPass.render(s, e), s.setRenderTarget(f), this.overrideMaterialManager !== null ? this.overrideMaterialManager.render(s, r, o) : s.render(r, o), o.layers.mask = c, r.background = l, s.shadowMap.autoUpdate = u
        }
    },
    Jc = `#include <packing>
#ifdef GL_FRAGMENT_PRECISION_HIGH
uniform highp sampler2D depthBuffer;
#else
uniform mediump sampler2D depthBuffer;
#endif
#ifdef DOWNSAMPLE_NORMALS
uniform lowp sampler2D normalBuffer;
#endif
varying vec2 vUv0;varying vec2 vUv1;varying vec2 vUv2;varying vec2 vUv3;float readDepth(const in vec2 uv){
#if DEPTH_PACKING == 3201
return unpackRGBAToDepth(texture2D(depthBuffer,uv));
#else
return texture2D(depthBuffer,uv).r;
#endif
}int findBestDepth(const in float samples[4]){float c=(samples[0]+samples[1]+samples[2]+samples[3])*0.25;float distances[4];distances[0]=abs(c-samples[0]);distances[1]=abs(c-samples[1]);distances[2]=abs(c-samples[2]);distances[3]=abs(c-samples[3]);float maxDistance=max(max(distances[0],distances[1]),max(distances[2],distances[3]));int remaining[3];int rejected[3];int i,j,k;for(i=0,j=0,k=0;i<4;++i){if(distances[i]<maxDistance){remaining[j++]=i;}else{rejected[k++]=i;}}for(;j<3;++j){remaining[j]=rejected[--k];}vec3 s=vec3(samples[remaining[0]],samples[remaining[1]],samples[remaining[2]]);c=(s.x+s.y+s.z)/3.0;distances[0]=abs(c-s.x);distances[1]=abs(c-s.y);distances[2]=abs(c-s.z);float minDistance=min(distances[0],min(distances[1],distances[2]));for(i=0;i<3;++i){if(distances[i]==minDistance){break;}}return remaining[i];}void main(){float d[4];d[0]=readDepth(vUv0);d[1]=readDepth(vUv1);d[2]=readDepth(vUv2);d[3]=readDepth(vUv3);int index=findBestDepth(d);
#ifdef DOWNSAMPLE_NORMALS
vec3 n[4];n[0]=texture2D(normalBuffer,vUv0).rgb;n[1]=texture2D(normalBuffer,vUv1).rgb;n[2]=texture2D(normalBuffer,vUv2).rgb;n[3]=texture2D(normalBuffer,vUv3).rgb;
#else
vec3 n[4];n[0]=vec3(0.0);n[1]=vec3(0.0);n[2]=vec3(0.0);n[3]=vec3(0.0);
#endif
gl_FragColor=vec4(n[index],d[index]);}`,
    Kc = "uniform vec2 texelSize;varying vec2 vUv0;varying vec2 vUv1;varying vec2 vUv2;varying vec2 vUv3;void main(){vec2 uv=position.xy*0.5+0.5;vUv0=uv;vUv1=vec2(uv.x,uv.y+texelSize.y);vUv2=vec2(uv.x+texelSize.x,uv.y);vUv3=uv+texelSize;gl_Position=vec4(position.xy,1.0,1.0);}",
    zc = class extends Ne {
        constructor() {
            super({
                name: "DepthDownsamplingMaterial",
                defines: {
                    DEPTH_PACKING: "0"
                },
                uniforms: {
                    depthBuffer: new G(null),
                    normalBuffer: new G(null),
                    texelSize: new G(new Z)
                },
                blending: lt,
                toneMapped: !1,
                depthWrite: !1,
                depthTest: !1,
                fragmentShader: Jc,
                vertexShader: Kc
            })
        }
        set depthBuffer(s) {
            this.uniforms.depthBuffer.value = s
        }
        set depthPacking(s) {
            this.defines.DEPTH_PACKING = s.toFixed(0), this.needsUpdate = !0
        }
        setDepthBuffer(s, e = Ct) {
            this.depthBuffer = s, this.depthPacking = e
        }
        set normalBuffer(s) {
            this.uniforms.normalBuffer.value = s, s !== null ? this.defines.DOWNSAMPLE_NORMALS = "1" : delete this.defines.DOWNSAMPLE_NORMALS, this.needsUpdate = !0
        }
        setNormalBuffer(s) {
            this.normalBuffer = s
        }
        setTexelSize(s, e) {
            this.uniforms.texelSize.value.set(s, e)
        }
        setSize(s, e) {
            this.uniforms.texelSize.value.set(1 / s, 1 / e)
        }
    },
    Yc = class extends ue {
        constructor({
            normalBuffer: s = null,
            resolutionScale: e = .5,
            width: t = re.AUTO_SIZE,
            height: i = re.AUTO_SIZE,
            resolutionX: n = t,
            resolutionY: r = i
        } = {}) {
            super("DepthDownsamplingPass");
            const o = new zc;
            o.normalBuffer = s, this.fullscreenMaterial = o, this.needsDepthTexture = !0, this.needsSwap = !1, this.renderTarget = new Be(1, 1, {
                minFilter: Yt,
                magFilter: Yt,
                depthBuffer: !1,
                type: gi
            }), this.renderTarget.texture.name = "DepthDownsamplingPass.Target", this.renderTarget.texture.generateMipmaps = !1;
            const a = this.resolution = new re(this, n, r, e);
            a.addEventListener("change", c => this.setSize(a.baseWidth, a.baseHeight))
        }
        get texture() {
            return this.renderTarget.texture
        }
        getTexture() {
            return this.renderTarget.texture
        }
        getResolution() {
            return this.resolution
        }
        setDepthTexture(s, e = Ct) {
            this.fullscreenMaterial.depthBuffer = s, this.fullscreenMaterial.depthPacking = e
        }
        render(s, e, t, i, n) {
            s.setRenderTarget(this.renderToScreen ? null : this.renderTarget), s.render(this.scene, this.camera)
        }
        setSize(s, e) {
            const t = this.resolution;
            t.setBaseSize(s, e), this.renderTarget.setSize(t.width, t.height), this.fullscreenMaterial.setSize(s, e)
        }
        initialize(s, e, t) {
            const i = s.getContext();
            if (!(i.getExtension("EXT_color_buffer_float") || i.getExtension("EXT_color_buffer_half_float"))) throw new Error("Rendering to float texture is not supported.")
        }
    },
    Xc = `#include <common>
#include <packing>
#include <dithering_pars_fragment>
#define packFloatToRGBA(v) packDepthToRGBA(v)
#define unpackRGBAToFloat(v) unpackRGBAToDepth(v)
#ifdef FRAMEBUFFER_PRECISION_HIGH
uniform mediump sampler2D inputBuffer;
#else
uniform lowp sampler2D inputBuffer;
#endif
#if DEPTH_PACKING == 3201
uniform lowp sampler2D depthBuffer;
#elif defined(GL_FRAGMENT_PRECISION_HIGH)
uniform highp sampler2D depthBuffer;
#else
uniform mediump sampler2D depthBuffer;
#endif
uniform vec2 resolution;uniform vec2 texelSize;uniform float cameraNear;uniform float cameraFar;uniform float aspect;uniform float time;varying vec2 vUv;vec4 sRGBToLinear(const in vec4 value){return vec4(mix(pow(value.rgb*0.9478672986+vec3(0.0521327014),vec3(2.4)),value.rgb*0.0773993808,vec3(lessThanEqual(value.rgb,vec3(0.04045)))),value.a);}float readDepth(const in vec2 uv){
#if DEPTH_PACKING == 3201
float depth=unpackRGBAToDepth(texture2D(depthBuffer,uv));
#else
float depth=texture2D(depthBuffer,uv).r;
#endif
#if defined(USE_LOGARITHMIC_DEPTH_BUFFER) || defined(LOG_DEPTH)
float d=pow(2.0,depth*log2(cameraFar+1.0))-1.0;float a=cameraFar/(cameraFar-cameraNear);float b=cameraFar*cameraNear/(cameraNear-cameraFar);depth=a+b/d;
#elif defined(USE_REVERSED_DEPTH_BUFFER)
depth=1.0-depth;
#endif
return depth;}float getViewZ(const in float depth){
#ifdef PERSPECTIVE_CAMERA
return perspectiveDepthToViewZ(depth,cameraNear,cameraFar);
#else
return orthographicDepthToViewZ(depth,cameraNear,cameraFar);
#endif
}vec3 RGBToHCV(const in vec3 RGB){vec4 P=mix(vec4(RGB.bg,-1.0,2.0/3.0),vec4(RGB.gb,0.0,-1.0/3.0),step(RGB.b,RGB.g));vec4 Q=mix(vec4(P.xyw,RGB.r),vec4(RGB.r,P.yzx),step(P.x,RGB.r));float C=Q.x-min(Q.w,Q.y);float H=abs((Q.w-Q.y)/(6.0*C+EPSILON)+Q.z);return vec3(H,C,Q.x);}vec3 RGBToHSL(const in vec3 RGB){vec3 HCV=RGBToHCV(RGB);float L=HCV.z-HCV.y*0.5;float S=HCV.y/(1.0-abs(L*2.0-1.0)+EPSILON);return vec3(HCV.x,S,L);}vec3 HueToRGB(const in float H){float R=abs(H*6.0-3.0)-1.0;float G=2.0-abs(H*6.0-2.0);float B=2.0-abs(H*6.0-4.0);return clamp(vec3(R,G,B),0.0,1.0);}vec3 HSLToRGB(const in vec3 HSL){vec3 RGB=HueToRGB(HSL.x);float C=(1.0-abs(2.0*HSL.z-1.0))*HSL.y;return(RGB-0.5)*C+HSL.z;}FRAGMENT_HEAD void main(){FRAGMENT_MAIN_UV vec4 color0=texture2D(inputBuffer,UV);vec4 color1=vec4(0.0);FRAGMENT_MAIN_IMAGE color0.a=clamp(color0.a,0.0,1.0);gl_FragColor=color0;
#ifdef ENCODE_OUTPUT
#include <colorspace_fragment>
#endif
#include <dithering_fragment>
}`,
    jc = "uniform vec2 resolution;uniform vec2 texelSize;uniform float cameraNear;uniform float cameraFar;uniform float aspect;uniform float time;varying vec2 vUv;VERTEX_HEAD void main(){vUv=position.xy*0.5+0.5;VERTEX_MAIN_SUPPORT gl_Position=vec4(position.xy,1.0,1.0);}",
    Qc = class extends Ne {
        constructor(s, e, t, i, n = !1) {
            super({
                name: "EffectMaterial",
                defines: {
                    THREE_REVISION: fi.replace(/\D+/g, ""),
                    DEPTH_PACKING: "0",
                    ENCODE_OUTPUT: "1"
                },
                uniforms: {
                    inputBuffer: new G(null),
                    depthBuffer: new G(null),
                    resolution: new G(new Z),
                    texelSize: new G(new Z),
                    cameraNear: new G(.3),
                    cameraFar: new G(1e3),
                    aspect: new G(1),
                    time: new G(0)
                },
                blending: lt,
                toneMapped: !1,
                depthWrite: !1,
                depthTest: !1,
                dithering: n
            }), s && this.setShaderParts(s), e && this.setDefines(e), t && this.setUniforms(t), this.copyCameraSettings(i)
        }
        set inputBuffer(s) {
            this.uniforms.inputBuffer.value = s
        }
        setInputBuffer(s) {
            this.uniforms.inputBuffer.value = s
        }
        get depthBuffer() {
            return this.uniforms.depthBuffer.value
        }
        set depthBuffer(s) {
            this.uniforms.depthBuffer.value = s
        }
        get depthPacking() {
            return Number(this.defines.DEPTH_PACKING)
        }
        set depthPacking(s) {
            this.defines.DEPTH_PACKING = s.toFixed(0), this.needsUpdate = !0
        }
        setDepthBuffer(s, e = Ct) {
            this.depthBuffer = s, this.depthPacking = e
        }
        setShaderData(s) {
            this.setShaderParts(s.shaderParts), this.setDefines(s.defines), this.setUniforms(s.uniforms), this.setExtensions(s.extensions)
        }
        setShaderParts(s) {
            return this.fragmentShader = Xc.replace(K.FRAGMENT_HEAD, s.get(K.FRAGMENT_HEAD) || "").replace(K.FRAGMENT_MAIN_UV, s.get(K.FRAGMENT_MAIN_UV) || "").replace(K.FRAGMENT_MAIN_IMAGE, s.get(K.FRAGMENT_MAIN_IMAGE) || ""), this.vertexShader = jc.replace(K.VERTEX_HEAD, s.get(K.VERTEX_HEAD) || "").replace(K.VERTEX_MAIN_SUPPORT, s.get(K.VERTEX_MAIN_SUPPORT) || ""), this.needsUpdate = !0, this
        }
        setDefines(s) {
            for (const e of s.entries()) this.defines[e[0]] = e[1];
            return this.needsUpdate = !0, this
        }
        setUniforms(s) {
            for (const e of s.entries()) this.uniforms[e[0]] = e[1];
            return this
        }
        setExtensions(s) {
            this.extensions = {};
            for (const e of s) this.extensions[e] = !0;
            return this
        }
        get encodeOutput() {
            return this.defines.ENCODE_OUTPUT !== void 0
        }
        set encodeOutput(s) {
            this.encodeOutput !== s && (s ? this.defines.ENCODE_OUTPUT = "1" : delete this.defines.ENCODE_OUTPUT, this.needsUpdate = !0)
        }
        isOutputEncodingEnabled(s) {
            return this.encodeOutput
        }
        setOutputEncodingEnabled(s) {
            this.encodeOutput = s
        }
        get time() {
            return this.uniforms.time.value
        }
        set time(s) {
            this.uniforms.time.value = s
        }
        setDeltaTime(s) {
            this.uniforms.time.value += s
        }
        adoptCameraSettings(s) {
            this.copyCameraSettings(s)
        }
        copyCameraSettings(s) {
            s && (this.uniforms.cameraNear.value = s.near, this.uniforms.cameraFar.value = s.far, s instanceof zn ? this.defines.PERSPECTIVE_CAMERA = "1" : delete this.defines.PERSPECTIVE_CAMERA, this.needsUpdate = !0)
        }
        setSize(s, e) {
            const t = this.uniforms;
            t.resolution.value.set(s, e), t.texelSize.value.set(1 / s, 1 / e), t.aspect.value = s / e
        }
        static get Section() {
            return K
        }
    };

function Sn(s, e, t) {
    for (const i of e) {
        const n = "$1" + s + i.charAt(0).toUpperCase() + i.slice(1),
            r = new RegExp("([^\\.])(\\b" + i + "\\b)", "g");
        for (const o of t.entries()) o[1] !== null && t.set(o[0], o[1].replace(r, n))
    }
}

function Vc(s, e, t) {
    let i = e.getFragmentShader(),
        n = e.getVertexShader();
    const r = i !== void 0 && /mainImage/.test(i),
        o = i !== void 0 && /mainUv/.test(i);
    if (t.attributes |= e.getAttributes(), i === void 0) throw new Error(`Missing fragment shader (${e.name})`);
    if (o && (t.attributes & He.CONVOLUTION) !== 0) throw new Error(`Effects that transform UVs are incompatible with convolution effects (${e.name})`);
    if (!r && !o) throw new Error(`Could not find mainImage or mainUv function (${e.name})`); {
        const a = /\w+\s+(\w+)\([\w\s,]*\)\s*{/g,
            c = t.shaderParts;
        let l = c.get(K.FRAGMENT_HEAD) || "",
            u = c.get(K.FRAGMENT_MAIN_UV) || "",
            f = c.get(K.FRAGMENT_MAIN_IMAGE) || "",
            p = c.get(K.VERTEX_HEAD) || "",
            A = c.get(K.VERTEX_MAIN_SUPPORT) || "";
        const v = new Set,
            _ = new Set;
        if (o && (u += `	${s}MainUv(UV);
`, t.uvTransformation = !0), n !== null && /mainSupport/.test(n)) {
            const B = /mainSupport *\([\w\s]*?uv\s*?\)/.test(n);
            A += `	${s}MainSupport(`, A += B ? `vUv);
` : `);
`;
            for (const y of n.matchAll(/(?:varying\s+\w+\s+([\S\s]*?);)/g))
                for (const b of y[1].split(/\s*,\s*/)) t.varyings.add(b), v.add(b), _.add(b);
            for (const y of n.matchAll(a)) _.add(y[1])
        }
        for (const B of i.matchAll(a)) _.add(B[1]);
        for (const B of e.defines.keys()) _.add(B.replace(/\([\w\s,]*\)/g, ""));
        for (const B of e.uniforms.keys()) _.add(B);
        _.delete("while"), _.delete("for"), _.delete("if"), e.uniforms.forEach((B, y) => t.uniforms.set(s + y.charAt(0).toUpperCase() + y.slice(1), B)), e.defines.forEach((B, y) => t.defines.set(s + y.charAt(0).toUpperCase() + y.slice(1), B));
        const T = new Map([
            ["fragment", i],
            ["vertex", n]
        ]);
        Sn(s, _, t.defines), Sn(s, _, T), i = T.get("fragment"), n = T.get("vertex");
        const g = e.blendMode;
        if (t.blendModes.set(g.blendFunction, g), r) {
            e.inputColorSpace !== null && e.inputColorSpace !== t.colorSpace && (f += e.inputColorSpace === ne ? `color0 = sRGBTransferOETF(color0);
	` : `color0 = sRGBToLinear(color0);
	`), e.outputColorSpace !== qn ? t.colorSpace = e.outputColorSpace : e.inputColorSpace !== null && (t.colorSpace = e.inputColorSpace);
            const B = /MainImage *\([\w\s,]*?depth[\w\s,]*?\)/;
            f += `${s}MainImage(color0, UV, `, (t.attributes & He.DEPTH) !== 0 && B.test(i) && (f += "depth, ", t.readDepth = !0), f += `color1);
	`;
            const y = s + "BlendOpacity";
            t.uniforms.set(y, g.opacity), f += `color0 = blend${g.blendFunction}(color0, color1, ${y});

	`, l += `uniform float ${y};

`
        }
        if (l += i + `
`, n !== null && (p += n + `
`), c.set(K.FRAGMENT_HEAD, l), c.set(K.FRAGMENT_MAIN_UV, u), c.set(K.FRAGMENT_MAIN_IMAGE, f), c.set(K.VERTEX_HEAD, p), c.set(K.VERTEX_MAIN_SUPPORT, A), e.extensions !== null)
            for (const B of e.extensions) t.extensions.add(B)
    }
}
var Wc = class extends ue {
        constructor(s, ...e) {
            super("EffectPass"), this.fullscreenMaterial = new Qc(null, null, null, s), this.listener = t => this.handleEvent(t), this.effects = [], this.setEffects(e), this.skipRendering = !1, this.minTime = 1, this.maxTime = Number.POSITIVE_INFINITY, this.timeScale = 1
        }
        set mainScene(s) {
            for (const e of this.effects) e.mainScene = s
        }
        set mainCamera(s) {
            this.fullscreenMaterial.copyCameraSettings(s);
            for (const e of this.effects) e.mainCamera = s
        }
        get encodeOutput() {
            return this.fullscreenMaterial.encodeOutput
        }
        set encodeOutput(s) {
            this.fullscreenMaterial.encodeOutput = s
        }
        get dithering() {
            return this.fullscreenMaterial.dithering
        }
        set dithering(s) {
            const e = this.fullscreenMaterial;
            e.dithering = s, e.needsUpdate = !0
        }
        setEffects(s) {
            for (const e of this.effects) e.removeEventListener("change", this.listener);
            this.effects = s.sort((e, t) => t.attributes - e.attributes);
            for (const e of this.effects) e.addEventListener("change", this.listener)
        }
        updateMaterial() {
            const s = new za;
            let e = 0;
            for (const o of this.effects)
                if (o.blendMode.blendFunction === N.DST) s.attributes |= o.getAttributes() & He.DEPTH;
                else {
                    if ((s.attributes & o.getAttributes() & He.CONVOLUTION) !== 0) throw new Error(`Convolution effects cannot be merged (${o.name})`);
                    Vc("e" + e++, o, s)
                }
            let t = s.shaderParts.get(K.FRAGMENT_HEAD),
                i = s.shaderParts.get(K.FRAGMENT_MAIN_IMAGE),
                n = s.shaderParts.get(K.FRAGMENT_MAIN_UV);
            const r = /\bblend\b/g;
            for (const o of s.blendModes.values()) t += o.getShaderCode().replace(r, `blend${o.blendFunction}`) + `
`;
            (s.attributes & He.DEPTH) !== 0 ? (s.readDepth && (i = `float depth = readDepth(UV);

	` + i), this.needsDepthTexture = this.getDepthTexture() === null) : this.needsDepthTexture = !1, s.colorSpace === ne && (i += `color0 = sRGBToLinear(color0);
	`), s.uvTransformation ? (n = `vec2 transformedUv = vUv;
` + n, s.defines.set("UV", "transformedUv")) : s.defines.set("UV", "vUv"), s.shaderParts.set(K.FRAGMENT_HEAD, t), s.shaderParts.set(K.FRAGMENT_MAIN_IMAGE, i), s.shaderParts.set(K.FRAGMENT_MAIN_UV, n);
            for (const [o, a] of s.shaderParts) a !== null && s.shaderParts.set(o, a.trim().replace(/^#/, `
#`));
            this.skipRendering = e === 0, this.needsSwap = !this.skipRendering, this.fullscreenMaterial.setShaderData(s)
        }
        recompile() {
            this.updateMaterial()
        }
        getDepthTexture() {
            return this.fullscreenMaterial.depthBuffer
        }
        setDepthTexture(s, e = Ct) {
            this.fullscreenMaterial.depthBuffer = s, this.fullscreenMaterial.depthPacking = e;
            for (const t of this.effects) t.setDepthTexture(s, e)
        }
        render(s, e, t, i, n) {
            for (const r of this.effects) r.update(s, e, i);
            if (!this.skipRendering || this.renderToScreen) {
                const r = this.fullscreenMaterial;
                r.inputBuffer = e.texture, r.time += i * this.timeScale, s.setRenderTarget(this.renderToScreen ? null : t), s.render(this.scene, this.camera)
            }
        }
        setSize(s, e) {
            this.fullscreenMaterial.setSize(s, e);
            for (const t of this.effects) t.setSize(s, e)
        }
        initialize(s, e, t) {
            this.renderer = s;
            for (const i of this.effects) i.initialize(s, e, t);
            this.updateMaterial(), t !== void 0 && t !== Qe && (this.fullscreenMaterial.defines.FRAMEBUFFER_PRECISION_HIGH = "1")
        }
        dispose() {
            super.dispose();
            for (const s of this.effects) s.removeEventListener("change", this.listener), s.dispose()
        }
        handleEvent(s) {
            s.type === "change" && this.recompile()
        }
    },
    Zc = class extends ue {
        constructor(s, e, {
            renderTarget: t,
            resolutionScale: i = 1,
            width: n = re.AUTO_SIZE,
            height: r = re.AUTO_SIZE,
            resolutionX: o = n,
            resolutionY: a = r
        } = {}) {
            super("NormalPass"), this.needsSwap = !1, this.renderPass = new hr(s, e, new To);
            const c = this.renderPass;
            c.ignoreBackground = !0, c.skipShadowMapUpdate = !0;
            const l = c.getClearPass();
            l.overrideClearColor = new ve(7829503), l.overrideClearAlpha = 1, this.renderTarget = t, this.renderTarget === void 0 && (this.renderTarget = new Be(1, 1, {
                minFilter: Yt,
                magFilter: Yt
            }), this.renderTarget.texture.name = "NormalPass.Target");
            const u = this.resolution = new re(this, o, a, i);
            u.addEventListener("change", f => this.setSize(u.baseWidth, u.baseHeight))
        }
        set mainScene(s) {
            this.renderPass.mainScene = s
        }
        set mainCamera(s) {
            this.renderPass.mainCamera = s
        }
        get texture() {
            return this.renderTarget.texture
        }
        getTexture() {
            return this.renderTarget.texture
        }
        getResolution() {
            return this.resolution
        }
        getResolutionScale() {
            return this.resolution.scale
        }
        setResolutionScale(s) {
            this.resolution.scale = s
        }
        render(s, e, t, i, n) {
            const r = this.renderToScreen ? null : this.renderTarget;
            this.renderPass.render(s, r, r)
        }
        setSize(s, e) {
            const t = this.resolution;
            t.setBaseSize(s, e), this.renderTarget.setSize(t.width, t.height)
        }
    };
const qc = x.createContext(null),
    Mn = s => (s.getAttributes() & He.CONVOLUTION) === He.CONVOLUTION,
    $c = ae.memo(x.forwardRef(({
        children: s,
        camera: e,
        scene: t,
        resolutionScale: i,
        enabled: n = !0,
        renderPriority: r = 1,
        autoClear: o = !0,
        depthBuffer: a,
        enableNormalPass: c,
        stencilBuffer: l,
        multisampling: u = 8,
        frameBufferType: f = Wn
    }, p) => {
        const {
            gl: A,
            scene: v,
            camera: _,
            size: T
        } = X(), g = t || v, B = e || _, [y, b, S] = x.useMemo(() => {
            const F = Do(),
                w = new Ka(A, {
                    depthBuffer: a,
                    stencilBuffer: l,
                    multisampling: u > 0 && F ? u : 0,
                    frameBufferType: f
                });
            w.addPass(new hr(g, B));
            let z = null,
                Q = null;
            return c && (Q = new Zc(g, B), Q.enabled = !1, w.addPass(Q), i !== void 0 && F && (z = new Yc({
                normalBuffer: Q.texture,
                resolutionScale: i
            }), z.enabled = !1, w.addPass(z))), [w, Q, z]
        }, [B, A, a, l, u, f, g, c, i]);
        x.useEffect(() => y ? .setSize(T.width, T.height), [y, T]), Fe((F, w) => {
            if (n) {
                const z = A.autoClear;
                A.autoClear = o, l && !o && A.clearStencil(), y.render(w), A.autoClear = z
            }
        }, n ? r : 0);
        const R = x.useRef(null);
        x.useLayoutEffect(() => {
            var F;
            const w = [],
                z = (F = R.current) == null ? void 0 : F.__r3f;
            if (z && y) {
                const Q = z.objects;
                for (let q = 0; q < Q.length; q++) {
                    const de = Q[q];
                    if (de instanceof Et) {
                        const Ee = [de];
                        if (!Mn(de)) {
                            let We = null;
                            for (;
                                (We = Q[q + 1]) instanceof Et && !Mn(We);) Ee.push(We), q++
                        }
                        const Ce = new Wc(B, ...Ee);
                        w.push(Ce)
                    } else de instanceof ue && w.push(de)
                }
                for (const q of w) y ? .addPass(q);
                b && (b.enabled = !0), S && (S.enabled = !0)
            }
            return () => {
                for (const Q of w) y ? .removePass(Q);
                b && (b.enabled = !1), S && (S.enabled = !1)
            }
        }, [y, s, B, b, S]), x.useEffect(() => {
            const F = A.toneMapping;
            return A.toneMapping = bo, () => {
                A.toneMapping = F
            }
        }, [A]);
        const D = x.useMemo(() => ({
            composer: y,
            normalPass: b,
            downSamplingPass: S,
            resolutionScale: i,
            camera: B,
            scene: g
        }), [y, b, S, i, B, g]);
        return x.useImperativeHandle(p, () => y, [y]), L.jsx(qc.Provider, {
            value: D,
            children: L.jsx("group", {
                ref: R,
                children: s
            })
        })
    }));
let el = 0;
const Rn = new WeakMap,
    tl = (s, e) => ae.forwardRef(function({
        blendFunction: i = e ? .blendFunction,
        opacity: n = e ? .opacity,
        ...r
    }, o) {
        let a = Rn.get(s);
        if (!a) {
            const u = `@react-three/postprocessing/${s.name}-${el++}`;
            vi({
                [u]: s
            }), Rn.set(s, a = u)
        }
        const c = X(u => u.camera),
            l = ae.useMemo(() => {
                var u, f;
                return [...(u = e ? .args) != null ? u : [], ...(f = r.args) != null ? f : [{ ...e,
                    ...r
                }]]
            }, [JSON.stringify(r)]);
        return L.jsx(a, {
            camera: c,
            "blendMode-blendFunction": i,
            "blendMode-opacity-value": n,
            ...r,
            ref: o,
            args: l
        })
    }),
    sl = tl(kc, {
        blendFunction: N.ADD
    }),
    il = new Ei,
    us = new Z,
    nl = x.forwardRef((s, e) => {
        const t = x.useRef(null);
        class i extends Et {
            constructor() {
                super("CustomEffect", `
        precision highp float;
        uniform float uTime;
        uniform sampler2D uTexture;
        uniform sampler2D uBrushTexture;
        void mainUv(inout vec2 uv) {
          float brush = texture2D(uBrushTexture, uv).b;
          uv += brush * 0.0035;
        }
        void mainImage(const in vec4 inputColor, const in vec2 uv, out vec4 outputColor) {
          float brush = texture2D(uBrushTexture, uv).b * 0.5;
          vec3 diffuse = texture2D(uTexture, uv + brush).rgb;
          vec3 color = mix(inputColor.rgb, diffuse, brush);
          outputColor = vec4(color, 1.0);
          #include <colorspace_fragment>
        }
      `, {
                    uniforms: new Map([
                        ["uTime", new G(0)],
                        ["uTexture", new G(null)],
                        ["uBrushTexture", new G(null)]
                    ])
                })
            }
            update(c, l, u) {
                this.uniforms.get("uTexture").value = l.texture, this.uniforms.get("uBrushTexture").value = t.current, this.uniforms.get("uTime").value = il.getElapsedTime()
            }
        }
        const n = x.useMemo(() => new i, []),
            [r, o] = Oa({
                size: 512,
                maxAge: 800,
                blend: "luminosity",
                radius: .095,
                intensity: .135,
                minForce: 0,
                interpolate: 0,
                smoothing: .85
            });
        return Fe(({
            gl: a,
            pointer: c
        }) => {
            us.x = (c.x + 1) / 2, us.y = (c.y + 1) / 2, o({
                uv: {
                    x: us.x,
                    y: us.y
                }
            }), t.current = r
        }), L.jsx("primitive", {
            ref: e,
            object: n,
            dispose: null
        })
    }),
    rl = new Ei;
let Ht = {
        value: 1
    },
    ds = {
        value: 1
    };
const ol = `
  #define CENTER vec2(0.5, 0.5)
  #define force 0.08
  #define thickness 0.075
  #define feathering 0.1
  #define aberrationOffset 0.006
  #define flashIntensity 3.0

  precision highp float;
  uniform float uTime;
  uniform float uSpeed;

  vec2 centerScaleUV(vec2 UV, vec2 factor) {
    return (UV - vec2(0.5)) * factor + vec2(0.5);
  }
  float easeOutSine(float t) {
    return sin((t * PI) / 2.0);
  }

  
  void mainImage(const in vec4 inputColor, const in vec2 uv,   out vec4 outputColor) {
    vec2 screenUV = uv;
    float pos = easeOutSine(uSpeed);
    float aspectRatio = resolution.x / resolution.y;
    vec2 scalingFactor = vec2(aspectRatio, 1.0);
    scalingFactor *= 2.0;
    scalingFactor *= 1.0 - thickness - feathering;
    scalingFactor /= sqrt(pow(aspectRatio, 2.0) + 1.0);
    vec2 scaledUV = centerScaleUV(screenUV, scalingFactor);
    vec2 displacement = normalize(scaledUV - CENTER) * force;
    float distance = distance(scaledUV, CENTER);
    float innerBound = smoothstep(
      pos - thickness - feathering,
      pos - thickness,
      distance
    );
    float outerBound = smoothstep(
        pos - feathering,
        pos,
        distance
    );
    float shapeMask = innerBound - outerBound;
    float rChannel = texture(inputBuffer, screenUV - (displacement - aberrationOffset) * shapeMask).x;
    float bChannel = texture(inputBuffer, screenUV - displacement * shapeMask).y;
    float gChannel = texture(inputBuffer, screenUV - (displacement + aberrationOffset) * shapeMask).z;
    vec3 color = vec3(rChannel, bChannel, gChannel);
    float flashOpacity = pow(1.0 - pos, 4.0);
    float flashMask = 1.0 - innerBound;
    color += flashIntensity * color * flashMask * flashOpacity;
    outputColor = vec4(color, 1.0);
    #include <colorspace_fragment>
  }
`;
let al = class extends Et {
    constructor() {
        super("CustomEffect", ol, {
            uniforms: new Map([
                ["uTime", new G(0)],
                ["uSpeed", new G(0)]
            ])
        })
    }
    update(e, t, i) {
        const n = this.uniforms.get("uTime");
        n && (n.value = rl.getElapsedTime())
    }
};
const cl = x.forwardRef((s, e) => {
        const t = x.useMemo(() => new al, []);
        return x.useEffect(() => I.subscribe(i => i.lu_skill_star, i => {
            Ht.value = 0, ds.value = .9
        }), []), Fe((i, n) => {
            const {
                country: r
            } = I.getState(), {
                scroll: o
            } = he.getState();
            r === "fr" && o > .96 && o < .97 && (Ht.value = 0, ds.value = 1), r === "befr" && o > .9 && o < .91 && (Ht.value = 0, ds.value = 1.5), ge(Ht, "value", 1, ds.value, n);
            let a = t.uniforms.get("uSpeed");
            a && (a.value = Ht.value)
        }), L.jsx("primitive", {
            ref: e,
            object: t,
            dispose: null
        })
    }),
    ll = new Ei,
    hl = `
    precision highp float;
    uniform float param;
    uniform float uTime;
    uniform float uSpeed;

    float vDrop(vec2 uv,float t)
    {
        uv.x = uv.x*128.0;
        float dx = fract(uv.x);
        uv.x = floor(uv.x);
        uv.y *= 0.05;
        float o=sin(uv.x*215.4);
        float s=cos(uv.x*33.1)*.3 +.7;
        float trail = mix(95.0,35.0,s);
        float yv = fract(uv.y + t*s + o ) * trail;
        yv = 1.0/yv;
        yv = smoothstep(0.0,1.0,yv*yv);
        yv = sin(yv*PI)*(s*5.0);
        float d2 = sin(dx*PI);
        return yv*(d2*d2);
    }  
    void mainImage(const in vec4 inputColor, const in vec2 uv, out vec4 outputColor) {
        vec2 uv2 = uv;
        uv2 -= 0.5;
        float disc = smoothstep(0.4,0.5,length(uv-0.5));
        disc *= uSpeed;
        disc = clamp(disc, 0.0, 1.0);
        float d = length(uv2)+0.5;
        vec2 p = vec2(atan(uv2.x, uv2.y) / PI, 2.5 / d);
        vec3 color = inputColor.rgb;
        vec3 col = disc * vec3(1.55,0.65,.225) * vDrop(p, uTime / 3.0);
        outputColor = vec4(color + col - 0.013, 1.0);
        #include <colorspace_fragment>
    }

`;
class ul extends Et {
    constructor() {
        super("CustomEffect", hl, {
            uniforms: new Map([
                ["uTime", new G(0)],
                ["uSpeed", new G(0)]
            ])
        })
    }
    update(e, t, i) {
        const n = this.uniforms.get("uTime");
        n && (n.value = ll.getElapsedTime())
    }
}
const dl = x.forwardRef((s, e) => {
    let t = 0;
    const i = x.useMemo(() => new ul, []);
    return Fe(() => {
        const {
            scroll: n
        } = he.getState(), r = (n - t) * 20;
        let o = i.uniforms.get("uSpeed");
        o && (o.value = r), t = n
    }), L.jsx("primitive", {
        ref: e,
        object: i,
        dispose: null
    })
});
var $s = {
    exports: {}
};
var xn;

function fl() {
    return xn || (xn = 1, (function(s) {
        (function(e, t, i, n) {
            var r = ["", "webkit", "Moz", "MS", "ms", "o"],
                o = t.createElement("div"),
                a = "function",
                c = Math.round,
                l = Math.abs,
                u = Date.now;

            function f(h, d, m) {
                return setTimeout(y(h, m), d)
            }

            function p(h, d, m) {
                return Array.isArray(h) ? (A(h, m[d], m), !0) : !1
            }

            function A(h, d, m) {
                var C;
                if (h)
                    if (h.forEach) h.forEach(d, m);
                    else if (h.length !== n)
                    for (C = 0; C < h.length;) d.call(m, h[C], C, h), C++;
                else
                    for (C in h) h.hasOwnProperty(C) && d.call(m, h[C], C, h)
            }

            function v(h, d, m) {
                var C = "DEPRECATED METHOD: " + d + `
` + m + ` AT 
`;
                return function() {
                    var M = new Error("get-stack-trace"),
                        O = M && M.stack ? M.stack.replace(/^[^\(]+?[\n$]/gm, "").replace(/^\s+at\s+/gm, "").replace(/^Object.<anonymous>\s*\(/gm, "{anonymous}()@") : "Unknown Stack Trace",
                        H = e.console && (e.console.warn || e.console.log);
                    return H && H.call(e.console, C, O), h.apply(this, arguments)
                }
            }
            var _;
            typeof Object.assign != "function" ? _ = function(d) {
                if (d === n || d === null) throw new TypeError("Cannot convert undefined or null to object");
                for (var m = Object(d), C = 1; C < arguments.length; C++) {
                    var M = arguments[C];
                    if (M !== n && M !== null)
                        for (var O in M) M.hasOwnProperty(O) && (m[O] = M[O])
                }
                return m
            } : _ = Object.assign;
            var T = v(function(d, m, C) {
                    for (var M = Object.keys(m), O = 0; O < M.length;)(!C || C && d[M[O]] === n) && (d[M[O]] = m[M[O]]), O++;
                    return d
                }, "extend", "Use `assign`."),
                g = v(function(d, m) {
                    return T(d, m, !0)
                }, "merge", "Use `assign`.");

            function B(h, d, m) {
                var C = d.prototype,
                    M;
                M = h.prototype = Object.create(C), M.constructor = h, M._super = C, m && _(M, m)
            }

            function y(h, d) {
                return function() {
                    return h.apply(d, arguments)
                }
            }

            function b(h, d) {
                return typeof h == a ? h.apply(d && d[0] || n, d) : h
            }

            function S(h, d) {
                return h === n ? d : h
            }

            function R(h, d, m) {
                A(z(d), function(C) {
                    h.addEventListener(C, m, !1)
                })
            }

            function D(h, d, m) {
                A(z(d), function(C) {
                    h.removeEventListener(C, m, !1)
                })
            }

            function F(h, d) {
                for (; h;) {
                    if (h == d) return !0;
                    h = h.parentNode
                }
                return !1
            }

            function w(h, d) {
                return h.indexOf(d) > -1
            }

            function z(h) {
                return h.trim().split(/\s+/g)
            }

            function Q(h, d, m) {
                if (h.indexOf && !m) return h.indexOf(d);
                for (var C = 0; C < h.length;) {
                    if (m && h[C][m] == d || !m && h[C] === d) return C;
                    C++
                }
                return -1
            }

            function q(h) {
                return Array.prototype.slice.call(h, 0)
            }

            function de(h, d, m) {
                for (var C = [], M = [], O = 0; O < h.length;) {
                    var H = h[O][d];
                    Q(M, H) < 0 && C.push(h[O]), M[O] = H, O++
                }
                return C = C.sort(function(se, oe) {
                    return se[d] > oe[d]
                }), C
            }

            function Ee(h, d) {
                for (var m, C, M = d[0].toUpperCase() + d.slice(1), O = 0; O < r.length;) {
                    if (m = r[O], C = m ? m + M : d, C in h) return C;
                    O++
                }
                return n
            }
            var Ce = 1;

            function We() {
                return Ce++
            }

            function jt(h) {
                var d = h.ownerDocument || h;
                return d.defaultView || d.parentWindow || e
            }
            var _t = /mobile|tablet|ip(ad|hone|od)|android/i,
                Tt = "ontouchstart" in e,
                Es = Ee(e, "PointerEvent") !== n,
                Cs = Tt && _t.test(navigator.userAgent),
                Ze = "touch",
                V = "pen",
                ie = "mouse",
                _e = "kinect",
                _s = 25,
                ee = 1,
                qe = 2,
                $ = 4,
                ce = 8,
                Qt = 1,
                yt = 2,
                bt = 4,
                St = 8,
                Mt = 16,
                Se = yt | bt,
                $e = St | Mt,
                bi = Se | $e,
                Si = ["x", "y"],
                Vt = ["clientX", "clientY"];

            function fe(h, d) {
                var m = this;
                this.manager = h, this.callback = d, this.element = h.element, this.target = h.options.inputTarget, this.domHandler = function(C) {
                    b(h.options.enable, [h]) && m.handler(C)
                }, this.init()
            }
            fe.prototype = {
                handler: function() {},
                init: function() {
                    this.evEl && R(this.element, this.evEl, this.domHandler), this.evTarget && R(this.target, this.evTarget, this.domHandler), this.evWin && R(jt(this.element), this.evWin, this.domHandler)
                },
                destroy: function() {
                    this.evEl && D(this.element, this.evEl, this.domHandler), this.evTarget && D(this.target, this.evTarget, this.domHandler), this.evWin && D(jt(this.element), this.evWin, this.domHandler)
                }
            };

            function dr(h) {
                var d, m = h.options.inputClass;
                return m ? d = m : Es ? d = ys : Cs ? d = qt : Tt ? d = bs : d = Zt, new d(h, fr)
            }

            function fr(h, d, m) {
                var C = m.pointers.length,
                    M = m.changedPointers.length,
                    O = d & ee && C - M === 0,
                    H = d & ($ | ce) && C - M === 0;
                m.isFirst = !!O, m.isFinal = !!H, O && (h.session = {}), m.eventType = d, pr(h, m), h.emit("hammer.input", m), h.recognize(m), h.session.prevInput = m
            }

            function pr(h, d) {
                var m = h.session,
                    C = d.pointers,
                    M = C.length;
                m.firstInput || (m.firstInput = Mi(d)), M > 1 && !m.firstMultiple ? m.firstMultiple = Mi(d) : M === 1 && (m.firstMultiple = !1);
                var O = m.firstInput,
                    H = m.firstMultiple,
                    te = H ? H.center : O.center,
                    se = d.center = Ri(C);
                d.timeStamp = u(), d.deltaTime = d.timeStamp - O.timeStamp, d.angle = Ts(te, se), d.distance = Wt(te, se), mr(m, d), d.offsetDirection = Di(d.deltaX, d.deltaY);
                var oe = xi(d.deltaTime, d.deltaX, d.deltaY);
                d.overallVelocityX = oe.x, d.overallVelocityY = oe.y, d.overallVelocity = l(oe.x) > l(oe.y) ? oe.x : oe.y, d.scale = H ? vr(H.pointers, C) : 1, d.rotation = H ? gr(H.pointers, C) : 0, d.maxPointers = m.prevInput ? d.pointers.length > m.prevInput.maxPointers ? d.pointers.length : m.prevInput.maxPointers : d.pointers.length, Ar(m, d);
                var Re = h.element;
                F(d.srcEvent.target, Re) && (Re = d.srcEvent.target), d.target = Re
            }

            function mr(h, d) {
                var m = d.center,
                    C = h.offsetDelta || {},
                    M = h.prevDelta || {},
                    O = h.prevInput || {};
                (d.eventType === ee || O.eventType === $) && (M = h.prevDelta = {
                    x: O.deltaX || 0,
                    y: O.deltaY || 0
                }, C = h.offsetDelta = {
                    x: m.x,
                    y: m.y
                }), d.deltaX = M.x + (m.x - C.x), d.deltaY = M.y + (m.y - C.y)
            }

            function Ar(h, d) {
                var m = h.lastInterval || d,
                    C = d.timeStamp - m.timeStamp,
                    M, O, H, te;
                if (d.eventType != ce && (C > _s || m.velocity === n)) {
                    var se = d.deltaX - m.deltaX,
                        oe = d.deltaY - m.deltaY,
                        Re = xi(C, se, oe);
                    O = Re.x, H = Re.y, M = l(Re.x) > l(Re.y) ? Re.x : Re.y, te = Di(se, oe), h.lastInterval = d
                } else M = m.velocity, O = m.velocityX, H = m.velocityY, te = m.direction;
                d.velocity = M, d.velocityX = O, d.velocityY = H, d.direction = te
            }

            function Mi(h) {
                for (var d = [], m = 0; m < h.pointers.length;) d[m] = {
                    clientX: c(h.pointers[m].clientX),
                    clientY: c(h.pointers[m].clientY)
                }, m++;
                return {
                    timeStamp: u(),
                    pointers: d,
                    center: Ri(d),
                    deltaX: h.deltaX,
                    deltaY: h.deltaY
                }
            }

            function Ri(h) {
                var d = h.length;
                if (d === 1) return {
                    x: c(h[0].clientX),
                    y: c(h[0].clientY)
                };
                for (var m = 0, C = 0, M = 0; M < d;) m += h[M].clientX, C += h[M].clientY, M++;
                return {
                    x: c(m / d),
                    y: c(C / d)
                }
            }

            function xi(h, d, m) {
                return {
                    x: d / h || 0,
                    y: m / h || 0
                }
            }

            function Di(h, d) {
                return h === d ? Qt : l(h) >= l(d) ? h < 0 ? yt : bt : d < 0 ? St : Mt
            }

            function Wt(h, d, m) {
                m || (m = Si);
                var C = d[m[0]] - h[m[0]],
                    M = d[m[1]] - h[m[1]];
                return Math.sqrt(C * C + M * M)
            }

            function Ts(h, d, m) {
                m || (m = Si);
                var C = d[m[0]] - h[m[0]],
                    M = d[m[1]] - h[m[1]];
                return Math.atan2(M, C) * 180 / Math.PI
            }

            function gr(h, d) {
                return Ts(d[1], d[0], Vt) + Ts(h[1], h[0], Vt)
            }

            function vr(h, d) {
                return Wt(d[0], d[1], Vt) / Wt(h[0], h[1], Vt)
            }
            var Br = {
                    mousedown: ee,
                    mousemove: qe,
                    mouseup: $
                },
                Er = "mousedown",
                Cr = "mousemove mouseup";

            function Zt() {
                this.evEl = Er, this.evWin = Cr, this.pressed = !1, fe.apply(this, arguments)
            }
            B(Zt, fe, {
                handler: function(d) {
                    var m = Br[d.type];
                    m & ee && d.button === 0 && (this.pressed = !0), m & qe && d.which !== 1 && (m = $), this.pressed && (m & $ && (this.pressed = !1), this.callback(this.manager, m, {
                        pointers: [d],
                        changedPointers: [d],
                        pointerType: ie,
                        srcEvent: d
                    }))
                }
            });
            var _r = {
                    pointerdown: ee,
                    pointermove: qe,
                    pointerup: $,
                    pointercancel: ce,
                    pointerout: ce
                },
                Tr = {
                    2: Ze,
                    3: V,
                    4: ie,
                    5: _e
                },
                Oi = "pointerdown",
                Ii = "pointermove pointerup pointercancel";
            e.MSPointerEvent && !e.PointerEvent && (Oi = "MSPointerDown", Ii = "MSPointerMove MSPointerUp MSPointerCancel");

            function ys() {
                this.evEl = Oi, this.evWin = Ii, fe.apply(this, arguments), this.store = this.manager.session.pointerEvents = []
            }
            B(ys, fe, {
                handler: function(d) {
                    var m = this.store,
                        C = !1,
                        M = d.type.toLowerCase().replace("ms", ""),
                        O = _r[M],
                        H = Tr[d.pointerType] || d.pointerType,
                        te = H == Ze,
                        se = Q(m, d.pointerId, "pointerId");
                    O & ee && (d.button === 0 || te) ? se < 0 && (m.push(d), se = m.length - 1) : O & ($ | ce) && (C = !0), !(se < 0) && (m[se] = d, this.callback(this.manager, O, {
                        pointers: m,
                        changedPointers: [d],
                        pointerType: H,
                        srcEvent: d
                    }), C && m.splice(se, 1))
                }
            });
            var yr = {
                    touchstart: ee,
                    touchmove: qe,
                    touchend: $,
                    touchcancel: ce
                },
                br = "touchstart",
                Sr = "touchstart touchmove touchend touchcancel";

            function Fi() {
                this.evTarget = br, this.evWin = Sr, this.started = !1, fe.apply(this, arguments)
            }
            B(Fi, fe, {
                handler: function(d) {
                    var m = yr[d.type];
                    if (m === ee && (this.started = !0), !!this.started) {
                        var C = Mr.call(this, d, m);
                        m & ($ | ce) && C[0].length - C[1].length === 0 && (this.started = !1), this.callback(this.manager, m, {
                            pointers: C[0],
                            changedPointers: C[1],
                            pointerType: Ze,
                            srcEvent: d
                        })
                    }
                }
            });

            function Mr(h, d) {
                var m = q(h.touches),
                    C = q(h.changedTouches);
                return d & ($ | ce) && (m = de(m.concat(C), "identifier")), [m, C]
            }
            var Rr = {
                    touchstart: ee,
                    touchmove: qe,
                    touchend: $,
                    touchcancel: ce
                },
                xr = "touchstart touchmove touchend touchcancel";

            function qt() {
                this.evTarget = xr, this.targetIds = {}, fe.apply(this, arguments)
            }
            B(qt, fe, {
                handler: function(d) {
                    var m = Rr[d.type],
                        C = Dr.call(this, d, m);
                    C && this.callback(this.manager, m, {
                        pointers: C[0],
                        changedPointers: C[1],
                        pointerType: Ze,
                        srcEvent: d
                    })
                }
            });

            function Dr(h, d) {
                var m = q(h.touches),
                    C = this.targetIds;
                if (d & (ee | qe) && m.length === 1) return C[m[0].identifier] = !0, [m, m];
                var M, O, H = q(h.changedTouches),
                    te = [],
                    se = this.target;
                if (O = m.filter(function(oe) {
                        return F(oe.target, se)
                    }), d === ee)
                    for (M = 0; M < O.length;) C[O[M].identifier] = !0, M++;
                for (M = 0; M < H.length;) C[H[M].identifier] && te.push(H[M]), d & ($ | ce) && delete C[H[M].identifier], M++;
                if (te.length) return [de(O.concat(te), "identifier"), te]
            }
            var Or = 2500,
                Ui = 25;

            function bs() {
                fe.apply(this, arguments);
                var h = y(this.handler, this);
                this.touch = new qt(this.manager, h), this.mouse = new Zt(this.manager, h), this.primaryTouch = null, this.lastTouches = []
            }
            B(bs, fe, {
                handler: function(d, m, C) {
                    var M = C.pointerType == Ze,
                        O = C.pointerType == ie;
                    if (!(O && C.sourceCapabilities && C.sourceCapabilities.firesTouchEvents)) {
                        if (M) Ir.call(this, m, C);
                        else if (O && Fr.call(this, C)) return;
                        this.callback(d, m, C)
                    }
                },
                destroy: function() {
                    this.touch.destroy(), this.mouse.destroy()
                }
            });

            function Ir(h, d) {
                h & ee ? (this.primaryTouch = d.changedPointers[0].identifier, Li.call(this, d)) : h & ($ | ce) && Li.call(this, d)
            }

            function Li(h) {
                var d = h.changedPointers[0];
                if (d.identifier === this.primaryTouch) {
                    var m = {
                        x: d.clientX,
                        y: d.clientY
                    };
                    this.lastTouches.push(m);
                    var C = this.lastTouches,
                        M = function() {
                            var O = C.indexOf(m);
                            O > -1 && C.splice(O, 1)
                        };
                    setTimeout(M, Or)
                }
            }

            function Fr(h) {
                for (var d = h.srcEvent.clientX, m = h.srcEvent.clientY, C = 0; C < this.lastTouches.length; C++) {
                    var M = this.lastTouches[C],
                        O = Math.abs(d - M.x),
                        H = Math.abs(m - M.y);
                    if (O <= Ui && H <= Ui) return !0
                }
                return !1
            }
            var wi = Ee(o.style, "touchAction"),
                Pi = wi !== n,
                Gi = "compute",
                Hi = "auto",
                Ss = "manipulation",
                et = "none",
                Rt = "pan-x",
                xt = "pan-y",
                $t = Lr();

            function Ms(h, d) {
                this.manager = h, this.set(d)
            }
            Ms.prototype = {
                set: function(h) {
                    h == Gi && (h = this.compute()), Pi && this.manager.element.style && $t[h] && (this.manager.element.style[wi] = h), this.actions = h.toLowerCase().trim()
                },
                update: function() {
                    this.set(this.manager.options.touchAction)
                },
                compute: function() {
                    var h = [];
                    return A(this.manager.recognizers, function(d) {
                        b(d.options.enable, [d]) && (h = h.concat(d.getTouchAction()))
                    }), Ur(h.join(" "))
                },
                preventDefaults: function(h) {
                    var d = h.srcEvent,
                        m = h.offsetDirection;
                    if (this.manager.session.prevented) {
                        d.preventDefault();
                        return
                    }
                    var C = this.actions,
                        M = w(C, et) && !$t[et],
                        O = w(C, xt) && !$t[xt],
                        H = w(C, Rt) && !$t[Rt];
                    if (M) {
                        var te = h.pointers.length === 1,
                            se = h.distance < 2,
                            oe = h.deltaTime < 250;
                        if (te && se && oe) return
                    }
                    if (!(H && O) && (M || O && m & Se || H && m & $e)) return this.preventSrc(d)
                },
                preventSrc: function(h) {
                    this.manager.session.prevented = !0, h.preventDefault()
                }
            };

            function Ur(h) {
                if (w(h, et)) return et;
                var d = w(h, Rt),
                    m = w(h, xt);
                return d && m ? et : d || m ? d ? Rt : xt : w(h, Ss) ? Ss : Hi
            }

            function Lr() {
                if (!Pi) return !1;
                var h = {},
                    d = e.CSS && e.CSS.supports;
                return ["auto", "manipulation", "pan-y", "pan-x", "pan-x pan-y", "none"].forEach(function(m) {
                    h[m] = d ? e.CSS.supports("touch-action", m) : !0
                }), h
            }
            var es = 1,
                pe = 2,
                ut = 4,
                ke = 8,
                Ue = ke,
                Dt = 16,
                Me = 32;

            function Le(h) {
                this.options = _({}, this.defaults, h || {}), this.id = We(), this.manager = null, this.options.enable = S(this.options.enable, !0), this.state = es, this.simultaneous = {}, this.requireFail = []
            }
            Le.prototype = {
                defaults: {},
                set: function(h) {
                    return _(this.options, h), this.manager && this.manager.touchAction.update(), this
                },
                recognizeWith: function(h) {
                    if (p(h, "recognizeWith", this)) return this;
                    var d = this.simultaneous;
                    return h = ts(h, this), d[h.id] || (d[h.id] = h, h.recognizeWith(this)), this
                },
                dropRecognizeWith: function(h) {
                    return p(h, "dropRecognizeWith", this) ? this : (h = ts(h, this), delete this.simultaneous[h.id], this)
                },
                requireFailure: function(h) {
                    if (p(h, "requireFailure", this)) return this;
                    var d = this.requireFail;
                    return h = ts(h, this), Q(d, h) === -1 && (d.push(h), h.requireFailure(this)), this
                },
                dropRequireFailure: function(h) {
                    if (p(h, "dropRequireFailure", this)) return this;
                    h = ts(h, this);
                    var d = Q(this.requireFail, h);
                    return d > -1 && this.requireFail.splice(d, 1), this
                },
                hasRequireFailures: function() {
                    return this.requireFail.length > 0
                },
                canRecognizeWith: function(h) {
                    return !!this.simultaneous[h.id]
                },
                emit: function(h) {
                    var d = this,
                        m = this.state;

                    function C(M) {
                        d.manager.emit(M, h)
                    }
                    m < ke && C(d.options.event + Ni(m)), C(d.options.event), h.additionalEvent && C(h.additionalEvent), m >= ke && C(d.options.event + Ni(m))
                },
                tryEmit: function(h) {
                    if (this.canEmit()) return this.emit(h);
                    this.state = Me
                },
                canEmit: function() {
                    for (var h = 0; h < this.requireFail.length;) {
                        if (!(this.requireFail[h].state & (Me | es))) return !1;
                        h++
                    }
                    return !0
                },
                recognize: function(h) {
                    var d = _({}, h);
                    if (!b(this.options.enable, [this, d])) {
                        this.reset(), this.state = Me;
                        return
                    }
                    this.state & (Ue | Dt | Me) && (this.state = es), this.state = this.process(d), this.state & (pe | ut | ke | Dt) && this.tryEmit(d)
                },
                process: function(h) {},
                getTouchAction: function() {},
                reset: function() {}
            };

            function Ni(h) {
                return h & Dt ? "cancel" : h & ke ? "end" : h & ut ? "move" : h & pe ? "start" : ""
            }

            function ki(h) {
                return h == Mt ? "down" : h == St ? "up" : h == yt ? "left" : h == bt ? "right" : ""
            }

            function ts(h, d) {
                var m = d.manager;
                return m ? m.get(h) : h
            }

            function Te() {
                Le.apply(this, arguments)
            }
            B(Te, Le, {
                defaults: {
                    pointers: 1
                },
                attrTest: function(h) {
                    var d = this.options.pointers;
                    return d === 0 || h.pointers.length === d
                },
                process: function(h) {
                    var d = this.state,
                        m = h.eventType,
                        C = d & (pe | ut),
                        M = this.attrTest(h);
                    return C && (m & ce || !M) ? d | Dt : C || M ? m & $ ? d | ke : d & pe ? d | ut : pe : Me
                }
            });

            function ss() {
                Te.apply(this, arguments), this.pX = null, this.pY = null
            }
            B(ss, Te, {
                defaults: {
                    event: "pan",
                    threshold: 10,
                    pointers: 1,
                    direction: bi
                },
                getTouchAction: function() {
                    var h = this.options.direction,
                        d = [];
                    return h & Se && d.push(xt), h & $e && d.push(Rt), d
                },
                directionTest: function(h) {
                    var d = this.options,
                        m = !0,
                        C = h.distance,
                        M = h.direction,
                        O = h.deltaX,
                        H = h.deltaY;
                    return M & d.direction || (d.direction & Se ? (M = O === 0 ? Qt : O < 0 ? yt : bt, m = O != this.pX, C = Math.abs(h.deltaX)) : (M = H === 0 ? Qt : H < 0 ? St : Mt, m = H != this.pY, C = Math.abs(h.deltaY))), h.direction = M, m && C > d.threshold && M & d.direction
                },
                attrTest: function(h) {
                    return Te.prototype.attrTest.call(this, h) && (this.state & pe || !(this.state & pe) && this.directionTest(h))
                },
                emit: function(h) {
                    this.pX = h.deltaX, this.pY = h.deltaY;
                    var d = ki(h.direction);
                    d && (h.additionalEvent = this.options.event + d), this._super.emit.call(this, h)
                }
            });

            function Rs() {
                Te.apply(this, arguments)
            }
            B(Rs, Te, {
                defaults: {
                    event: "pinch",
                    threshold: 0,
                    pointers: 2
                },
                getTouchAction: function() {
                    return [et]
                },
                attrTest: function(h) {
                    return this._super.attrTest.call(this, h) && (Math.abs(h.scale - 1) > this.options.threshold || this.state & pe)
                },
                emit: function(h) {
                    if (h.scale !== 1) {
                        var d = h.scale < 1 ? "in" : "out";
                        h.additionalEvent = this.options.event + d
                    }
                    this._super.emit.call(this, h)
                }
            });

            function xs() {
                Le.apply(this, arguments), this._timer = null, this._input = null
            }
            B(xs, Le, {
                defaults: {
                    event: "press",
                    pointers: 1,
                    time: 251,
                    threshold: 9
                },
                getTouchAction: function() {
                    return [Hi]
                },
                process: function(h) {
                    var d = this.options,
                        m = h.pointers.length === d.pointers,
                        C = h.distance < d.threshold,
                        M = h.deltaTime > d.time;
                    if (this._input = h, !C || !m || h.eventType & ($ | ce) && !M) this.reset();
                    else if (h.eventType & ee) this.reset(), this._timer = f(function() {
                        this.state = Ue, this.tryEmit()
                    }, d.time, this);
                    else if (h.eventType & $) return Ue;
                    return Me
                },
                reset: function() {
                    clearTimeout(this._timer)
                },
                emit: function(h) {
                    this.state === Ue && (h && h.eventType & $ ? this.manager.emit(this.options.event + "up", h) : (this._input.timeStamp = u(), this.manager.emit(this.options.event, this._input)))
                }
            });

            function Ds() {
                Te.apply(this, arguments)
            }
            B(Ds, Te, {
                defaults: {
                    event: "rotate",
                    threshold: 0,
                    pointers: 2
                },
                getTouchAction: function() {
                    return [et]
                },
                attrTest: function(h) {
                    return this._super.attrTest.call(this, h) && (Math.abs(h.rotation) > this.options.threshold || this.state & pe)
                }
            });

            function Os() {
                Te.apply(this, arguments)
            }
            B(Os, Te, {
                defaults: {
                    event: "swipe",
                    threshold: 10,
                    velocity: .3,
                    direction: Se | $e,
                    pointers: 1
                },
                getTouchAction: function() {
                    return ss.prototype.getTouchAction.call(this)
                },
                attrTest: function(h) {
                    var d = this.options.direction,
                        m;
                    return d & (Se | $e) ? m = h.overallVelocity : d & Se ? m = h.overallVelocityX : d & $e && (m = h.overallVelocityY), this._super.attrTest.call(this, h) && d & h.offsetDirection && h.distance > this.options.threshold && h.maxPointers == this.options.pointers && l(m) > this.options.velocity && h.eventType & $
                },
                emit: function(h) {
                    var d = ki(h.offsetDirection);
                    d && this.manager.emit(this.options.event + d, h), this.manager.emit(this.options.event, h)
                }
            });

            function is() {
                Le.apply(this, arguments), this.pTime = !1, this.pCenter = !1, this._timer = null, this._input = null, this.count = 0
            }
            B(is, Le, {
                defaults: {
                    event: "tap",
                    pointers: 1,
                    taps: 1,
                    interval: 300,
                    time: 250,
                    threshold: 9,
                    posThreshold: 10
                },
                getTouchAction: function() {
                    return [Ss]
                },
                process: function(h) {
                    var d = this.options,
                        m = h.pointers.length === d.pointers,
                        C = h.distance < d.threshold,
                        M = h.deltaTime < d.time;
                    if (this.reset(), h.eventType & ee && this.count === 0) return this.failTimeout();
                    if (C && M && m) {
                        if (h.eventType != $) return this.failTimeout();
                        var O = this.pTime ? h.timeStamp - this.pTime < d.interval : !0,
                            H = !this.pCenter || Wt(this.pCenter, h.center) < d.posThreshold;
                        this.pTime = h.timeStamp, this.pCenter = h.center, !H || !O ? this.count = 1 : this.count += 1, this._input = h;
                        var te = this.count % d.taps;
                        if (te === 0) return this.hasRequireFailures() ? (this._timer = f(function() {
                            this.state = Ue, this.tryEmit()
                        }, d.interval, this), pe) : Ue
                    }
                    return Me
                },
                failTimeout: function() {
                    return this._timer = f(function() {
                        this.state = Me
                    }, this.options.interval, this), Me
                },
                reset: function() {
                    clearTimeout(this._timer)
                },
                emit: function() {
                    this.state == Ue && (this._input.tapCount = this.count, this.manager.emit(this.options.event, this._input))
                }
            });

            function Je(h, d) {
                return d = d || {}, d.recognizers = S(d.recognizers, Je.defaults.preset), new Is(h, d)
            }
            Je.VERSION = "2.0.7", Je.defaults = {
                domEvents: !1,
                touchAction: Gi,
                enable: !0,
                inputTarget: null,
                inputClass: null,
                preset: [
                    [Ds, {
                        enable: !1
                    }],
                    [Rs, {
                            enable: !1
                        },
                        ["rotate"]
                    ],
                    [Os, {
                        direction: Se
                    }],
                    [ss, {
                            direction: Se
                        },
                        ["swipe"]
                    ],
                    [is],
                    [is, {
                            event: "doubletap",
                            taps: 2
                        },
                        ["tap"]
                    ],
                    [xs]
                ],
                cssProps: {
                    userSelect: "none",
                    touchSelect: "none",
                    touchCallout: "none",
                    contentZooming: "none",
                    userDrag: "none",
                    tapHighlightColor: "rgba(0,0,0,0)"
                }
            };
            var wr = 1,
                Ji = 2;

            function Is(h, d) {
                this.options = _({}, Je.defaults, d || {}), this.options.inputTarget = this.options.inputTarget || h, this.handlers = {}, this.session = {}, this.recognizers = [], this.oldCssProps = {}, this.element = h, this.input = dr(this), this.touchAction = new Ms(this, this.options.touchAction), Ki(this, !0), A(this.options.recognizers, function(m) {
                    var C = this.add(new m[0](m[1]));
                    m[2] && C.recognizeWith(m[2]), m[3] && C.requireFailure(m[3])
                }, this)
            }
            Is.prototype = {
                set: function(h) {
                    return _(this.options, h), h.touchAction && this.touchAction.update(), h.inputTarget && (this.input.destroy(), this.input.target = h.inputTarget, this.input.init()), this
                },
                stop: function(h) {
                    this.session.stopped = h ? Ji : wr
                },
                recognize: function(h) {
                    var d = this.session;
                    if (!d.stopped) {
                        this.touchAction.preventDefaults(h);
                        var m, C = this.recognizers,
                            M = d.curRecognizer;
                        (!M || M && M.state & Ue) && (M = d.curRecognizer = null);
                        for (var O = 0; O < C.length;) m = C[O], d.stopped !== Ji && (!M || m == M || m.canRecognizeWith(M)) ? m.recognize(h) : m.reset(), !M && m.state & (pe | ut | ke) && (M = d.curRecognizer = m), O++
                    }
                },
                get: function(h) {
                    if (h instanceof Le) return h;
                    for (var d = this.recognizers, m = 0; m < d.length; m++)
                        if (d[m].options.event == h) return d[m];
                    return null
                },
                add: function(h) {
                    if (p(h, "add", this)) return this;
                    var d = this.get(h.options.event);
                    return d && this.remove(d), this.recognizers.push(h), h.manager = this, this.touchAction.update(), h
                },
                remove: function(h) {
                    if (p(h, "remove", this)) return this;
                    if (h = this.get(h), h) {
                        var d = this.recognizers,
                            m = Q(d, h);
                        m !== -1 && (d.splice(m, 1), this.touchAction.update())
                    }
                    return this
                },
                on: function(h, d) {
                    if (h !== n && d !== n) {
                        var m = this.handlers;
                        return A(z(h), function(C) {
                            m[C] = m[C] || [], m[C].push(d)
                        }), this
                    }
                },
                off: function(h, d) {
                    if (h !== n) {
                        var m = this.handlers;
                        return A(z(h), function(C) {
                            d ? m[C] && m[C].splice(Q(m[C], d), 1) : delete m[C]
                        }), this
                    }
                },
                emit: function(h, d) {
                    this.options.domEvents && Pr(h, d);
                    var m = this.handlers[h] && this.handlers[h].slice();
                    if (!(!m || !m.length)) {
                        d.type = h, d.preventDefault = function() {
                            d.srcEvent.preventDefault()
                        };
                        for (var C = 0; C < m.length;) m[C](d), C++
                    }
                },
                destroy: function() {
                    this.element && Ki(this, !1), this.handlers = {}, this.session = {}, this.input.destroy(), this.element = null
                }
            };

            function Ki(h, d) {
                var m = h.element;
                if (m.style) {
                    var C;
                    A(h.options.cssProps, function(M, O) {
                        C = Ee(m.style, O), d ? (h.oldCssProps[C] = m.style[C], m.style[C] = M) : m.style[C] = h.oldCssProps[C] || ""
                    }), d || (h.oldCssProps = {})
                }
            }

            function Pr(h, d) {
                var m = t.createEvent("Event");
                m.initEvent(h, !0, !0), m.gesture = d, d.target.dispatchEvent(m)
            }
            _(Je, {
                INPUT_START: ee,
                INPUT_MOVE: qe,
                INPUT_END: $,
                INPUT_CANCEL: ce,
                STATE_POSSIBLE: es,
                STATE_BEGAN: pe,
                STATE_CHANGED: ut,
                STATE_ENDED: ke,
                STATE_RECOGNIZED: Ue,
                STATE_CANCELLED: Dt,
                STATE_FAILED: Me,
                DIRECTION_NONE: Qt,
                DIRECTION_LEFT: yt,
                DIRECTION_RIGHT: bt,
                DIRECTION_UP: St,
                DIRECTION_DOWN: Mt,
                DIRECTION_HORIZONTAL: Se,
                DIRECTION_VERTICAL: $e,
                DIRECTION_ALL: bi,
                Manager: Is,
                Input: fe,
                TouchAction: Ms,
                TouchInput: qt,
                MouseInput: Zt,
                PointerEventInput: ys,
                TouchMouseInput: bs,
                SingleTouchInput: Fi,
                Recognizer: Le,
                AttrRecognizer: Te,
                Tap: is,
                Pan: ss,
                Swipe: Os,
                Pinch: Rs,
                Rotate: Ds,
                Press: xs,
                on: R,
                off: D,
                each: A,
                merge: g,
                extend: T,
                assign: _,
                inherit: B,
                bindFn: y,
                prefixed: Ee
            });
            var Gr = typeof e < "u" ? e : typeof self < "u" ? self : {};
            Gr.Hammer = Je, s.exports ? s.exports = Je : e[i] = Je
        })(window, document, "Hammer")
    })($s)), $s.exports
}
var pl = fl();
const vt = $n(pl);
var ei, Dn;

function ml() {
    if (Dn) return ei;
    Dn = 1;
    var s = !1,
        e, t, i, n, r, o, a, c, l, u, f, p, A, v, _;

    function T() {
        if (!s) {
            s = !0;
            var B = navigator.userAgent,
                y = /(?:MSIE.(\d+\.\d+))|(?:(?:Firefox|GranParadiso|Iceweasel).(\d+\.\d+))|(?:Opera(?:.+Version.|.)(\d+\.\d+))|(?:AppleWebKit.(\d+(?:\.\d+)?))|(?:Trident\/\d+\.\d+.*rv:(\d+\.\d+))/.exec(B),
                b = /(Mac OS X)|(Windows)|(Linux)/.exec(B);
            if (p = /\b(iPhone|iP[ao]d)/.exec(B), A = /\b(iP[ao]d)/.exec(B), u = /Android/i.exec(B), v = /FBAN\/\w+;/i.exec(B), _ = /Mobile/i.exec(B), f = !!/Win64/.exec(B), y) {
                e = y[1] ? parseFloat(y[1]) : y[5] ? parseFloat(y[5]) : NaN, e && document && document.documentMode && (e = document.documentMode);
                var S = /(?:Trident\/(\d+.\d+))/.exec(B);
                o = S ? parseFloat(S[1]) + 4 : e, t = y[2] ? parseFloat(y[2]) : NaN, i = y[3] ? parseFloat(y[3]) : NaN, n = y[4] ? parseFloat(y[4]) : NaN, n ? (y = /(?:Chrome\/(\d+\.\d+))/.exec(B), r = y && y[1] ? parseFloat(y[1]) : NaN) : r = NaN
            } else e = t = i = r = n = NaN;
            if (b) {
                if (b[1]) {
                    var R = /(?:Mac OS X (\d+(?:[._]\d+)?))/.exec(B);
                    a = R ? parseFloat(R[1].replace("_", ".")) : !0
                } else a = !1;
                c = !!b[2], l = !!b[3]
            } else a = c = l = !1
        }
    }
    var g = {
        ie: function() {
            return T() || e
        },
        ieCompatibilityMode: function() {
            return T() || o > e
        },
        ie64: function() {
            return g.ie() && f
        },
        firefox: function() {
            return T() || t
        },
        opera: function() {
            return T() || i
        },
        webkit: function() {
            return T() || n
        },
        safari: function() {
            return g.webkit()
        },
        chrome: function() {
            return T() || r
        },
        windows: function() {
            return T() || c
        },
        osx: function() {
            return T() || a
        },
        linux: function() {
            return T() || l
        },
        iphone: function() {
            return T() || p
        },
        mobile: function() {
            return T() || p || A || u || _
        },
        nativeApp: function() {
            return T() || v
        },
        android: function() {
            return T() || u
        },
        ipad: function() {
            return T() || A
        }
    };
    return ei = g, ei
}
var ti, On;

function Al() {
    if (On) return ti;
    On = 1;
    var s = !!(typeof window < "u" && window.document && window.document.createElement),
        e = {
            canUseDOM: s,
            canUseWorkers: typeof Worker < "u",
            canUseEventListeners: s && !!(window.addEventListener || window.attachEvent),
            canUseViewport: s && !!window.screen,
            isInWorker: !s
        };
    return ti = e, ti
}
var si, In;

function gl() {
    if (In) return si;
    In = 1;
    var s = Al(),
        e;
    s.canUseDOM && (e = document.implementation && document.implementation.hasFeature && document.implementation.hasFeature("", "") !== !0);

    function t(i, n) {
        if (!s.canUseDOM || n && !("addEventListener" in document)) return !1;
        var r = "on" + i,
            o = r in document;
        if (!o) {
            var a = document.createElement("div");
            a.setAttribute(r, "return;"), o = typeof a[r] == "function"
        }
        return !o && e && i === "wheel" && (o = document.implementation.hasFeature("Events.wheel", "3.0")), o
    }
    return si = t, si
}
var ii, Fn;

function vl() {
    if (Fn) return ii;
    Fn = 1;
    var s = ml(),
        e = gl(),
        t = 10,
        i = 40,
        n = 800;

    function r(o) {
        var a = 0,
            c = 0,
            l = 0,
            u = 0;
        return "detail" in o && (c = o.detail), "wheelDelta" in o && (c = -o.wheelDelta / 120), "wheelDeltaY" in o && (c = -o.wheelDeltaY / 120), "wheelDeltaX" in o && (a = -o.wheelDeltaX / 120), "axis" in o && o.axis === o.HORIZONTAL_AXIS && (a = c, c = 0), l = a * t, u = c * t, "deltaY" in o && (u = o.deltaY), "deltaX" in o && (l = o.deltaX), (l || u) && o.deltaMode && (o.deltaMode == 1 ? (l *= i, u *= i) : (l *= n, u *= n)), l && !a && (a = l < 1 ? -1 : 1), u && !c && (c = u < 1 ? -1 : 1), {
            spinX: a,
            spinY: c,
            pixelX: l,
            pixelY: u
        }
    }
    return r.getEventType = function() {
        return s.firefox() ? "DOMMouseScroll" : e("wheel") ? "wheel" : "mousewheel"
    }, ii = r, ii
}
var ni, Un;

function Bl() {
    return Un || (Un = 1, ni = vl()), ni
}
var El = Bl();
const Cl = $n(El);
class be {
    constructor(e) {
        let t = typeof e == "object" ? e : {};
        this.container = t.container != null ? t.container : window, this.container.addEventListener("mousewheel", this.updateScrollDeltaValue.bind(this)), this.container.addEventListener("wheel", this.updateScrollDeltaValue.bind(this)), this.deltaY = this.currentY = typeof t.startY == "number" ? t.startY : 0, this.lerpAmount = this.lerpAmountScroll = t.lerpAmount != null ? t.lerpAmount : .1, this.lerpAmountSwipe = t.lerpAmountSwipe != null ? t.lerpAmountSwipe : this.lerpAmount * 4, this.mobileSensibility = t.mobileSensibility ? ? 1, this.amp = t.amp > 1 ? t.amp : 1, this.triggers = typeof t.triggers == "object" ? t.triggers : [], this.range = typeof t.range != "object" ? !1 : t.range, this.completion = 0, this.scrollbarCreation = t.scrollbar !== !1, this.scrollbar_options = t.scrollbar || {}, this.scrollbarPosition = this.scrollbar_options.position || "right", this.scrollbarDistanceFromEdge = this.scrollbar_options.distanceFromEdge ? ? 0, this.scrollbarWidth = this.scrollbar_options.width || 6, this.scrollbarDirection = this.scrollbarPosition == "top" || this.scrollbarPosition == "bottom" ? "horizontal" : "vertical", this.swipeStrength = typeof t.swipeStrength == "number" ? t.swipeStrength : 75, this.customScrollbarStyles = typeof this.scrollbar_options.customStyles == "string" ? this.scrollbar_options.customStyles : !1, this.fadeOutDelay = typeof t.fadeOutDelay == "number" ? t.fadeOutDelay : !1, this.fadeOutTimeout, this.active = !0, this.handleSize = typeof t.handleSize == "number" ? t.handleSize : .1, this.distanceToScroll = -(100 * (this.handleSize - 1)) / this.handleSize;
        const i = new vt.Manager(document.body, {
            inputClass: vt.TouchInput
        });
        this.hammer = i, i.add(new vt.Pan({
            direction: vt.DIRECTION_ALL,
            threshold: 0
        })), i.on("pan", this.updateSwipeDeltaValue.bind(this)), this instanceof be && (typeof be[be.instanceCounter] != "number" ? be[be.instanceCounter] = 0 : be[be.instanceCounter]++), this.instanceId = be[be.instanceCounter], this.lerpAnimation = !0, this.scrollbarCreation && this.createScrollbar()
    }
    createScrollbar() {
        let e = document.createElement("style");
        e.id = `virtual-scroll-handler-${this.instanceId}`, e.innerHTML = `.vsh-scrollbar-${this.instanceId} {
            position: fixed;
            ${this.scrollbarPosition=="bottom"?"bottom":"top"}: ${this.scrollbarDistanceFromEdge}px;
            ${this.scrollbarPosition=="left"?"left":"right"}: ${this.scrollbarDistanceFromEdge}px;
            ${this.scrollbarDirection=="vertical"?"height":"width"}: calc(100% - ${this.scrollbarDistanceFromEdge*2}px);
            ${this.scrollbarDirection=="vertical"?"width":"height"}: ${this.scrollbarWidth}px;
            background: #333333;
            z-index: 10000;
            border: 1px solid #333333;
            box-sizing: border-box;
        }

        .vsh-scrollbar-${this.instanceId}--out {
            opacity: 0;
            transition: .5s opacity linear;
        }

        .vsh-scrollbar__handle-${this.instanceId} {
            position: absolute;
            ${this.scrollbarDirection=="vertical"?"width":"height"}: 300%;
            ${this.scrollbarDirection=="vertical"?"height":"width"}: ${this.handleSize*100}%;
            ${this.scrollbarDirection=="vertical"?"top":"left"}: 0;
            ${this.scrollbarDirection=="vertical"?"left":"top"}: -100%;
            cursor: grab;
        }

        .vsh-scrollbar__handle-${this.instanceId}:after{
            content: '';
            position: absolute;
            background: white;
            
            ${this.scrollbarDirection=="vertical"?"width":"height"}: 33.33%;
            ${this.scrollbarDirection=="vertical"?"height":"width"}: 100%;
            ${this.scrollbarDirection=="vertical"?"top":"left"}: 0;
            ${this.scrollbarDirection=="vertical"?"left":"top"}: 33.33%;
        }`, this.customScrollbarStyles && (e.innerHTML += this.customScrollbarStyles), document.head.appendChild(e);
        let t = document.createElement("div");
        t.id = `vsh-scrollbar-${this.instanceId}`, t.classList.add(`vsh-scrollbar-${this.instanceId}`), this.fadeOutDelay && t.classList.add(`vsh-scrollbar-${this.instanceId}--out`), document.body.appendChild(t);
        let i = document.createElement("div");
        i.id = `vsh-scrollbar__handle-${this.instanceId}`, i.classList.add(`vsh-scrollbar__handle-${this.instanceId}`), t.appendChild(i), this.domElements = {
            scrollbar: t,
            handle: i
        }, setTimeout((function() {
            this.handleDrag(), this.domElements.scrollbar.addEventListener("mouseenter", () => {
                this.domElements.scrollbar.classList.remove(`vsh-scrollbar-${this.instanceId}--out`), clearTimeout(this.fadeOutTimeout)
            }), this.domElements.scrollbar.addEventListener("mouseleave", () => {
                this.resetFadeOutTimeout()
            })
        }).bind(this), 100)
    }
    handleDrag() {
        let e = {
                prevY: 0,
                y: 0
            },
            t = new vt(this.domElements.handle),
            i = this.getWindowSize();
        window.addEventListener("resize", (function() {
            i = this.getWindowSize()
        }).bind(this));
        let n = this.scrollbarDirection == "vertical" ? 1 : 0,
            r = this.scrollbarDirection == "vertical" ? "deltaY" : "deltaX";
        this.domElements.handle.addEventListener("mousedown", () => {
            this.preventFadeOut = !0
        }), window.addEventListener("mouseup", () => {
            this.preventFadeOut = !1, this.resetFadeOutTimeout()
        }), t.get("pan").set({
            direction: vt.DIRECTION_ALL
        }), t.on("panstart", (function() {
            this.active && (this.lerpAnimation = !1, e.prevY = this.currentY / this.range[1] * i[n])
        }).bind(this)), t.on("pan", (function(o) {
            this.active && (e.y = e.prevY + o[r], e.y = ri(e.y, 0, i[n]), this.currentY = this.deltaY = e.y / i[n] * this.range[1], this.domElements.handle.style.transform = `translateY(${e.y/i[n]*this.distanceToScroll}%)`)
        }).bind(this)), t.on("panend", (function() {
            this.active && (this.lerpAnimation = !0)
        }).bind(this))
    }
    getWindowSize() {
        return [window.innerWidth, window.innerHeight]
    }
    updateScrollDeltaValue(e) {
        if (!this.active) return;
        let t, i = window.devicePixelRatio || 1,
            n = Cl(e).pixelY / i * this.amp;
        this.range ? t = ri(this.deltaY + n, this.range[0], this.range[1]) : t = this.deltaY + n, this.deltaY = t, this.lerpAmount = this.lerpAmountScroll, this.resetFadeOutTimeout()
    }
    resetFadeOutTimeout() {
        this.fadeOutDelay && this.scrollbarCreation && (this.domElements.scrollbar.classList.remove(`vsh-scrollbar-${this.instanceId}--out`), clearTimeout(this.fadeOutTimeout), this.fadeOutTimeout = setTimeout(() => {
            this.preventFadeOut || this.domElements.scrollbar.classList.add(`vsh-scrollbar-${this.instanceId}--out`)
        }, this.fadeOutDelay))
    }
    updateSwipeDeltaValue(e) {
        if (!this.active) return;
        this.fadeOutTimeout && this.scrollbarCreation && (this.domElements.scrollbar.classList.remove(`vsh-scrollbar-${this.instanceId}--out`), clearTimeout(this.fadeOutTimeout));
        let t;
        this.range ? t = ri(this.deltaY + this.swipeStrength * -e.velocityY * this.mobileSensibility * this.amp, this.range[0], this.range[1]) : t = this.deltaY + this.swipeStrength * -e.velocityY * this.mobileSensibility * this.amp, this.deltaY = t, this.lerpAmount = this.lerpAmountSwipe, this.fadeOutDelay && this.scrollbarCreation && (this.fadeOutTimeout = setTimeout(() => {
            this.domElements.scrollbar.classList.add(`vsh-scrollbar-${this.instanceId}--out`)
        }, this.fadeOutDelay))
    }
    update() {
        let e;
        this.lerpAnimation ? e = _l(this.currentY, this.deltaY, this.lerpAmount) : e = this.deltaY, this.currentY = Math.ceil(e * 100) / 100, this.checkTriggers(), this.updateCompletion(), this.scrollbarCreation && (this.scrollbarPosition == "left" || this.scrollbarPosition == "right" ? this.domElements.handle.style.transform = "translate3d(0," + this.completion * this.distanceToScroll + "%,0)" : this.domElements.handle.style.transform = "translate3d(" + this.completion * this.distanceToScroll + "%,0,0)")
    }
    checkTriggers() {
        this.triggers.forEach(e => {
            e.condition == ">y" || e.condition == null ? (this.currentY >= e.y && !e.triggered && (e.callback(), e.triggered = !0), this.currentY < e.y && e.triggered && !e.once && (e.triggered = !1)) : e.condition == "<y" && (this.currentY <= e.y && !e.triggered && (e.callback(), e.triggered = !0), this.currentY > e.y && e.triggered && !e.once && (e.triggered = !1))
        })
    }
    updateCompletion() {
        this.range && (this.completion = (this.currentY - this.range[0]) / (this.range[1] - this.range[0]))
    }
    goTo(e, t = !0) {
        t ? this.deltaY = e : (this.lerpAnimation = !1, this.deltaY = e, this.update(), setTimeout(() => {
            this.lerpAnimation = !0
        }, 50))
    }
    reset() {
        this.deltaY = this.currentY = this.completion = 0
    }
    destroy() {
        this.reset(), this.hammer.destroy(), this.container.removeEventListener("mousewheel", this.updateScrollDeltaValue.bind(this)), this.container.removeEventListener("wheel", this.updateScrollDeltaValue.bind(this))
    }
}

function _l(s, e, t) {
    return (1 - t) * s + t * e
}

function ri(s, e, t) {
    return s <= e ? e : s >= t ? t : s
}
const Tl = () => {
        let s = 0,
            e = 0;
        const t = .1,
            i = 5,
            n = x.useRef(null),
            r = a => {
                const {
                    mobile: c
                } = I.getState();
                c && he.setState({
                    lerpAmountInit: t
                }), e = 0, n.current && n.current.destroy(), n.current = new be({
                    lerpAmount: c ? t : he.getState().lerpAmount,
                    mobileSensibility: 0,
                    lerpAmountSwipe: 0,
                    startY: 0,
                    range: [0, a],
                    scrollbar: !1
                }), c && (n.current.active = !1), he.setState({
                    scrollHandler: n.current,
                    scroll: 0,
                    deltaScroll: 0,
                    scroll_path_length: a
                })
            },
            o = () => {
                const {
                    scrollHandler: a,
                    scroll_path_length: c,
                    disableScroll: l
                } = he.getState(), {
                    mobile: u,
                    mobileJoystick: f,
                    mobileJoystickActive: p
                } = I.getState();
                if (!(!a || l)) {
                    if (u && f)
                        if (p) {
                            const {
                                vector: {
                                    y: A
                                }
                            } = f;
                            e < 0 && (e = 0), e += A * i, a.currentY >= c ? a.currentY = c : a.currentY += e, he.setState({
                                scroll: a.completion
                            })
                        } else a.completion = a.completion, e = 0;
                    else he.setState({
                        scroll: a.completion,
                        deltaScroll: s
                    }), s = a.currentY / a.deltaY || 0;
                    a.update(), !l && requestAnimationFrame(o)
                }
            };
        x.useEffect(() => {
            const {
                scroll_path_init_length: a
            } = he.getState(), l = a / 1.5;
            return r(l), requestAnimationFrame(o), he.subscribe(u => u.disableScroll, u => {
                u === !1 && requestAnimationFrame(o)
            }), I.subscribe(u => u.country, (u, f) => {
                if (u !== f) {
                    const {
                        scroll_path_init_length: p
                    } = he.getState();
                    let A = 1.5,
                        v = u === "frlux" ? p * 2 : p;
                    v = u === "befr" ? p * 1.4 : v, v /= A, r(v)
                }
            })
        }, [])
    },
    ur = {
        log: "background-color:green; padding:5px; color:white"
    },
    nt = "__joysticks_identifiers__",
    Xe = "__active_joysticks__",
    Ln = {
        ALL: -1,
        LEFT: 0,
        MIDDLE: 1,
        RIGHT: 2
    };
class yl {
    JOYSTICK_TRANSITION = "border-radius 0.2s ease-in-out";
    options = {
        maxRange: 100,
        level: 10,
        radius: 50,
        joystickRadius: 30,
        opacity: .8,
        leftToRight: !0,
        bottomToUp: !0,
        containerClass: "",
        controllerClass: "",
        joystickClass: "",
        x: "50%",
        y: "50%",
        distortion: !1,
        dynamicPosition: !1,
        dynamicPositionTarget: null,
        disableX: !1,
        disableY: !1
    };
    onMove;
    x = 0;
    y = 0;
    leveledX = 0;
    leveledY = 0;
    angle = 0;
    distance = 0;
    style;
    id;
    container;
    controller;
    joystick;
    centerX;
    centerY;
    started;
    identifier = null;
    mouseButton = -1;
    constructor(e, t) {
        this.options = Object.assign(this.options, e), this.onMove = t, this.validate(), this.init()
    }
    validate() {
        window[Xe] && window[Xe].length > 0 && window[Xe].some(e => e.options.dynamicPosition && (e.options.dynamicPositionTarget || document) === (this.options.dynamicPositionTarget || document)) && console.error("Multiple dynamicPosition should be used with different target elements (dynamicPositionTarget) to prevent event collision.")
    }
    init() {
        window[nt] || (window[nt] = new Set), this.id = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15), window[Xe] = Object.assign(window[Xe] || [], [this]), this.style = document.createElement("style"), this.style.setAttribute("id", "style-" + this.id), this.style.innerHTML = `
        .joystick-container-${this.id} {
            box-sizing: border-box;
            position: fixed;
            outline: none;
            ${this.options.leftToRight?"left":"right"}: ${this.options.x};
            ${this.options.bottomToUp?"bottom":"top"}: ${this.options.y};
            transform: translate(${this.options.dynamicPosition||this.options.leftToRight?"-50%":"50%"}, ${this.options.dynamicPosition||!this.options.bottomToUp?"-50%":"50%"});
        }
    
        .joystick-controller-${this.id} {
            box-sizing: border-box;
            outline: none;
            opacity: ${this.options.opacity};
            width: ${this.options.radius*2}px;
            height: ${this.options.radius*2}px;
            border-radius: 50%;
            position: relative;
            outline: 2px solid #4c4c4c77;
            background: radial-gradient(circle,#ebebeb55, #5c5c5c55);
        }
    
        .joystick-${this.id} {
            box-sizing: border-box;
            outline: none;
            position: absolute;
            cursor: grab;
            width: ${this.options.joystickRadius*2}px;
            height: ${this.options.joystickRadius*2}px;
            z-index: 1;
            border-radius: 50%;
            left: 50%;
            bottom: 50%;
            transform: translate(-50%, 50%);
            background: radial-gradient(#000c, #3e3f46aa);
            transition: ${this.JOYSTICK_TRANSITION};
        }
        `, this.container = document.createElement("div"), this.container.setAttribute("id", "joystick-container-" + this.id), this.container.setAttribute("class", "__html joystick-container-" + this.id + " " + this.options.containerClass), this.controller = document.createElement("div"), this.controller.setAttribute("id", "joystick-controller-" + this.id), this.controller.setAttribute("class", "joystick-controller-" + this.id + " " + this.options.controllerClass), this.joystick = document.createElement("div"), this.joystick.setAttribute("id", "joystick-" + this.id), this.joystick.setAttribute("class", "joystick-" + this.id + " " + this.options.joystickClass), this.controller.appendChild(this.joystick), this.container.appendChild(this.controller), document.head.appendChild(this.style), !this.options.dynamicPosition && document.body.appendChild(this.container), this.addEventListeners(), this.recenterJoystick(), this.resetCoordinates()
    }
    addEventListeners = () => {
        const e = this.options.mouseClickButton;
        if ((typeof e == "string" && Object.keys(Ln).includes(e) || typeof e == "number" && e < 6 && e > -2) && (this.mouseButton = typeof e == "string" ? Ln[e] : e), this.options.dynamicPosition) {
            const t = this.options.dynamicPositionTarget || document;
            t.addEventListener("mousedown", this.dynamicPositioningMouse), document.addEventListener("mouseup", this.removeDynamicPositioning), t.addEventListener("touchstart", this.dynamicPositioningTouch), document.addEventListener("touchmove", this.onTouchEvent, {
                passive: !1
            }), document.addEventListener("touchend", this.removeDynamicPositioning), this.options.hideContextMenu && (t.addEventListener("contextmenu", i => i.preventDefault()), this.joystick.addEventListener("contextmenu", i => i.preventDefault()))
        } else this.joystick.addEventListener("touchstart", this.onStartEvent), this.joystick.addEventListener("touchmove", this.onTouchEvent), this.joystick.addEventListener("touchend", this.onStopEvent), this.joystick.addEventListener("mousedown", this.onStartEvent), this.options.hideContextMenu && (this.container.addEventListener("contextmenu", t => t.preventDefault()), this.joystick.addEventListener("contextmenu", t => t.preventDefault()));
        window.addEventListener("resize", this.recenterJoystick)
    };
    dynamicPositioningMouse = e => {
        if (this.identifier !== null || this.mouseButton !== -1 && e.button !== this.mouseButton) return;
        const t = e.x + "-" + e.y;
        if (window[nt].has(t)) return;
        this.identifier = t, window[nt].add(this.identifier);
        const i = e.clientX,
            n = e.clientY;
        this.container.style.left = i + "px", this.container.style.top = n + "px", this.container.style.bottom = "unset", this.container.style.right = "unset", document.body.appendChild(this.container), this.recenterJoystick(), this.onStartEvent(e, !1)
    };
    dynamicPositioningTouch = e => {
        if (this.identifier !== null) return;
        const t = e.changedTouches[0].identifier;
        if (window[nt].has(t)) return;
        this.identifier = t, window[nt].add(t);
        let i;
        for (let o = 0; o < e.touches.length; o++) {
            const a = e.touches.item(o);
            if (this.identifier === a.identifier) {
                i = a;
                break
            }
        }
        if (!i) return;
        const n = i.clientX,
            r = i.clientY;
        this.container.style.left = n + "px", this.container.style.top = r + "px", this.container.style.bottom = "unset", this.container.style.right = "unset", document.body.appendChild(this.container), this.recenterJoystick(), this.onStartEvent(e, !1)
    };
    removeDynamicPositioning = e => {
        if (this.identifier !== null) {
            if (e.type === "touchend") {
                const t = e.changedTouches[0].identifier;
                if (this.identifier !== t) return
            } else if (this.mouseButton !== -1 && e.button !== this.mouseButton) return;
            window[nt].delete(this.identifier), this.identifier = null, this.onStopEvent(e), this.container.remove()
        }
    };
    updateCoordinates = (e, t) => {
        this.distance = Math.sqrt(Math.pow(e - this.centerX, 2) + Math.pow(t - this.centerY, 2)).toFixed(4), this.distance *= .35, this.angle = Math.atan2(t - this.centerY, e - this.centerX).toFixed(4);
        const i = this.distance > this.options.maxRange ? this.options.maxRange : this.distance;
        this.x = this.options.disableX ? 0 : Math.round(Math.cos(this.angle) * i), this.y = this.options.disableY ? 0 : -Math.round(Math.sin(this.angle) * i), this.leveledX = Math.round(this.x / this.options.maxRange * this.options.level), this.leveledY = Math.round(this.y / this.options.maxRange * this.options.level), this.joystick.style.left = this.options.radius + this.x + "px", this.joystick.style.bottom = this.options.radius + this.y + "px", this.options.distortion && this.distortJoystick(), this.onMove && this.onMove({
            x: this.x,
            y: this.y,
            leveledX: this.leveledX,
            leveledY: this.leveledY,
            distance: this.distance,
            angle: this.angle
        })
    };
    resetCoordinates = () => {
        this.x = 0, this.y = 0, this.leveledX = 0, this.leveledY = 0, this.angle = 0, this.distance = 0, this.joystick.style.left = this.options.radius + "px", this.joystick.style.bottom = this.options.radius + "px", this.options.distortion && this.distortJoystick(), this.onMove && this.onMove({
            x: this.x,
            y: this.y,
            leveledX: this.leveledX,
            leveledY: this.leveledY,
            distance: this.distance,
            angle: this.angle
        })
    };
    distortJoystick = () => {
        this.distance > this.options.maxRange * .7 ? (this.joystick.style.borderRadius = "70% 80% 70% 15%", this.joystick.style.transform = `translate(-50%, 50%) rotate(${+this.angle+Math.PI/4}rad)`) : (this.joystick.style.borderRadius = "50%", this.joystick.style.transform = `translate(-50%, 50%) rotate(${Math.PI/4}rad})`)
    };
    onStartEvent = (e, t = !0) => {
        if (e.type === "mousedown") {
            if (this.mouseButton !== -1 && e.button !== this.mouseButton) return;
            window.addEventListener("mousemove", this.onMouseEvent), window.addEventListener("mouseup", this.onStopEvent)
        } else if (t) {
            const i = e.changedTouches[0].identifier;
            this.identifier = i
        }
        this.started = !0, this.joystick.style.transition = this.JOYSTICK_TRANSITION, this.joystick.style.cursor = "grabbing"
    };
    onStopEvent = e => {
        if (e.type === "mouseup") {
            if (this.mouseButton !== -1 && e.button !== this.mouseButton) return;
            window.removeEventListener("mousemove", this.onMouseEvent), window.removeEventListener("mouseup", this.onStopEvent)
        } else this.identifier = null;
        this.started = !1, this.joystick.style.transition = "all 0.2s ease-in-out", this.joystick.style.cursor = "grab", this.resetCoordinates()
    };
    onTouchEvent = e => {
        let t;
        for (let r = 0; r < e.touches.length; r++) {
            const o = e.touches.item(r);
            if (this.identifier === o.identifier) {
                t = o;
                break
            }
        }
        if (!t) return;
        e.preventDefault();
        const i = t.clientX,
            n = t.clientY;
        this.updateCoordinates(i, n)
    };
    onMouseEvent = e => {
        if (!this.started) return;
        e.preventDefault();
        const t = e.clientX,
            i = e.clientY;
        this.updateCoordinates(t, i)
    };
    recenterJoystick = () => {
        this.centerX = this.controller.getBoundingClientRect().left + this.options.radius, this.centerY = this.controller.getBoundingClientRect().top + this.options.radius
    };
    destroy() {
        if (this.options.dynamicPosition) {
            const e = this.options.dynamicPositionTarget || document;
            e.removeEventListener("mousedown", this.dynamicPositioningMouse), document.removeEventListener("mouseup", this.removeDynamicPositioning), e.removeEventListener("touchstart", this.dynamicPositioningTouch), document.removeEventListener("touchmove", this.onTouchEvent, {
                passive: !1
            }), document.removeEventListener("touchend", this.removeDynamicPositioning)
        } else this.joystick.removeEventListener("touchstart", this.onStartEvent), this.joystick.removeEventListener("touchmove", this.onTouchEvent), this.joystick.removeEventListener("touchend", this.onStopEvent), this.joystick.removeEventListener("mousedown", this.onStartEvent);
        window.removeEventListener("resize", this.recenterJoystick), this.style.remove(), this.container.remove(), Array.isArray(window[Xe]) && (window[Xe] = window[Xe].filter(e => e !== this))
    }
}
const bl = () => {
    const s = X(i => i.scene),
        {
            isMobile: e
        } = or(),
        t = .8;
    if (!e) return null;
    console.log("%c useMobile Hook", ur.log), x.useEffect(() => {
        e && (I.setState({
            mobile: !0
        }), document.documentElement.classList.add("mobile"), new yl({
            radius: 45,
            joystickRadius: 25,
            disableX: !0,
            maxRange: 40,
            level: 1,
            y: "10%",
            x: "25%",
            containerClass: "joystick"
        }, n => {
            const r = document.querySelector(".joystick"),
                o = n.y / 40;
            o > .2 && r ? .classList.add("disable-notification"), I.setState({
                mobileJoystick: {
                    vector: {
                        x: 0,
                        y: o
                    }
                }
            })
        }))
    }, [e]), x.useEffect(() => I.subscribe(i => i.fr_component_loaded, () => {
        setTimeout(() => {
            s.getObjectByName("world") ? .translateX(-t)
        }, 2e3)
    }), []), x.useEffect(() => I.subscribe(i => i.teleportation, () => {
        const {
            country: i
        } = I.getState();
        if (i !== "fr") {
            const n = s.getObjectByName("world");
            n && (n.position.x = 0)
        }
    }), []), Fe(({
        scene: i
    }) => {
        const {
            country: n
        } = I.getState(), {
            scroll: r
        } = he.getState();
        if (n === "fr") {
            const o = i.getObjectByName("world"),
                a = t - r * t;
            o && (o.position.x = -a)
        }
        if (n === "befr2") {
            const o = i.getObjectByName("world"),
                a = t + r * t;
            o && (o.position.x = -a)
        }
    })
};

function Yl(s) {
    return new Pe(...s)
}

function Xl(s) {
    return new Pn(...s)
}

function jl(s = !0) {
    s && !document.querySelector("#root") ? .classList.contains("active") && document.querySelector("#root") ? .classList.add("active"), !s && document.querySelector("#root") ? .classList.contains("active") && document.querySelector("#root") ? .classList.remove("active")
}

function wn(s) {
    const e = new So;
    return e.setPath(s), e.load(["px.png", "nx.png", "py.png", "ny.png", "pz.png", "nz.png"])
}

function Ql(s) {
    const e = s ? .getObjectByName("vespaInner"),
        t = s ? .getObjectByName("world");
    if (!e) return !1;
    if (e) try {
        const i = e.children.find(({
            userData: n
        }) => n.name === "sebastien");
        if (i) return i.removeFromParent(), t.add(i), !0
    } catch (i) {
        return console.error("Erreur fichier Vespa.tsx - L57", i), !1
    }
}

function Vl(s, e) {
    const {
        mobile: t
    } = I.getState(), i = wn(t ? "/hdri/sunrise/mobile/" : "/hdri/sunrise/"), n = wn(t ? "/hdri/sunshine/mobile/" : "/hdri/sunshine/"), {
        fog: r
    } = s;
    e === "sunshine" && (s.background = n, s.environment = n, r instanceof Qi && (r.color.set("hsl(196,70%,63%)"), r.far = 430)), e === "sunrise" && (s.background = i, s.environment = i, r instanceof Qi && (r.color.set("hsl(325,15%,45%)"), r.far = I.getState().fog_init_value))
}

function fs(s, e = [], t = []) {
    e.forEach(i => {
        const n = s.getObjectByName(i);
        n && (n.visible = !0)
    }), t.forEach(i => {
        const n = s.getObjectByName(i);
        n && (n.visible = !1)
    })
}
const Sl = () => {
        const s = X(a => a.scene),
            e = 2.4,
            t = .004,
            i = x.useRef({
                value: 0
            }),
            n = x.useRef(!1),
            r = Ci();
        x.useEffect(() => I.subscribe(a => a.transition, a => {
            const c = document.getElementById("preloader"),
                l = document.querySelector(".cursor-scroll"),
                {
                    country: u
                } = I.getState();
            if (a === "onEnter" && (setTimeout(() => {
                    l ? .classList.add("cursor-scroll--hidden")
                }, 500), r.play("soundTransition")), a === "onExit" && (n.current = !0), a === "onEnterFinish") switch (u) {
                case "fr":
                    fs(s, ["countryFrance"], ["countryBelgium", "countryLuxembourg"]);
                    break;
                case "frlux":
                    fs(s, ["countryFrance", "countryLuxembourg"], ["countryBelgium"]);
                    break;
                case "lux":
                    fs(s, ["countryLuxembourg"], ["countryBelgium", "countryFrance"]);
                    break;
                case "befr":
                    fs(s, ["countryBelgium"], ["countryFrance", "countryLuxembourg"]);
                    break
            }
            a === "onExitFinish" && setTimeout(() => {
                l ? .classList.remove("cursor-scroll--hidden"), c ? .classList.remove("preloader--france"), c ? .classList.remove("preloader--luxembourg"), c ? .classList.remove("preloader--belgium")
            }, 4e3)
        }), []);
        let o = 0;
        return Fe(({
            camera: a,
            clock: c
        }, l) => {
            const u = document.getElementById("preloader"),
                {
                    transition: f
                } = I.getState();
            if (!f) return;
            const {
                country: p
            } = I.getState();
            if (f === "onEnter" && i.current.value > 0) {
                if (ge(i.current, "value", 0, e, l, t, A => Wi.inOut(A)), I.setState({
                        transitionProgress: i.current.value
                    }), i.current.value < .13 && i.current.value > .12) switch (p) {
                    case "fr":
                        u ? .classList.add("preloader--france");
                        break;
                    case "frlux":
                        u ? .classList.add("preloader--france");
                        break;
                    case "lux":
                        u ? .classList.add("preloader--luxembourg");
                        break;
                    case "luxbe":
                        u ? .classList.add("preloader--luxembourg");
                        break;
                    case "befr":
                        u ? .classList.add("preloader--belgium");
                        break
                }
                a.zoom = o - _i(o - i.current.value, 0, 1) * .15, a.updateProjectionMatrix(), i.current.value === 0 && I.setState({
                    transition: "onEnterFinish"
                })
            }
            f === "onExit" && i.current.value < 1 && (ge(i.current, "value", 1, e, l, t, A => Wi.inOut(A)), I.setState({
                transitionProgress: i.current.value
            }), o = a.zoom, isNaN(i.current.value) ? (i.current.value = 0, I.setState({
                transition: "onExit"
            })) : (i.current.value > .13 && u ? .removeAttribute("class"), i.current.value === 1 && I.setState({
                transition: "onExitFinish"
            }))), a.zoom < 1 && n.current && (ge(a, "zoom", 1, .9, l), a.updateProjectionMatrix()), ["onEnterFinish", "onExitFinish"].some(A => A === f) && (I.setState({
                transition: null
            }), "__damp" in i.current && delete i.current.__damp)
        }), null
    },
    Ml = () => {
        const s = gs("texture/transition-country.jpg"),
            e = gs("texture/transition-enter.jpg"),
            t = x.useRef(null),
            i = x.useRef(null),
            n = x.useRef(null),
            r = ma({
                uTime: 0,
                uCountry: 0,
                uColor: new ve("hsl(0,0%,76%)"),
                uTextureCountry: s,
                uTextureEnter: e,
                uTransition: 0,
                uTransitionNumber: 0,
                uResolution: new Z(innerWidth, innerHeight)
            }, `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = vec4(position, 1.0);
        }
      `, `
        uniform float uTime;
        uniform int uCountry; // 1 = fr - 2 = frlux - 3 = lux - 4 = befr
        uniform vec3 uColor;
        uniform vec2 uResolution;
        uniform sampler2D uTextureCountry;
        uniform sampler2D uTextureEnter;
        uniform float uTransition;
        uniform int uTransitionNumber;
        varying vec2 vUv;
        const float MASK_BORDER_BLUR = 0.035;
        vec3 ContrastSaturationBrightness(vec3 color, float brt, float sat, float con)
          {
            const float AvgLumR = 0.5;
            const float AvgLumG = 0.5;
            const float AvgLumB = 0.5;
            const vec3 LumCoeff = vec3(0.2125, 0.7154, 0.0721);
            vec3 AvgLumin  = vec3(AvgLumR, AvgLumG, AvgLumB);
            vec3 brtColor  = color * brt;
            vec3 intensity = vec3(dot(brtColor, LumCoeff));
            vec3 satColor  = mix(intensity, brtColor, sat);
            vec3 conColor  = mix(AvgLumin, satColor, con);
            return conColor;
          }
  
        float maskFalloff(float _input, float start, float end, float margin, float progress){
          float p=mix(start-margin, end, progress);
          return smoothstep(p + margin, p, _input);
        }
  
        void main() {
          vec3 color = uColor;
          vec2 uv = vUv - 0.5;
          uv *= uResolution / max(uResolution.x, uResolution.y);
          uv += 0.5;
          vec4 textureCountry = texture2D(uTextureCountry, uv);
          vec4 textureEnter = texture2D(uTextureEnter, uv);
          float t = 0.0;
          if(uTransitionNumber == 2) {
            t = 1.0 - textureEnter.g;
          } else {
            if(uCountry == 0) {
              t = 1.0 - textureCountry.r;
            }
            if(uCountry == 1) {
              t = 1.0 - textureCountry.g;
            }  
            if(uCountry == 2) {
              t = 1.0 - textureCountry.b;
            }
          }
          float mask =  max(1.0 - maskFalloff(t, 0.0, 1.0, MASK_BORDER_BLUR, uTransition),0.0);
          color = ContrastSaturationBrightness(color, 2.2, 0.45, 1.0);
          gl_FragColor.rgba = vec4(color * 0.58, mask);
          #include <colorspace_fragment>
        }
      `);
        Sl();
        let o = {
            value: 0
        };
        return x.useEffect(() => {
            const a = Ci();
            return I.subscribe(c => c.scene_loaded_after_progress, () => {
                const c = document.documentElement,
                    l = document.getElementById("preloader"),
                    u = document.querySelector(".preloader-enter"),
                    f = u.querySelector(".button-start");
                l.classList.add("end"), l.addEventListener("transitionend", A => {
                    const {
                        propertyName: v,
                        pseudoElement: _
                    } = A;
                    v === "clip-path" && _ === "::before" && p()
                }, !1);

                function p() {
                    console.log("%c Scene Loaded", ur.log), i.current = document.querySelectorAll(".__html"), f.addEventListener("click", A => {
                        A.preventDefault();
                        const v = document.querySelector(".main-title"),
                            _ = l.querySelector(".city"),
                            T = l.querySelector("code"),
                            g = l.querySelector("div.active"),
                            B = document.getElementById("awards");
                        T.remove(), g.remove(), _.remove(), v && v.classList.add("active"), c.classList.add("html--loaded"), B.classList.add("end"), B.addEventListener("transitionend", () => {
                            B.remove()
                        }, !1), I.setState({
                            transition: "onExit",
                            isSoundsMuted: !1
                        }), setTimeout(() => {
                            a.playAll(), document.querySelector(".cursor-scroll").classList.remove("cursor-scroll--hidden"), u.remove()
                        }, 2e3)
                    }, !1)
                }
            })
        }, []), x.useEffect(() => I.subscribe(a => a.transitionCountry, a => {
            switch (i.current = document.querySelectorAll(".__html"), a) {
                case "frlux":
                    n.current.uniforms.uCountry.value = 0;
                    break;
                case "lux":
                    n.current.uniforms.uCountry.value = 1;
                    break;
                case "luxbe":
                    n.current.uniforms.uCountry.value = 1;
                    break;
                case "be":
                    n.current.uniforms.uCountry.value = 2;
                    break;
                case "befr":
                    n.current.uniforms.uCountry.value = 2;
                    break;
                default:
                    n.current.uniforms.uCountry.value = 0;
                    break
            }
        }, {
            fireImmediately: !0
        }), []), x.useEffect(() => he.subscribe(a => a.scroll, a => {
            const {
                country: c
            } = I.getState();
            c === "frlux" && a > .34 && (n.current.uniforms.uCountry.value = 1)
        }), []), x.useEffect(() => {
            I.subscribe(a => a.transition, a => {
                const c = document.documentElement;
                switch (a) {
                    case "onEnter":
                        c.classList.add("isTransition");
                        break;
                    case "onExit":
                        c.classList.remove("isTransition");
                        break
                }
            })
        }, []), x.useEffect(() => {
            I.subscribe(a => a.transitionProgress, a => {
                i.current && i.current.forEach(c => {
                    c.style.opacity = Math.pow(a, 8)
                })
            })
        }, []), Fe(({
            camera: a,
            clock: c
        }, l) => {
            const u = document.getElementById("preloader"),
                {
                    transitionProgress: f,
                    transition: p,
                    scene_load_progress: A,
                    scene_loaded_after_progress: v
                } = I.getState();
            let _ = null,
                T = 0;
            switch (p) {
                case "onEnter":
                    _ = 1;
                    break;
                case "onExit":
                    _ = 2;
                    break
            }
            if (t.current && t.current.position.copy(a.position.clone()), n.current && (n.current.uniforms.uTime.value = c.getElapsedTime(), n.current.uniforms.uResolution.value.x = innerWidth, n.current.uniforms.uResolution.value.y = innerHeight, n.current.uniforms.uTransition.value = f, n.current.uniforms.uTransitionNumber.value = _), +A <= 1 && !v) {
                ge(o, "value", A, 1.2, l);
                const g = u.querySelector("code");
                T = Math.round(o.value.toFixed(2) * 100);
                const B = T.toString().padStart(3, "0");
                g.innerText = B
            } + T >= 100 && !v && I.setState({
                scene_loaded_after_progress: !0
            })
        }), vi({
            IntroTransitionMaterial: r
        }), L.jsx(L.Fragment, {
            children: L.jsxs("mesh", {
                "position-z": -5,
                ref: t,
                renderOrder: 2,
                children: [L.jsx("planeGeometry", {
                    args: [2, 2]
                }), L.jsx("introTransitionMaterial", {
                    ref: n,
                    transparent: !0,
                    toneMapped: !1,
                    depthTest: !1,
                    depthWrite: !1
                })]
            })
        })
    },
    Rl = () => {
        const s = Ci(),
            e = ae.useRef(null),
            t = ae.useRef(null),
            i = ae.useRef(null),
            n = ae.useRef(null),
            r = ae.useRef(null),
            o = ae.useRef(null),
            a = ae.useRef(null),
            c = ae.useRef(null);
        x.useEffect(() => {
            e.current && (e.current.setVolume(.15), I.setState({
                soundTheme: e.current
            })), t.current && (t.current.setVolume(0), I.setState({
                soundWind: t.current
            })), i.current && (i.current.setVolume(.35), I.setState({
                soundBreakpoint: r.current
            })), o.current && I.setState({
                soundSkills: o.current
            }), a.current && (a.current.setVolume(.85), I.setState({
                soundWhoosh: a.current
            })), c.current && (c.current.setVolume(.25), I.setState({
                soundTransition: c.current
            })), i.current && (i.current.setVolume(.25), i.current.setPlaybackRate(1.5), I.setState({
                soundButtonHovered: i.current
            })), n.current && I.setState({
                soundButtonClicked: n.current
            })
        }, [e, t, i, n]), x.useEffect(() => I.subscribe(u => u.country, u => {
            u === "befr2" && s.play("soundBreakpoint")
        }), []);
        let l = 0;
        return x.useEffect(() => he.subscribe(u => u.scroll, u => {
            const {
                country: f
            } = I.getState(), p = _i((u - l) * 500, 0, 1);
            t.current.setVolume(p * 2), f === "fr" && u > .96 && u > .9601 && s.play("soundBreakpoint"), l = u
        }), []), L.jsxs("group", {
            children: [L.jsx(ze, {
                ref: e,
                url: "/sounds/theme.m4a",
                loop: !0
            }), L.jsx(ze, {
                ref: t,
                url: "/sounds/wind.mp3",
                loop: !0
            }), L.jsx(ze, {
                ref: i,
                url: "/sounds/buttonHover.mp3",
                loop: !1
            }), L.jsx(ze, {
                ref: n,
                url: "/sounds/buttonClick.mp3",
                loop: !1
            }), L.jsx(ze, {
                ref: r,
                url: "/sounds/breakpoint.mp3",
                loop: !1
            }), L.jsx(ze, {
                ref: o,
                url: "/sounds/skills.mp3",
                loop: !1
            }), L.jsx(ze, {
                ref: a,
                url: "/sounds/whoosh.mp3",
                loop: !1
            }), L.jsx(ze, {
                ref: c,
                url: "/sounds/transition.mp3",
                loop: !1
            })]
        })
    },
    xl = x.lazy(() => Bs(() =>
        import ("./CountryFrance-CABRcqX6.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]))),
    Dl = ae.lazy(() => Bs(() =>
        import ("./CountryLuxembourg-B78eat4a.js"), __vite__mapDeps([10, 1, 2, 7]))),
    Ol = ae.lazy(() => Bs(() =>
        import ("./CountryBelgium-BSndXaUR.js"), __vite__mapDeps([11, 1, 2, 7, 12, 8]))),
    Il = x.lazy(() => Bs(() =>
        import ("./Model-CftzVF03.js"), __vite__mapDeps([13, 1, 2]))),
    Fl = () => (Tl(), L.jsx(L.Fragment, {})),
    Ul = () => {
        const s = innerWidth > innerHeight ? innerWidth / innerHeight : innerHeight / innerWidth,
            {
                mobile: e
            } = I.getState(),
            t = I(r => r.country),
            i = x.useRef(null),
            n = x.useRef(null);
        return ae.useEffect(() => {
            i.current && (e ? i.current.setFocalLength(I.getState().camera_fov_init / 1.2) : i.current.setFocalLength(I.getState().camera_fov_init / s))
        }, []), ae.useEffect(() => {
            I.setState({
                currentCamera: t ? i.current : n.current
            })
        }, [t]), t ? L.jsx(va, {
            name: "mainCamera",
            zoom: .8,
            ref: i,
            makeDefault: !0
        }) : L.jsx(_a, {
            ref: n,
            makeDefault: !0
        })
    },
    Ll = () => {
        const {
            isMobile: s,
            tier: e
        } = or(), t = x.useRef(null);
        return x.useEffect(() => I.subscribe(i => i.country, i => {
            (i === "fr" || i === "befr2") && (t.current.color.set("hsl(325,15%,45%)"), t.current.near = 0, t.current.far = I.getState().fog_init_value)
        }), []), x.useEffect(() => {
            Vi.onProgress = function(i, n, r) {
                const o = n / 45;
                o <= 1 && I.setState({
                    scene_load_progress: o
                })
            }, Vi.onLoad = function() {
                setTimeout(() => {
                    I.setState({
                        scene_loaded: !0
                    })
                }, 1e3)
            }, I.setState({
                fog: t.current
            })
        }, []), L.jsxs(L.Fragment, {
            children: [L.jsx(Ml, {}), bl(), L.jsx("fog", {
                attach: "fog",
                ref: t,
                args: ["hsl(325,15%,45%)", 0, I.getState().fog_init_value]
            }), L.jsxs(x.Suspense, {
                fallback: null,
                children: [L.jsxs("group", {
                    name: "world",
                    children: [L.jsx(xl, {}), L.jsx(Il, {}), L.jsx(Dl, {}), L.jsx(Ol, {})]
                }), L.jsx(Ul, {}), L.jsx(Rl, {}), L.jsx(Fl, {}), L.jsx(Fa, {
                    pixelated: !0
                }), L.jsx(Ua, {}), L.jsx(Ia, {})]
            }), e >= 3 && L.jsx(L.Fragment, {
                children: L.jsxs($c, {
                    disableNormalPass: !0,
                    children: [L.jsx(cl, {}), L.jsx(nl, {}), L.jsx(dl, {}), L.jsx(sl, {
                        mipmapBlur: !0,
                        luminanceThreshold: .6,
                        intensity: .8,
                        luminanceSmoothing: .2
                    })]
                })
            })]
        })
    };
ht.preload(I.getState().fr_glb_path);
ht.preload(I.getState().lu_glb_path);
ht.preload(I.getState().be_glb_path);
ht.preload("gltf/model.glb");
const Wl = Object.freeze(Object.defineProperty({
    __proto__: null,
    default: Ll
}, Symbol.toStringTag, {
    value: "Module"
}));
export {
    Wl as S, Xt as _, ht as a, jl as b, Vl as c, Nl as d, ge as e, Hl as f, Gl as g, _i as h, Pl as i, gs as j, Aa as k, ur as l, ma as m, Yl as n, Xl as o, Ql as p, fs as s, or as u, Oo as v
};