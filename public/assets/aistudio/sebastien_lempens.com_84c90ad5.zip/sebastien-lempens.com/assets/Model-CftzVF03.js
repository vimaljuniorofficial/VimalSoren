const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/Sebastien-CYkykiHx.js", "assets/index-DjXkBzPf.js", "assets/index-CaPdr700.css", "assets/useMouse-CXoH0j_u.js", "assets/useAnimation-CGFVWVoT.js", "assets/Scene-CdCGEhkU.js", "assets/Vespa-CT6SydAo.js", "assets/shapes-B93sfIzn.js", "assets/Birds-CinhSofb.js", "assets/SkeletonUtils-bL-kYfaA.js", "assets/Cat-DFzg-iEi.js"]))) => i.map(i => d[i]);
import {
    aM as l,
    aK as o,
    ab as e,
    aT as t
} from "./index-DjXkBzPf.js";
import {
    l as n,
    a as r
} from "./Scene-CdCGEhkU.js";
const _ = e.lazy(() => t(() =>
        import ("./Sebastien-CYkykiHx.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5]))),
    d = e.lazy(() => t(() =>
        import ("./Vespa-CT6SydAo.js"), __vite__mapDeps([6, 1, 2, 5, 4, 7]))),
    i = e.lazy(() => t(() =>
        import ("./Birds-CinhSofb.js"), __vite__mapDeps([8, 1, 2, 4, 9, 5]))),
    c = e.lazy(() => t(() =>
        import ("./Cat-DFzg-iEi.js"), __vite__mapDeps([10, 1, 2, 4, 5]))),
    m = () => {
        console.log("%c Model Component Loaded", n.log);
        const a = r("gltf/model.glb"),
            {
                animations: s
            } = a;
        return e.useEffect(() => {
            l.setState({
                mesh_animations: s
            })
        }, []), o.jsx(o.Fragment, {
            children: o.jsxs(e.Suspense, {
                fallback: null,
                children: [o.jsx(_, {}), o.jsx(d, {}), o.jsx(i, {}), o.jsx(c, {})]
            })
        })
    },
    x = () => l(s => s.scene_loaded) ? o.jsx(m, {}) : o.jsx(o.Fragment, {});
export {
    x as
    default
};