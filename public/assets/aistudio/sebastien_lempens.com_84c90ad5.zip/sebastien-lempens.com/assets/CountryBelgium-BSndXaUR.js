const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/Cars-bQygneYV.js", "assets/index-DjXkBzPf.js", "assets/index-CaPdr700.css", "assets/Scene-CdCGEhkU.js", "assets/Clone-DlEjDv1t.js", "assets/SkeletonUtils-bL-kYfaA.js", "assets/Buildings-BAATLfJU.js", "assets/Buttons-Bu6-RSra.js", "assets/Html-DewR4ynt.js", "assets/Credits-Fnp023Ib.js", "assets/Billboard-BFaQTabQ.js"]))) => i.map(i => d[i]);
import {
    ab as r,
    ac as R,
    am as x,
    aM as o,
    aK as i,
    w as H,
    aT as E,
    aN as m
} from "./index-DjXkBzPf.js";
import {
    a as j,
    l as k,
    s as A,
    c as P,
    b as S,
    e as L,
    f as v,
    g as M,
    h as F,
    i as G
} from "./Scene-CdCGEhkU.js";
import {
    u as J
} from "./useAnimation-CGFVWVoT.js";
import {
    C as Y,
    a as Z
} from "./Cloud-qp0Oh7DW.js";
import "./deprecated-yOBBLatR.js";
const K = () => {
        const u = r.useRef(null);
        return r.useRef(), R(({
            scene: a
        }) => a), r.useEffect(() => {}, []), x(() => {
            const a = o.getState().country;
            u.current && (u.current.intensity = a === "be" || a === "befr" ? 3 : 0)
        }), i.jsx(i.Fragment, {
            children: i.jsx("directionalLight", {
                ref: u,
                color: "#fffceb",
                intensity: 0,
                position: [80, 180, -50],
                "shadow-bias": -1e-4,
                "shadow-mapSize-width": 4096,
                "shadow-mapSize-height": 4096,
                "shadow-camera-top": 100,
                "shadow-camera-bottom": 0,
                "shadow-camera-right": -100,
                "shadow-camera-left": -200,
                "shadow-camera-near": 200,
                "shadow-camera-far": 300,
                castShadow: !0
            })
        })
    },
    X = r.lazy(() => E(() =>
        import ("./Cars-bQygneYV.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5]))),
    Q = r.lazy(() => E(() =>
        import ("./Buildings-BAATLfJU.js"), __vite__mapDeps([6, 1, 2, 3]))),
    U = r.lazy(() => E(() =>
        import ("./Buttons-Bu6-RSra.js"), __vite__mapDeps([7, 1, 2, 3, 8]))),
    W = r.lazy(() => E(() =>
        import ("./Credits-Fnp023Ib.js"), __vite__mapDeps([9, 1, 2, 10, 3, 8]))),
    $ = () => {
        const {
            be_cameras_animations: u
        } = o.getState(), a = R(t => t.scene), e = R(t => t.camera), [n] = u ? .filter(({
            name: t
        }) => t === "cameraBelgium"), [c, h] = J("cameraBelgium", e, n), y = 20, _ = 320, d = 170, g = 5, w = 175, C = .7, N = .8;
        r.useEffect(() => o.subscribe(t => t.country, t => {
            const {
                mobile: s
            } = o.getState();
            if (t === "be" && (A(a, ["countryBelgium"], ["countryFrance", "countryLuxembourg"]), P(a, "sunshine"), e.rotation.set(-Math.PI / 2, 0, 0), e.position.set(y, _, d), c.reset().play().paused = !0, document.querySelector(".white-plane") ? .style.setProperty("opacity", "1")), t === "befr") S(!1), A(a, ["countryBelgium"], ["countryFrance", "countryLuxembourg"]), s && o.setState({
                mobileJoystickActive: !0
            }), c.reset().play().paused = !0, document.querySelector(".white-plane") ? .style.setProperty("opacity", "0");
            else {
                const l = e.position.clone(),
                    f = e.rotation.clone();
                c.stop(), e.position.set(...l.toArray()), e.rotation.set(f.x, f.y, f.z)
            }
            t === "befr2" && (A(a, ["countryFrance"], ["countryBelgium", "countryLuxembourg"]), P(a, "sunrise"), e.position.set(19.844941842606527, 12.838312671280597, 72.3329748544212), document.querySelector(".white-plane") ? .style.setProperty("opacity", "1")), ["fr", "frlux", "lu"].includes(t) && document.querySelector(".white-plane") ? .style.setProperty("opacity", "0")
        }, {
            fireImmediately: !0
        }), []), r.useEffect(() => o.subscribe(t => t.teleportation, t => {
            const {
                country: s
            } = o.getState();
            t && s === "befr" && (P(a, "sunshine"), e.position.set(y, g, w), e.rotation.set(0, 0, 0))
        }), []), r.useEffect(() => m.subscribe(t => t.scroll, t => {
            const {
                country: s
            } = o.getState();
            s === "befr" && (t > .05 ? S() : S(!1)), s === "luxbe" && t > .35 && S()
        }), []);
        let O = !1,
            T = !1,
            B = !1;
        return x((t, s) => {
            const {
                country: l,
                camera_position_init: f,
                camera_rotation_init: z,
                mobile: I
            } = o.getState(), {
                scroll: p
            } = m.getState();
            if (l === "be")
                if (O) {
                    const b = document.querySelector(".white-plane");
                    b && L(b.style, "opacity", 0, 1, s);
                    const D = F((p - C) / (N - C), 0, 1),
                        q = Math.PI / 2 - Math.PI / 2 * D;
                    v(e.rotation, [-q, e.rotation.y, e.rotation.z], .4, s), e.position.z = d - (d - w) * p, p < .8 ? e.position.y = _ - (_ - g) * p : (I && o.setState({
                        mobileJoystickActive: !1
                    }), M(e.position, [y, g, w], .75, s, .65, V => G.inOut(V)), e.position.y <= g && o.setState({
                        country: "befr"
                    }))
                } else m.getState().scrollHandler.reset(), O = !0;
            if (l === "befr" && (T ? p >= .91 ? o.setState({
                    country: "befr2"
                }) : (c.time = c.getClip().duration * p, h && h.update(s)) : (m.getState().scrollHandler.reset(), T = !0)), l === "befr2")
                if (B) {
                    I && o.setState({
                        mobileJoystickActive: !1
                    }), M(e.position, f.fr, .6, s), v(e.rotation, z.fr, .6, s);
                    const b = document.querySelector(".white-plane");
                    b && L(b.style, "opacity", 0, 1, s), e.position.z === f.fr[2] && o.setState({
                        country: "fr"
                    })
                } else m.getState().scrollHandler.reset(), m.setState({
                    scroll: 1
                }), B = !0
        }), !1
    },
    ae = () => {
        const {
            animations: u
        } = j(o.getState().be_glb_path), a = o(n => n.be_component_loaded), e = r.useRef(null);
        return r.useEffect(() => o.subscribe(n => n.country, n => {
            n === "be" && e.current && (e.current.visible = !0)
        }), []), r.useEffect(() => o.subscribe(n => n.teleportation, n => {
            const {
                country: c
            } = o.getState();
            n && (c === "lux" && e.current && (e.current.visible = !0), c === "befr" && e.current && (e.current.visible = !1))
        }), []), r.useEffect(() => {
            o.setState({
                be_cameras_animations: u,
                be_component_loaded: !0
            }), console.log("%c Belgium Component Loaded", k.log)
        }, []), x((n, c) => {
            const {
                scroll: h
            } = m.getState(), {
                country: y
            } = o.getState();
            if (y === "be") {
                const _ = F((.8 - h) / .1499999999999999, 0, 1);
                if (e.current) {
                    const d = e.current.getObjectByProperty("type", "Mesh");
                    d.material.opacity = _
                }
            }
        }), i.jsxs("group", {
            name: "countryBelgium",
            visible: !1,
            children: [i.jsx(Q, {}), i.jsx(X, {}), i.jsx(U, {}), i.jsx(W, {}), i.jsx(K, {}), i.jsx(Y, {
                ref: e,
                texture: "texture/cloud.png",
                position: [20, 180, 180],
                material: H,
                renderOrder: -1,
                children: i.jsx(Z, {
                    concentrate: "random",
                    seed: 4,
                    speed: .4,
                    smallestVolume: 1,
                    segments: 200,
                    opacity: 1,
                    bounds: [30, 80, 30],
                    volume: 30,
                    scale: 2,
                    fade: 50
                })
            }), a && i.jsx($, {})]
        })
    };
j.preload(o.getState().be_glb_path);
export {
    ae as
    default
};