const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/Buildings-BKYUSQmL.js", "assets/index-DjXkBzPf.js", "assets/index-CaPdr700.css", "assets/Scene-CdCGEhkU.js", "assets/Bridges-TUHD1og8.js", "assets/BigWheel-CFdhQiU-.js", "assets/Clone-DlEjDv1t.js", "assets/SkeletonUtils-bL-kYfaA.js", "assets/EiffelTower-YKGT_MbS.js", "assets/Floor-YVn1hsyq.js", "assets/Lights-CsIaKWVG.js", "assets/River-Do6bCd_6.js", "assets/HtmlTitle-BnxYPVZT.js", "assets/Billboard-BFaQTabQ.js", "assets/Html-DewR4ynt.js"]))) => i.map(i => d[i]);
import {
    A as br,
    aU as Wt,
    ag as Tr,
    v as jt,
    aV as Vr,
    aj as Me,
    al as Le,
    aW as je,
    m as Ae,
    aX as or,
    aY as Yt,
    q as ke,
    aD as Kr,
    Y as $t,
    aZ as Qr,
    ai as Jr,
    a_ as gr,
    a$ as Xt,
    b0 as qt,
    aB as Cr,
    a3 as Xe,
    w as Vt,
    b1 as Kt,
    b2 as Qt,
    b3 as Jt,
    b4 as ea,
    au as Ir,
    L as ra,
    b5 as ta,
    b6 as jr,
    av as aa,
    F as mr,
    aF as na,
    a as Ze,
    ac as qe,
    ab as L,
    ae as _r,
    b7 as ia,
    b8 as sa,
    aQ as oa,
    aq as la,
    as as ca,
    am as Rr,
    b9 as ua,
    ba as Yr,
    aM as fe,
    bb as ha,
    aN as Ye,
    aK as U,
    aI as $r,
    aT as He
} from "./index-DjXkBzPf.js";
import {
    v as et,
    _ as da,
    u as rt,
    a as pa,
    l as fa,
    b as dr,
    s as va,
    c as ma
} from "./Scene-CdCGEhkU.js";
import {
    u as ga
} from "./useMouse-CXoH0j_u.js";
import {
    BuildSpans as pr
} from "./HtmlTitle-BnxYPVZT.js";
import {
    B as tr
} from "./Billboard-BFaQTabQ.js";
import {
    H as ar
} from "./Html-DewR4ynt.js";
import {
    u as _a
} from "./useAnimation-CGFVWVoT.js";
import {
    s as wa,
    L as ya
} from "./deprecated-yOBBLatR.js";
import {
    P as Ea
} from "./shapes-B93sfIzn.js";
var Ie = Uint8Array,
    Pe = Uint16Array,
    Mr = Uint32Array,
    tt = new Ie([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0, 0]),
    at = new Ie([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 0, 0]),
    Sa = new Ie([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]),
    nt = function(n, t) {
        for (var i = new Pe(31), s = 0; s < 31; ++s) i[s] = t += 1 << n[s - 1];
        for (var l = new Mr(i[30]), s = 1; s < 30; ++s)
            for (var d = i[s]; d < i[s + 1]; ++d) l[d] = d - i[s] << 5 | s;
        return [i, l]
    },
    it = nt(tt, 2),
    st = it[0],
    Ia = it[1];
st[28] = 258, Ia[258] = 28;
var Ma = nt(at, 0),
    xa = Ma[0],
    xr = new Pe(32768);
for (var ae = 0; ae < 32768; ++ae) {
    var Be = (ae & 43690) >>> 1 | (ae & 21845) << 1;
    Be = (Be & 52428) >>> 2 | (Be & 13107) << 2, Be = (Be & 61680) >>> 4 | (Be & 3855) << 4, xr[ae] = ((Be & 65280) >>> 8 | (Be & 255) << 8) >>> 1
}
var sr = (function(n, t, i) {
        for (var s = n.length, l = 0, d = new Pe(t); l < s; ++l) ++d[n[l] - 1];
        var c = new Pe(t);
        for (l = 0; l < t; ++l) c[l] = c[l - 1] + d[l - 1] << 1;
        var v;
        if (i) {
            v = new Pe(1 << t);
            var p = 15 - t;
            for (l = 0; l < s; ++l)
                if (n[l])
                    for (var f = l << 4 | n[l], b = t - n[l], I = c[n[l] - 1]++ << b, T = I | (1 << b) - 1; I <= T; ++I) v[xr[I] >>> p] = f
        } else
            for (v = new Pe(s), l = 0; l < s; ++l) n[l] && (v[l] = xr[c[n[l] - 1]++] >>> 15 - n[l]);
        return v
    }),
    cr = new Ie(288);
for (var ae = 0; ae < 144; ++ae) cr[ae] = 8;
for (var ae = 144; ae < 256; ++ae) cr[ae] = 9;
for (var ae = 256; ae < 280; ++ae) cr[ae] = 7;
for (var ae = 280; ae < 288; ++ae) cr[ae] = 8;
var ot = new Ie(32);
for (var ae = 0; ae < 32; ++ae) ot[ae] = 5;
var ba = sr(cr, 9, 1),
    Ta = sr(ot, 5, 1),
    Er = function(n) {
        for (var t = n[0], i = 1; i < n.length; ++i) n[i] > t && (t = n[i]);
        return t
    },
    Te = function(n, t, i) {
        var s = t / 8 | 0;
        return (n[s] | n[s + 1] << 8) >> (t & 7) & i
    },
    Sr = function(n, t) {
        var i = t / 8 | 0;
        return (n[i] | n[i + 1] << 8 | n[i + 2] << 16) >> (t & 7)
    },
    Ca = function(n) {
        return (n / 8 | 0) + (n & 7 && 1)
    },
    Ra = function(n, t, i) {
        (i == null || i > n.length) && (i = n.length);
        var s = new(n instanceof Pe ? Pe : n instanceof Mr ? Mr : Ie)(i - t);
        return s.set(n.subarray(t, i)), s
    },
    Aa = function(n, t, i) {
        var s = n.length;
        if (!s || i && !i.l && s < 5) return t || new Ie(0);
        var l = !t || i,
            d = !i || i.i;
        i || (i = {}), t || (t = new Ie(s * 3));
        var c = function(q) {
                var Fe = t.length;
                if (q > Fe) {
                    var Ue = new Ie(Math.max(Fe * 2, q));
                    Ue.set(t), t = Ue
                }
            },
            v = i.f || 0,
            p = i.p || 0,
            f = i.b || 0,
            b = i.l,
            I = i.d,
            T = i.m,
            A = i.n,
            N = s * 8;
        do {
            if (!b) {
                i.f = v = Te(n, p, 1);
                var Q = Te(n, p + 1, 3);
                if (p += 3, Q)
                    if (Q == 1) b = ba, I = Ta, T = 9, A = 5;
                    else if (Q == 2) {
                    var z = Te(n, p, 31) + 257,
                        ue = Te(n, p + 10, 15) + 4,
                        H = z + Te(n, p + 5, 31) + 1;
                    p += 14;
                    for (var k = new Ie(H), ie = new Ie(19), S = 0; S < ue; ++S) ie[Sa[S]] = Te(n, p + S * 3, 7);
                    p += ue * 3;
                    for (var x = Er(ie), Z = (1 << x) - 1, $ = sr(ie, x, 1), S = 0; S < H;) {
                        var G = $[Te(n, p, Z)];
                        p += G & 15;
                        var W = G >>> 4;
                        if (W < 16) k[S++] = W;
                        else {
                            var j = 0,
                                F = 0;
                            for (W == 16 ? (F = 3 + Te(n, p, 3), p += 2, j = k[S - 1]) : W == 17 ? (F = 3 + Te(n, p, 7), p += 3) : W == 18 && (F = 11 + Te(n, p, 127), p += 7); F--;) k[S++] = j
                        }
                    }
                    var se = k.subarray(0, z),
                        B = k.subarray(z);
                    T = Er(se), A = Er(B), b = sr(se, T, 1), I = sr(B, A, 1)
                } else throw "invalid block type";
                else {
                    var W = Ca(p) + 4,
                        ne = n[W - 4] | n[W - 3] << 8,
                        X = W + ne;
                    if (X > s) {
                        if (d) throw "unexpected EOF";
                        break
                    }
                    l && c(f + ne), t.set(n.subarray(W, X), f), i.b = f += ne, i.p = p = X * 8;
                    continue
                }
                if (p > N) {
                    if (d) throw "unexpected EOF";
                    break
                }
            }
            l && c(f + 131072);
            for (var xe = (1 << T) - 1, ze = (1 << A) - 1, be = p;; be = p) {
                var j = b[Sr(n, p) & xe],
                    re = j >>> 4;
                if (p += j & 15, p > N) {
                    if (d) throw "unexpected EOF";
                    break
                }
                if (!j) throw "invalid length/literal";
                if (re < 256) t[f++] = re;
                else if (re == 256) {
                    be = p, b = null;
                    break
                } else {
                    var De = re - 254;
                    if (re > 264) {
                        var S = re - 257,
                            oe = tt[S];
                        De = Te(n, p, (1 << oe) - 1) + st[S], p += oe
                    }
                    var pe = I[Sr(n, p) & ze],
                        Ce = pe >>> 4;
                    if (!pe) throw "invalid distance";
                    p += pe & 15;
                    var B = xa[Ce];
                    if (Ce > 3) {
                        var oe = at[Ce];
                        B += Sr(n, p) & (1 << oe) - 1, p += oe
                    }
                    if (p > N) {
                        if (d) throw "unexpected EOF";
                        break
                    }
                    l && c(f + 131072);
                    for (var Ve = f + De; f < Ve; f += 4) t[f] = t[f - B], t[f + 1] = t[f + 1 - B], t[f + 2] = t[f + 2 - B], t[f + 3] = t[f + 3 - B];
                    f = Ve
                }
            }
            i.l = b, i.p = be, i.b = f, b && (v = 1, i.m = T, i.d = I, i.n = A)
        } while (!v);
        return f == t.length ? t : Ra(t, 0, f)
    },
    Fa = new Ie(0),
    Ua = function(n) {
        if ((n[0] & 15) != 8 || n[0] >>> 4 > 7 || (n[0] << 8 | n[1]) % 31) throw "invalid zlib data";
        if (n[1] & 32) throw "invalid zlib data: preset dictionaries not supported"
    };

function fr(n, t) {
    return Aa((Ua(n), n.subarray(2, -4)), t)
}
var Oa = typeof TextDecoder < "u" && new TextDecoder,
    La = 0;
try {
    Oa.decode(Fa, {
        stream: !0
    }), La = 1
} catch {}
const Da = n => n && n.isCubeTexture;
class Na extends br {
    constructor(t, i) {
        var s, l;
        const d = Da(t),
            v = ((l = d ? (s = t.image[0]) == null ? void 0 : s.width : t.image.width) != null ? l : 1024) / 4,
            p = Math.floor(Math.log2(v)),
            f = Math.pow(2, p),
            b = 3 * Math.max(f, 112),
            I = 4 * f,
            T = [d ? "#define ENVMAP_TYPE_CUBE" : "", `#define CUBEUV_TEXEL_WIDTH ${1/b}`, `#define CUBEUV_TEXEL_HEIGHT ${1/I}`, `#define CUBEUV_MAX_MIP ${p}.0`],
            A = `
        varying vec3 vWorldPosition;
        void main() 
        {
            vec4 worldPosition = ( modelMatrix * vec4( position, 1.0 ) );
            vWorldPosition = worldPosition.xyz;
            
            gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
        }
        `,
            N = T.join(`
`) + `
        #define ENVMAP_TYPE_CUBE_UV
        varying vec3 vWorldPosition;
        uniform float radius;
        uniform float height;
        uniform float angle;
        #ifdef ENVMAP_TYPE_CUBE
            uniform samplerCube map;
        #else
            uniform sampler2D map;
        #endif
        // From: https://www.shadertoy.com/view/4tsBD7
        float diskIntersectWithBackFaceCulling( vec3 ro, vec3 rd, vec3 c, vec3 n, float r ) 
        {
            float d = dot ( rd, n );
            
            if( d > 0.0 ) { return 1e6; }
            
            vec3  o = ro - c;
            float t = - dot( n, o ) / d;
            vec3  q = o + rd * t;
            
            return ( dot( q, q ) < r * r ) ? t : 1e6;
        }
        // From: https://www.iquilezles.org/www/articles/intersectors/intersectors.htm
        float sphereIntersect( vec3 ro, vec3 rd, vec3 ce, float ra ) 
        {
            vec3 oc = ro - ce;
            float b = dot( oc, rd );
            float c = dot( oc, oc ) - ra * ra;
            float h = b * b - c;
            
            if( h < 0.0 ) { return -1.0; }
            
            h = sqrt( h );
            
            return - b + h;
        }
        vec3 project() 
        {
            vec3 p = normalize( vWorldPosition );
            vec3 camPos = cameraPosition;
            camPos.y -= height;
            float intersection = sphereIntersect( camPos, p, vec3( 0.0 ), radius );
            if( intersection > 0.0 ) {
                
                vec3 h = vec3( 0.0, - height, 0.0 );
                float intersection2 = diskIntersectWithBackFaceCulling( camPos, p, h, vec3( 0.0, 1.0, 0.0 ), radius );
                p = ( camPos + min( intersection, intersection2 ) * p ) / radius;
            } else {
                p = vec3( 0.0, 1.0, 0.0 );
            }
            return p;
        }
        #include <common>
        #include <cube_uv_reflection_fragment>
        void main() 
        {
            vec3 projectedWorldPosition = project();
            
            #ifdef ENVMAP_TYPE_CUBE
                vec3 outcolor = textureCube( map, projectedWorldPosition ).rgb;
            #else
                vec3 direction = normalize( projectedWorldPosition );
                vec2 uv = equirectUv( direction );
                vec3 outcolor = texture2D( map, uv ).rgb;
            #endif
            gl_FragColor = vec4( outcolor, 1.0 );
            #include <tonemapping_fragment>
            #include <${et>=154?"colorspace_fragment":"encodings_fragment"}>
        }
        `,
            Q = {
                map: {
                    value: t
                },
                height: {
                    value: i ? .height || 15
                },
                radius: {
                    value: i ? .radius || 100
                }
            },
            W = new Wt(1, 16),
            ne = new Tr({
                uniforms: Q,
                fragmentShader: N,
                vertexShader: A,
                side: jt
            });
        super(W, ne)
    }
    set radius(t) {
        this.material.uniforms.radius.value = t
    }
    get radius() {
        return this.material.uniforms.radius.value
    }
    set height(t) {
        this.material.uniforms.height.value = t
    }
    get height() {
        return this.material.uniforms.height.value
    }
}
class Ba extends Vr {
    constructor(t) {
        super(t), this.type = Me
    }
    parse(t) {
        const c = function(S, x) {
                switch (S) {
                    case 1:
                        throw new Error("THREE.RGBELoader: Read Error: " + (x || ""));
                    case 2:
                        throw new Error("THREE.RGBELoader: Write Error: " + (x || ""));
                    case 3:
                        throw new Error("THREE.RGBELoader: Bad File Format: " + (x || ""));
                    default:
                    case 4:
                        throw new Error("THREE.RGBELoader: Memory Error: " + (x || ""))
                }
            },
            I = function(S, x, Z) {
                x = x || 1024;
                let G = S.pos,
                    j = -1,
                    F = 0,
                    se = "",
                    B = String.fromCharCode.apply(null, new Uint16Array(S.subarray(G, G + 128)));
                for (; 0 > (j = B.indexOf(`
`)) && F < x && G < S.byteLength;) se += B, F += B.length, G += 128, B += String.fromCharCode.apply(null, new Uint16Array(S.subarray(G, G + 128)));
                return -1 < j ? (S.pos += F + j + 1, se + B.slice(0, j)) : !1
            },
            T = function(S) {
                const x = /^#\?(\S+)/,
                    Z = /^\s*GAMMA\s*=\s*(\d+(\.\d+)?)\s*$/,
                    $ = /^\s*EXPOSURE\s*=\s*(\d+(\.\d+)?)\s*$/,
                    G = /^\s*FORMAT=(\S+)\s*$/,
                    j = /^\s*\-Y\s+(\d+)\s+\+X\s+(\d+)\s*$/,
                    F = {
                        valid: 0,
                        string: "",
                        comments: "",
                        programtype: "RGBE",
                        format: "",
                        gamma: 1,
                        exposure: 1,
                        width: 0,
                        height: 0
                    };
                let se, B;
                for ((S.pos >= S.byteLength || !(se = I(S))) && c(1, "no header found"), (B = se.match(x)) || c(3, "bad initial token"), F.valid |= 1, F.programtype = B[1], F.string += se + `
`; se = I(S), se !== !1;) {
                    if (F.string += se + `
`, se.charAt(0) === "#") {
                        F.comments += se + `
`;
                        continue
                    }
                    if ((B = se.match(Z)) && (F.gamma = parseFloat(B[1])), (B = se.match($)) && (F.exposure = parseFloat(B[1])), (B = se.match(G)) && (F.valid |= 2, F.format = B[1]), (B = se.match(j)) && (F.valid |= 4, F.height = parseInt(B[1], 10), F.width = parseInt(B[2], 10)), F.valid & 2 && F.valid & 4) break
                }
                return F.valid & 2 || c(3, "missing format specifier"), F.valid & 4 || c(3, "missing image size specifier"), F
            },
            A = function(S, x, Z) {
                const $ = x;
                if ($ < 8 || $ > 32767 || S[0] !== 2 || S[1] !== 2 || S[2] & 128) return new Uint8Array(S);
                $ !== (S[2] << 8 | S[3]) && c(3, "wrong scanline width");
                const G = new Uint8Array(4 * x * Z);
                G.length || c(4, "unable to allocate buffer space");
                let j = 0,
                    F = 0;
                const se = 4 * $,
                    B = new Uint8Array(4),
                    xe = new Uint8Array(se);
                let ze = Z;
                for (; ze > 0 && F < S.byteLength;) {
                    F + 4 > S.byteLength && c(1), B[0] = S[F++], B[1] = S[F++], B[2] = S[F++], B[3] = S[F++], (B[0] != 2 || B[1] != 2 || (B[2] << 8 | B[3]) != $) && c(3, "bad rgbe scanline format");
                    let be = 0,
                        re;
                    for (; be < se && F < S.byteLength;) {
                        re = S[F++];
                        const oe = re > 128;
                        if (oe && (re -= 128), (re === 0 || be + re > se) && c(3, "bad scanline data"), oe) {
                            const pe = S[F++];
                            for (let Ce = 0; Ce < re; Ce++) xe[be++] = pe
                        } else xe.set(S.subarray(F, F + re), be), be += re, F += re
                    }
                    const De = $;
                    for (let oe = 0; oe < De; oe++) {
                        let pe = 0;
                        G[j] = xe[oe + pe], pe += $, G[j + 1] = xe[oe + pe], pe += $, G[j + 2] = xe[oe + pe], pe += $, G[j + 3] = xe[oe + pe], j += 4
                    }
                    ze--
                }
                return G
            },
            N = function(S, x, Z, $) {
                const G = S[x + 3],
                    j = Math.pow(2, G - 128) / 255;
                Z[$ + 0] = S[x + 0] * j, Z[$ + 1] = S[x + 1] * j, Z[$ + 2] = S[x + 2] * j, Z[$ + 3] = 1
            },
            Q = function(S, x, Z, $) {
                const G = S[x + 3],
                    j = Math.pow(2, G - 128) / 255;
                Z[$ + 0] = je.toHalfFloat(Math.min(S[x + 0] * j, 65504)), Z[$ + 1] = je.toHalfFloat(Math.min(S[x + 1] * j, 65504)), Z[$ + 2] = je.toHalfFloat(Math.min(S[x + 2] * j, 65504)), Z[$ + 3] = je.toHalfFloat(1)
            },
            W = new Uint8Array(t);
        W.pos = 0;
        const ne = T(W),
            X = ne.width,
            z = ne.height,
            ue = A(W.subarray(W.pos), X, z);
        let H, k, ie;
        switch (this.type) {
            case Le:
                ie = ue.length / 4;
                const S = new Float32Array(ie * 4);
                for (let Z = 0; Z < ie; Z++) N(ue, Z * 4, S, Z * 4);
                H = S, k = Le;
                break;
            case Me:
                ie = ue.length / 4;
                const x = new Uint16Array(ie * 4);
                for (let Z = 0; Z < ie; Z++) Q(ue, Z * 4, x, Z * 4);
                H = x, k = Me;
                break;
            default:
                throw new Error("THREE.RGBELoader: Unsupported type: " + this.type)
        }
        return {
            width: X,
            height: z,
            data: H,
            header: ne.string,
            gamma: ne.gamma,
            exposure: ne.exposure,
            type: k
        }
    }
    setDataType(t) {
        return this.type = t, this
    }
    load(t, i, s, l) {
        function d(c, v) {
            switch (c.type) {
                case Le:
                case Me:
                    "colorSpace" in c ? c.colorSpace = "srgb-linear" : c.encoding = 3e3, c.minFilter = Ae, c.magFilter = Ae, c.generateMipmaps = !1, c.flipY = !0;
                    break
            }
            i && i(c, v)
        }
        return super.load(t, d, s, l)
    }
}
const nr = et >= 152;
class ka extends Vr {
    constructor(t) {
        super(t), this.type = Me
    }
    parse(t) {
        const x = Math.pow(2.7182818, 2.2);

        function Z(e, r) {
            for (var a = 0, o = 0; o < 65536; ++o)(o == 0 || e[o >> 3] & 1 << (o & 7)) && (r[a++] = o);
            for (var u = a - 1; a < 65536;) r[a++] = 0;
            return u
        }

        function $(e) {
            for (var r = 0; r < 16384; r++) e[r] = {}, e[r].len = 0, e[r].lit = 0, e[r].p = null
        }
        const G = {
            l: 0,
            c: 0,
            lc: 0
        };

        function j(e, r, a, o, u) {
            for (; a < e;) r = r << 8 | Zr(o, u), a += 8;
            a -= e, G.l = r >> a & (1 << e) - 1, G.c = r, G.lc = a
        }
        const F = new Array(59);

        function se(e) {
            for (var r = 0; r <= 58; ++r) F[r] = 0;
            for (var r = 0; r < 65537; ++r) F[e[r]] += 1;
            for (var a = 0, r = 58; r > 0; --r) {
                var o = a + F[r] >> 1;
                F[r] = a, a = o
            }
            for (var r = 0; r < 65537; ++r) {
                var u = e[r];
                u > 0 && (e[r] = u | F[u]++ << 6)
            }
        }

        function B(e, r, a, o, u, h, g) {
            for (var m = a, y = 0, w = 0; u <= h; u++) {
                if (m.value - a.value > o) return !1;
                j(6, y, w, e, m);
                var E = G.l;
                if (y = G.c, w = G.lc, g[u] = E, E == 63) {
                    if (m.value - a.value > o) throw "Something wrong with hufUnpackEncTable";
                    j(8, y, w, e, m);
                    var _ = G.l + 6;
                    if (y = G.c, w = G.lc, u + _ > h + 1) throw "Something wrong with hufUnpackEncTable";
                    for (; _--;) g[u++] = 0;
                    u--
                } else if (E >= 59) {
                    var _ = E - 59 + 2;
                    if (u + _ > h + 1) throw "Something wrong with hufUnpackEncTable";
                    for (; _--;) g[u++] = 0;
                    u--
                }
            }
            se(g)
        }

        function xe(e) {
            return e & 63
        }

        function ze(e) {
            return e >> 6
        }

        function be(e, r, a, o) {
            for (; r <= a; r++) {
                var u = ze(e[r]),
                    h = xe(e[r]);
                if (u >> h) throw "Invalid table entry";
                if (h > 14) {
                    var g = o[u >> h - 14];
                    if (g.len) throw "Invalid table entry";
                    if (g.lit++, g.p) {
                        var m = g.p;
                        g.p = new Array(g.lit);
                        for (var y = 0; y < g.lit - 1; ++y) g.p[y] = m[y]
                    } else g.p = new Array(1);
                    g.p[g.lit - 1] = r
                } else if (h)
                    for (var w = 0, y = 1 << 14 - h; y > 0; y--) {
                        var g = o[(u << 14 - h) + w];
                        if (g.len || g.p) throw "Invalid table entry";
                        g.len = h, g.lit = r, w++
                    }
            }
            return !0
        }
        const re = {
            c: 0,
            lc: 0
        };

        function De(e, r, a, o) {
            e = e << 8 | Zr(a, o), r += 8, re.c = e, re.lc = r
        }
        const oe = {
            c: 0,
            lc: 0
        };

        function pe(e, r, a, o, u, h, g, m, y, w) {
            if (e == r) {
                o < 8 && (De(a, o, u, g), a = re.c, o = re.lc), o -= 8;
                var E = a >> o,
                    E = new Uint8Array([E])[0];
                if (y.value + E > w) return !1;
                for (var _ = m[y.value - 1]; E-- > 0;) m[y.value++] = _
            } else if (y.value < w) m[y.value++] = e;
            else return !1;
            oe.c = a, oe.lc = o
        }

        function Ce(e) {
            return e & 65535
        }

        function Ve(e) {
            var r = Ce(e);
            return r > 32767 ? r - 65536 : r
        }
        const q = {
            a: 0,
            b: 0
        };

        function Fe(e, r) {
            var a = Ve(e),
                o = Ve(r),
                u = o,
                h = a + (u & 1) + (u >> 1),
                g = h,
                m = h - u;
            q.a = g, q.b = m
        }

        function Ue(e, r) {
            var a = Ce(e),
                o = Ce(r),
                u = a - (o >> 1) & 65535,
                h = o + u - 32768 & 65535;
            q.a = h, q.b = u
        }

        function ft(e, r, a, o, u, h, g) {
            for (var m = g < 16384, y = a > u ? u : a, w = 1, E; w <= y;) w <<= 1;
            for (w >>= 1, E = w, w >>= 1; w >= 1;) {
                for (var _ = 0, ce = _ + h * (u - E), C = h * w, R = h * E, O = o * w, D = o * E, V, J, he, ge; _ <= ce; _ += R) {
                    for (var ee = _, Re = _ + o * (a - E); ee <= Re; ee += D) {
                        var te = ee + O,
                            de = ee + C,
                            Oe = de + O;
                        m ? (Fe(e[ee + r], e[de + r]), V = q.a, he = q.b, Fe(e[te + r], e[Oe + r]), J = q.a, ge = q.b, Fe(V, J), e[ee + r] = q.a, e[te + r] = q.b, Fe(he, ge), e[de + r] = q.a, e[Oe + r] = q.b) : (Ue(e[ee + r], e[de + r]), V = q.a, he = q.b, Ue(e[te + r], e[Oe + r]), J = q.a, ge = q.b, Ue(V, J), e[ee + r] = q.a, e[te + r] = q.b, Ue(he, ge), e[de + r] = q.a, e[Oe + r] = q.b)
                    }
                    if (a & w) {
                        var de = ee + C;
                        m ? Fe(e[ee + r], e[de + r]) : Ue(e[ee + r], e[de + r]), V = q.a, e[de + r] = q.b, e[ee + r] = V
                    }
                }
                if (u & w)
                    for (var ee = _, Re = _ + o * (a - E); ee <= Re; ee += D) {
                        var te = ee + O;
                        m ? Fe(e[ee + r], e[te + r]) : Ue(e[ee + r], e[te + r]), V = q.a, e[te + r] = q.b, e[ee + r] = V
                    }
                E = w, w >>= 1
            }
            return _
        }

        function vt(e, r, a, o, u, h, g, m, y, w) {
            for (var E = 0, _ = 0, ce = m, C = Math.trunc(u.value + (h + 7) / 8); u.value < C;)
                for (De(E, _, a, u), E = re.c, _ = re.lc; _ >= 14;) {
                    var R = E >> _ - 14 & 16383,
                        O = r[R];
                    if (O.len) _ -= O.len, pe(O.lit, g, E, _, a, o, u, y, w, ce), E = oe.c, _ = oe.lc;
                    else {
                        if (!O.p) throw "hufDecode issues";
                        var D;
                        for (D = 0; D < O.lit; D++) {
                            for (var V = xe(e[O.p[D]]); _ < V && u.value < C;) De(E, _, a, u), E = re.c, _ = re.lc;
                            if (_ >= V && ze(e[O.p[D]]) == (E >> _ - V & (1 << V) - 1)) {
                                _ -= V, pe(O.p[D], g, E, _, a, o, u, y, w, ce), E = oe.c, _ = oe.lc;
                                break
                            }
                        }
                        if (D == O.lit) throw "hufDecode issues"
                    }
                }
            var J = 8 - h & 7;
            for (E >>= J, _ -= J; _ > 0;) {
                var O = r[E << 14 - _ & 16383];
                if (O.len) _ -= O.len, pe(O.lit, g, E, _, a, o, u, y, w, ce), E = oe.c, _ = oe.lc;
                else throw "hufDecode issues"
            }
            return !0
        }

        function Br(e, r, a, o, u, h) {
            var g = {
                    value: 0
                },
                m = a.value,
                y = _e(r, a),
                w = _e(r, a);
            a.value += 4;
            var E = _e(r, a);
            if (a.value += 4, y < 0 || y >= 65537 || w < 0 || w >= 65537) throw "Something wrong with HUF_ENCSIZE";
            var _ = new Array(65537),
                ce = new Array(16384);
            $(ce);
            var C = o - (a.value - m);
            if (B(e, r, a, C, y, w, _), E > 8 * (o - (a.value - m))) throw "Something wrong with hufUncompress";
            be(_, y, w, ce), vt(_, ce, e, r, a, E, w, h, u, g)
        }

        function mt(e, r, a) {
            for (var o = 0; o < a; ++o) r[o] = e[r[o]]
        }

        function kr(e) {
            for (var r = 1; r < e.length; r++) {
                var a = e[r - 1] + e[r] - 128;
                e[r] = a
            }
        }

        function Pr(e, r) {
            for (var a = 0, o = Math.floor((e.length + 1) / 2), u = 0, h = e.length - 1; !(u > h || (r[u++] = e[a++], u > h));) r[u++] = e[o++]
        }

        function Hr(e) {
            for (var r = e.byteLength, a = new Array, o = 0, u = new DataView(e); r > 0;) {
                var h = u.getInt8(o++);
                if (h < 0) {
                    var g = -h;
                    r -= g + 1;
                    for (var m = 0; m < g; m++) a.push(u.getUint8(o++))
                } else {
                    var g = h;
                    r -= 2;
                    for (var y = u.getUint8(o++), m = 0; m < g + 1; m++) a.push(y)
                }
            }
            return a
        }

        function gt(e, r, a, o, u, h) {
            var te = new DataView(h.buffer),
                g = a[e.idx[0]].width,
                m = a[e.idx[0]].height,
                y = 3,
                w = Math.floor(g / 8),
                E = Math.ceil(g / 8),
                _ = Math.ceil(m / 8),
                ce = g - (E - 1) * 8,
                C = m - (_ - 1) * 8,
                R = {
                    value: 0
                },
                O = new Array(y),
                D = new Array(y),
                V = new Array(y),
                J = new Array(y),
                he = new Array(y);
            for (let K = 0; K < y; ++K) he[K] = r[e.idx[K]], O[K] = K < 1 ? 0 : O[K - 1] + E * _, D[K] = new Float32Array(64), V[K] = new Uint16Array(64), J[K] = new Uint16Array(E * 64);
            for (let K = 0; K < _; ++K) {
                var ge = 8;
                K == _ - 1 && (ge = C);
                var ee = 8;
                for (let le = 0; le < E; ++le) {
                    le == E - 1 && (ee = ce);
                    for (let Y = 0; Y < y; ++Y) V[Y].fill(0), V[Y][0] = u[O[Y]++], _t(R, o, V[Y]), wt(V[Y], D[Y]), yt(D[Y]);
                    Et(D);
                    for (let Y = 0; Y < y; ++Y) St(D[Y], J[Y], le * 64)
                }
                let me = 0;
                for (let le = 0; le < y; ++le) {
                    const Y = a[e.idx[le]].type;
                    for (let Se = 8 * K; Se < 8 * K + ge; ++Se) {
                        me = he[le][Se];
                        for (let Ge = 0; Ge < w; ++Ge) {
                            const we = Ge * 64 + (Se & 7) * 8;
                            te.setUint16(me + 0 * Y, J[le][we + 0], !0), te.setUint16(me + 2 * Y, J[le][we + 1], !0), te.setUint16(me + 4 * Y, J[le][we + 2], !0), te.setUint16(me + 6 * Y, J[le][we + 3], !0), te.setUint16(me + 8 * Y, J[le][we + 4], !0), te.setUint16(me + 10 * Y, J[le][we + 5], !0), te.setUint16(me + 12 * Y, J[le][we + 6], !0), te.setUint16(me + 14 * Y, J[le][we + 7], !0), me += 16 * Y
                        }
                    }
                    if (w != E)
                        for (let Se = 8 * K; Se < 8 * K + ge; ++Se) {
                            const Ge = he[le][Se] + 8 * w * 2 * Y,
                                we = w * 64 + (Se & 7) * 8;
                            for (let Ne = 0; Ne < ee; ++Ne) te.setUint16(Ge + Ne * 2 * Y, J[le][we + Ne], !0)
                        }
                }
            }
            for (var Re = new Uint16Array(g), te = new DataView(h.buffer), de = 0; de < y; ++de) {
                a[e.idx[de]].decoded = !0;
                var Oe = a[e.idx[de]].type;
                if (a[de].type == 2)
                    for (var rr = 0; rr < m; ++rr) {
                        const K = he[de][rr];
                        for (var Ee = 0; Ee < g; ++Ee) Re[Ee] = te.getUint16(K + Ee * 2 * Oe, !0);
                        for (var Ee = 0; Ee < g; ++Ee) te.setFloat32(K + Ee * 2 * Oe, M(Re[Ee]), !0)
                    }
            }
        }

        function _t(e, r, a) {
            for (var o, u = 1; u < 64;) o = r[e.value], o == 65280 ? u = 64 : o >> 8 == 255 ? u += o & 255 : (a[u] = o, u++), e.value++
        }

        function wt(e, r) {
            r[0] = M(e[0]), r[1] = M(e[1]), r[2] = M(e[5]), r[3] = M(e[6]), r[4] = M(e[14]), r[5] = M(e[15]), r[6] = M(e[27]), r[7] = M(e[28]), r[8] = M(e[2]), r[9] = M(e[4]), r[10] = M(e[7]), r[11] = M(e[13]), r[12] = M(e[16]), r[13] = M(e[26]), r[14] = M(e[29]), r[15] = M(e[42]), r[16] = M(e[3]), r[17] = M(e[8]), r[18] = M(e[12]), r[19] = M(e[17]), r[20] = M(e[25]), r[21] = M(e[30]), r[22] = M(e[41]), r[23] = M(e[43]), r[24] = M(e[9]), r[25] = M(e[11]), r[26] = M(e[18]), r[27] = M(e[24]), r[28] = M(e[31]), r[29] = M(e[40]), r[30] = M(e[44]), r[31] = M(e[53]), r[32] = M(e[10]), r[33] = M(e[19]), r[34] = M(e[23]), r[35] = M(e[32]), r[36] = M(e[39]), r[37] = M(e[45]), r[38] = M(e[52]), r[39] = M(e[54]), r[40] = M(e[20]), r[41] = M(e[22]), r[42] = M(e[33]), r[43] = M(e[38]), r[44] = M(e[46]), r[45] = M(e[51]), r[46] = M(e[55]), r[47] = M(e[60]), r[48] = M(e[21]), r[49] = M(e[34]), r[50] = M(e[37]), r[51] = M(e[47]), r[52] = M(e[50]), r[53] = M(e[56]), r[54] = M(e[59]), r[55] = M(e[61]), r[56] = M(e[35]), r[57] = M(e[36]), r[58] = M(e[48]), r[59] = M(e[49]), r[60] = M(e[57]), r[61] = M(e[58]), r[62] = M(e[62]), r[63] = M(e[63])
        }

        function yt(e) {
            const r = .5 * Math.cos(.7853975),
                a = .5 * Math.cos(3.14159 / 16),
                o = .5 * Math.cos(3.14159 / 8),
                u = .5 * Math.cos(3 * 3.14159 / 16),
                h = .5 * Math.cos(5 * 3.14159 / 16),
                g = .5 * Math.cos(3 * 3.14159 / 8),
                m = .5 * Math.cos(7 * 3.14159 / 16);
            for (var y = new Array(4), w = new Array(4), E = new Array(4), _ = new Array(4), ce = 0; ce < 8; ++ce) {
                var C = ce * 8;
                y[0] = o * e[C + 2], y[1] = g * e[C + 2], y[2] = o * e[C + 6], y[3] = g * e[C + 6], w[0] = a * e[C + 1] + u * e[C + 3] + h * e[C + 5] + m * e[C + 7], w[1] = u * e[C + 1] - m * e[C + 3] - a * e[C + 5] - h * e[C + 7], w[2] = h * e[C + 1] - a * e[C + 3] + m * e[C + 5] + u * e[C + 7], w[3] = m * e[C + 1] - h * e[C + 3] + u * e[C + 5] - a * e[C + 7], E[0] = r * (e[C + 0] + e[C + 4]), E[3] = r * (e[C + 0] - e[C + 4]), E[1] = y[0] + y[3], E[2] = y[1] - y[2], _[0] = E[0] + E[1], _[1] = E[3] + E[2], _[2] = E[3] - E[2], _[3] = E[0] - E[1], e[C + 0] = _[0] + w[0], e[C + 1] = _[1] + w[1], e[C + 2] = _[2] + w[2], e[C + 3] = _[3] + w[3], e[C + 4] = _[3] - w[3], e[C + 5] = _[2] - w[2], e[C + 6] = _[1] - w[1], e[C + 7] = _[0] - w[0]
            }
            for (var R = 0; R < 8; ++R) y[0] = o * e[16 + R], y[1] = g * e[16 + R], y[2] = o * e[48 + R], y[3] = g * e[48 + R], w[0] = a * e[8 + R] + u * e[24 + R] + h * e[40 + R] + m * e[56 + R], w[1] = u * e[8 + R] - m * e[24 + R] - a * e[40 + R] - h * e[56 + R], w[2] = h * e[8 + R] - a * e[24 + R] + m * e[40 + R] + u * e[56 + R], w[3] = m * e[8 + R] - h * e[24 + R] + u * e[40 + R] - a * e[56 + R], E[0] = r * (e[R] + e[32 + R]), E[3] = r * (e[R] - e[32 + R]), E[1] = y[0] + y[3], E[2] = y[1] - y[2], _[0] = E[0] + E[1], _[1] = E[3] + E[2], _[2] = E[3] - E[2], _[3] = E[0] - E[1], e[0 + R] = _[0] + w[0], e[8 + R] = _[1] + w[1], e[16 + R] = _[2] + w[2], e[24 + R] = _[3] + w[3], e[32 + R] = _[3] - w[3], e[40 + R] = _[2] - w[2], e[48 + R] = _[1] - w[1], e[56 + R] = _[0] - w[0]
        }

        function Et(e) {
            for (var r = 0; r < 64; ++r) {
                var a = e[0][r],
                    o = e[1][r],
                    u = e[2][r];
                e[0][r] = a + 1.5747 * u, e[1][r] = a - .1873 * o - .4682 * u, e[2][r] = a + 1.8556 * o
            }
        }

        function St(e, r, a) {
            for (var o = 0; o < 64; ++o) r[a + o] = je.toHalfFloat(It(e[o]))
        }

        function It(e) {
            return e <= 1 ? Math.sign(e) * Math.pow(Math.abs(e), 2.2) : Math.sign(e) * Math.pow(x, Math.abs(e) - 1)
        }

        function zr(e) {
            return new DataView(e.array.buffer, e.offset.value, e.size)
        }

        function Mt(e) {
            var r = e.viewer.buffer.slice(e.offset.value, e.offset.value + e.size),
                a = new Uint8Array(Hr(r)),
                o = new Uint8Array(a.length);
            return kr(a), Pr(a, o), new DataView(o.buffer)
        }

        function yr(e) {
            var r = e.array.slice(e.offset.value, e.offset.value + e.size),
                a = fr(r),
                o = new Uint8Array(a.length);
            return kr(a), Pr(a, o), new DataView(o.buffer)
        }

        function xt(e) {
            for (var r = e.viewer, a = {
                    value: e.offset.value
                }, o = new Uint16Array(e.width * e.scanlineBlockSize * (e.channels * e.type)), u = new Uint8Array(8192), h = 0, g = new Array(e.channels), m = 0; m < e.channels; m++) g[m] = {}, g[m].start = h, g[m].end = g[m].start, g[m].nx = e.width, g[m].ny = e.lines, g[m].size = e.type, h += g[m].nx * g[m].ny * g[m].size;
            var y = Qe(r, a),
                w = Qe(r, a);
            if (w >= 8192) throw "Something is wrong with PIZ_COMPRESSION BITMAP_SIZE";
            if (y <= w)
                for (var m = 0; m < w - y + 1; m++) u[m + y] = We(r, a);
            var E = new Uint16Array(65536),
                _ = Z(u, E),
                ce = _e(r, a);
            Br(e.array, r, a, ce, o, h);
            for (var m = 0; m < e.channels; ++m)
                for (var C = g[m], R = 0; R < g[m].size; ++R) ft(o, C.start + R, C.nx, C.size, C.ny, C.nx * C.size, _);
            mt(E, o, h);
            for (var O = 0, D = new Uint8Array(o.buffer.byteLength), V = 0; V < e.lines; V++)
                for (var J = 0; J < e.channels; J++) {
                    var C = g[J],
                        he = C.nx * C.size,
                        ge = new Uint8Array(o.buffer, C.end * 2, he * 2);
                    D.set(ge, O), O += he * 2, C.end += he
                }
            return new DataView(D.buffer)
        }

        function bt(e) {
            var r = e.array.slice(e.offset.value, e.offset.value + e.size),
                a = fr(r);
            const o = e.lines * e.channels * e.width,
                u = e.type == 1 ? new Uint16Array(o) : new Uint32Array(o);
            let h = 0,
                g = 0;
            const m = new Array(4);
            for (let y = 0; y < e.lines; y++)
                for (let w = 0; w < e.channels; w++) {
                    let E = 0;
                    switch (e.type) {
                        case 1:
                            m[0] = h, m[1] = m[0] + e.width, h = m[1] + e.width;
                            for (let _ = 0; _ < e.width; ++_) {
                                const ce = a[m[0]++] << 8 | a[m[1]++];
                                E += ce, u[g] = E, g++
                            }
                            break;
                        case 2:
                            m[0] = h, m[1] = m[0] + e.width, m[2] = m[1] + e.width, h = m[2] + e.width;
                            for (let _ = 0; _ < e.width; ++_) {
                                const ce = a[m[0]++] << 24 | a[m[1]++] << 16 | a[m[2]++] << 8;
                                E += ce, u[g] = E, g++
                            }
                            break
                    }
                }
            return new DataView(u.buffer)
        }

        function Gr(e) {
            var r = e.viewer,
                a = {
                    value: e.offset.value
                },
                o = new Uint8Array(e.width * e.lines * (e.channels * e.type * 2)),
                u = {
                    version: ye(r, a),
                    unknownUncompressedSize: ye(r, a),
                    unknownCompressedSize: ye(r, a),
                    acCompressedSize: ye(r, a),
                    dcCompressedSize: ye(r, a),
                    rleCompressedSize: ye(r, a),
                    rleUncompressedSize: ye(r, a),
                    rleRawSize: ye(r, a),
                    totalAcUncompressedCount: ye(r, a),
                    totalDcUncompressedCount: ye(r, a),
                    acCompression: ye(r, a)
                };
            if (u.version < 2) throw "EXRLoader.parse: " + er.compression + " version " + u.version + " is unsupported";
            for (var h = new Array, g = Qe(r, a) - 2; g > 0;) {
                var m = ur(r.buffer, a),
                    y = We(r, a),
                    w = y >> 2 & 3,
                    E = (y >> 4) - 1,
                    _ = new Int8Array([E])[0],
                    ce = We(r, a);
                h.push({
                    name: m,
                    index: _,
                    type: ce,
                    compression: w
                }), g -= m.length + 3
            }
            for (var C = er.channels, R = new Array(e.channels), O = 0; O < e.channels; ++O) {
                var D = R[O] = {},
                    V = C[O];
                D.name = V.name, D.compression = 0, D.decoded = !1, D.type = V.pixelType, D.pLinear = V.pLinear, D.width = e.width, D.height = e.lines
            }
            for (var J = {
                    idx: new Array(3)
                }, he = 0; he < e.channels; ++he)
                for (var D = R[he], O = 0; O < h.length; ++O) {
                    var ge = h[O];
                    D.name == ge.name && (D.compression = ge.compression, ge.index >= 0 && (J.idx[ge.index] = he), D.offset = he)
                }
            if (u.acCompressedSize > 0) switch (u.acCompression) {
                case 0:
                    var te = new Uint16Array(u.totalAcUncompressedCount);
                    Br(e.array, r, a, u.acCompressedSize, te, u.totalAcUncompressedCount);
                    break;
                case 1:
                    var ee = e.array.slice(a.value, a.value + u.totalAcUncompressedCount),
                        Re = fr(ee),
                        te = new Uint16Array(Re.buffer);
                    a.value += u.totalAcUncompressedCount;
                    break
            }
            if (u.dcCompressedSize > 0) {
                var de = {
                        array: e.array,
                        offset: a,
                        size: u.dcCompressedSize
                    },
                    Oe = new Uint16Array(yr(de).buffer);
                a.value += u.dcCompressedSize
            }
            if (u.rleRawSize > 0) {
                var ee = e.array.slice(a.value, a.value + u.rleCompressedSize),
                    Re = fr(ee),
                    rr = Hr(Re.buffer);
                a.value += u.rleCompressedSize
            }
            for (var Ee = 0, K = new Array(R.length), O = 0; O < K.length; ++O) K[O] = new Array;
            for (var me = 0; me < e.lines; ++me)
                for (var le = 0; le < R.length; ++le) K[le].push(Ee), Ee += R[le].width * e.type * 2;
            gt(J, K, R, te, Oe, o);
            for (var O = 0; O < R.length; ++O) {
                var D = R[O];
                if (!D.decoded) switch (D.compression) {
                    case 2:
                        for (var Y = 0, Se = 0, me = 0; me < e.lines; ++me) {
                            for (var Ge = K[O][Y], we = 0; we < D.width; ++we) {
                                for (var Ne = 0; Ne < 2 * D.type; ++Ne) o[Ge++] = rr[Se + Ne * D.width * D.height];
                                Se++
                            }
                            Y++
                        }
                        break;
                    default:
                        throw "EXRLoader.parse: unsupported channel compression"
                }
            }
            return new DataView(o.buffer)
        }

        function ur(e, r) {
            for (var a = new Uint8Array(e), o = 0; a[r.value + o] != 0;) o += 1;
            var u = new TextDecoder().decode(a.slice(r.value, r.value + o));
            return r.value = r.value + o + 1, u
        }

        function Tt(e, r, a) {
            var o = new TextDecoder().decode(new Uint8Array(e).slice(r.value, r.value + a));
            return r.value = r.value + a, o
        }

        function Ct(e, r) {
            var a = Ke(e, r),
                o = _e(e, r);
            return [a, o]
        }

        function Rt(e, r) {
            var a = _e(e, r),
                o = _e(e, r);
            return [a, o]
        }

        function Ke(e, r) {
            var a = e.getInt32(r.value, !0);
            return r.value = r.value + 4, a
        }

        function _e(e, r) {
            var a = e.getUint32(r.value, !0);
            return r.value = r.value + 4, a
        }

        function Zr(e, r) {
            var a = e[r.value];
            return r.value = r.value + 1, a
        }

        function We(e, r) {
            var a = e.getUint8(r.value);
            return r.value = r.value + 1, a
        }
        const ye = function(e, r) {
            let a;
            return "getBigInt64" in DataView.prototype ? a = Number(e.getBigInt64(r.value, !0)) : a = e.getUint32(r.value + 4, !0) + Number(e.getUint32(r.value, !0) << 32), r.value += 8, a
        };

        function ve(e, r) {
            var a = e.getFloat32(r.value, !0);
            return r.value += 4, a
        }

        function At(e, r) {
            return je.toHalfFloat(ve(e, r))
        }

        function M(e) {
            var r = (e & 31744) >> 10,
                a = e & 1023;
            return (e >> 15 ? -1 : 1) * (r ? r === 31 ? a ? NaN : 1 / 0 : Math.pow(2, r - 15) * (1 + a / 1024) : 6103515625e-14 * (a / 1024))
        }

        function Qe(e, r) {
            var a = e.getUint16(r.value, !0);
            return r.value += 2, a
        }

        function Ft(e, r) {
            return M(Qe(e, r))
        }

        function Ut(e, r, a, o) {
            for (var u = a.value, h = []; a.value < u + o - 1;) {
                var g = ur(r, a),
                    m = Ke(e, a),
                    y = We(e, a);
                a.value += 3;
                var w = Ke(e, a),
                    E = Ke(e, a);
                h.push({
                    name: g,
                    pixelType: m,
                    pLinear: y,
                    xSampling: w,
                    ySampling: E
                })
            }
            return a.value += 1, h
        }

        function Ot(e, r) {
            var a = ve(e, r),
                o = ve(e, r),
                u = ve(e, r),
                h = ve(e, r),
                g = ve(e, r),
                m = ve(e, r),
                y = ve(e, r),
                w = ve(e, r);
            return {
                redX: a,
                redY: o,
                greenX: u,
                greenY: h,
                blueX: g,
                blueY: m,
                whiteX: y,
                whiteY: w
            }
        }

        function Lt(e, r) {
            var a = ["NO_COMPRESSION", "RLE_COMPRESSION", "ZIPS_COMPRESSION", "ZIP_COMPRESSION", "PIZ_COMPRESSION", "PXR24_COMPRESSION", "B44_COMPRESSION", "B44A_COMPRESSION", "DWAA_COMPRESSION", "DWAB_COMPRESSION"],
                o = We(e, r);
            return a[o]
        }

        function Dt(e, r) {
            var a = _e(e, r),
                o = _e(e, r),
                u = _e(e, r),
                h = _e(e, r);
            return {
                xMin: a,
                yMin: o,
                xMax: u,
                yMax: h
            }
        }

        function Nt(e, r) {
            var a = ["INCREASING_Y"],
                o = We(e, r);
            return a[o]
        }

        function Bt(e, r) {
            var a = ve(e, r),
                o = ve(e, r);
            return [a, o]
        }

        function kt(e, r) {
            var a = ve(e, r),
                o = ve(e, r),
                u = ve(e, r);
            return [a, o, u]
        }

        function Pt(e, r, a, o, u) {
            if (o === "string" || o === "stringvector" || o === "iccProfile") return Tt(r, a, u);
            if (o === "chlist") return Ut(e, r, a, u);
            if (o === "chromaticities") return Ot(e, a);
            if (o === "compression") return Lt(e, a);
            if (o === "box2i") return Dt(e, a);
            if (o === "lineOrder") return Nt(e, a);
            if (o === "float") return ve(e, a);
            if (o === "v2f") return Bt(e, a);
            if (o === "v3f") return kt(e, a);
            if (o === "int") return Ke(e, a);
            if (o === "rational") return Ct(e, a);
            if (o === "timecode") return Rt(e, a);
            if (o === "preview") return a.value += u, "skipped";
            a.value += u
        }

        function Ht(e, r, a) {
            const o = {};
            if (e.getUint32(0, !0) != 20000630) throw "THREE.EXRLoader: provided file doesn't appear to be in OpenEXR format.";
            o.version = e.getUint8(4);
            const u = e.getUint8(5);
            o.spec = {
                singleTile: !!(u & 2),
                longName: !!(u & 4),
                deepFormat: !!(u & 8),
                multiPart: !!(u & 16)
            }, a.value = 8;
            for (var h = !0; h;) {
                var g = ur(r, a);
                if (g == 0) h = !1;
                else {
                    var m = ur(r, a),
                        y = _e(e, a),
                        w = Pt(e, r, a, m, y);
                    w === void 0 ? console.warn(`EXRLoader.parse: skipped unknown header attribute type '${m}'.`) : o[g] = w
                }
            }
            if ((u & -5) != 0) throw console.error("EXRHeader:", o), "THREE.EXRLoader: provided file is currently unsupported.";
            return o
        }

        function zt(e, r, a, o, u) {
            const h = {
                size: 0,
                viewer: r,
                array: a,
                offset: o,
                width: e.dataWindow.xMax - e.dataWindow.xMin + 1,
                height: e.dataWindow.yMax - e.dataWindow.yMin + 1,
                channels: e.channels.length,
                bytesPerLine: null,
                lines: null,
                inputSize: null,
                type: e.channels[0].pixelType,
                uncompress: null,
                getter: null,
                format: null,
                [nr ? "colorSpace" : "encoding"]: null
            };
            switch (e.compression) {
                case "NO_COMPRESSION":
                    h.lines = 1, h.uncompress = zr;
                    break;
                case "RLE_COMPRESSION":
                    h.lines = 1, h.uncompress = Mt;
                    break;
                case "ZIPS_COMPRESSION":
                    h.lines = 1, h.uncompress = yr;
                    break;
                case "ZIP_COMPRESSION":
                    h.lines = 16, h.uncompress = yr;
                    break;
                case "PIZ_COMPRESSION":
                    h.lines = 32, h.uncompress = xt;
                    break;
                case "PXR24_COMPRESSION":
                    h.lines = 16, h.uncompress = bt;
                    break;
                case "DWAA_COMPRESSION":
                    h.lines = 32, h.uncompress = Gr;
                    break;
                case "DWAB_COMPRESSION":
                    h.lines = 256, h.uncompress = Gr;
                    break;
                default:
                    throw "EXRLoader.parse: " + e.compression + " is unsupported"
            }
            if (h.scanlineBlockSize = h.lines, h.type == 1) switch (u) {
                case Le:
                    h.getter = Ft, h.inputSize = 2;
                    break;
                case Me:
                    h.getter = Qe, h.inputSize = 2;
                    break
            } else if (h.type == 2) switch (u) {
                case Le:
                    h.getter = ve, h.inputSize = 4;
                    break;
                case Me:
                    h.getter = At, h.inputSize = 4
            } else throw "EXRLoader.parse: unsupported pixelType " + h.type + " for " + e.compression + ".";
            h.blockCount = (e.dataWindow.yMax + 1) / h.scanlineBlockSize;
            for (var g = 0; g < h.blockCount; g++) ye(r, o);
            h.outputChannels = h.channels == 3 ? 4 : h.channels;
            const m = h.width * h.height * h.outputChannels;
            switch (u) {
                case Le:
                    h.byteArray = new Float32Array(m), h.channels < h.outputChannels && h.byteArray.fill(1, 0, m);
                    break;
                case Me:
                    h.byteArray = new Uint16Array(m), h.channels < h.outputChannels && h.byteArray.fill(15360, 0, m);
                    break;
                default:
                    console.error("THREE.EXRLoader: unsupported type: ", u);
                    break
            }
            return h.bytesPerLine = h.width * h.inputSize * h.channels, h.outputChannels == 4 ? h.format = or : h.format = Yt, nr ? h.colorSpace = "srgb-linear" : h.encoding = 3e3, h
        }
        const hr = new DataView(t),
            Gt = new Uint8Array(t),
            Je = {
                value: 0
            },
            er = Ht(hr, t, Je),
            P = zt(er, hr, Gt, Je, this.type),
            Wr = {
                value: 0
            },
            Zt = {
                R: 0,
                G: 1,
                B: 2,
                A: 3,
                Y: 0
            };
        for (let e = 0; e < P.height / P.scanlineBlockSize; e++) {
            const r = _e(hr, Je);
            P.size = _e(hr, Je), P.lines = r + P.scanlineBlockSize > P.height ? P.height - r : P.scanlineBlockSize;
            const o = P.size < P.lines * P.bytesPerLine ? P.uncompress(P) : zr(P);
            Je.value += P.size;
            for (let u = 0; u < P.scanlineBlockSize; u++) {
                const h = u + e * P.scanlineBlockSize;
                if (h >= P.height) break;
                for (let g = 0; g < P.channels; g++) {
                    const m = Zt[er.channels[g].name];
                    for (let y = 0; y < P.width; y++) {
                        Wr.value = (u * (P.channels * P.width) + g * P.width + y) * P.inputSize;
                        const w = (P.height - 1 - h) * (P.width * P.outputChannels) + y * P.outputChannels + m;
                        P.byteArray[w] = P.getter(o, Wr)
                    }
                }
            }
        }
        return {
            header: er,
            width: P.width,
            height: P.height,
            data: P.byteArray,
            format: P.format,
            [nr ? "colorSpace" : "encoding"]: P[nr ? "colorSpace" : "encoding"],
            type: this.type
        }
    }
    setDataType(t) {
        return this.type = t, this
    }
    load(t, i, s, l) {
        function d(c, v) {
            nr ? c.colorSpace = v.colorSpace : c.encoding = v.encoding, c.minFilter = Ae, c.magFilter = Ae, c.generateMipmaps = !1, c.flipY = !1, i && i(c, v)
        }
        return super.load(t, d, s, l)
    }
}
const lt = (n, t, i) => {
    let s;
    switch (n) {
        case Ir:
            s = new Uint8ClampedArray(t * i * 4);
            break;
        case Me:
            s = new Uint16Array(t * i * 4);
            break;
        case ea:
            s = new Uint32Array(t * i * 4);
            break;
        case Jt:
            s = new Int8Array(t * i * 4);
            break;
        case Qt:
            s = new Int16Array(t * i * 4);
            break;
        case Kt:
            s = new Int32Array(t * i * 4);
            break;
        case Le:
            s = new Float32Array(t * i * 4);
            break;
        default:
            throw new Error("Unsupported data type")
    }
    return s
};
let vr;
const Pa = (n, t, i, s) => {
    if (vr !== void 0) return vr;
    const l = new Jr(1, 1, s);
    t.setRenderTarget(l);
    const d = new br(new Qr, new Vt({
        color: 16777215
    }));
    t.render(d, i), t.setRenderTarget(null);
    const c = lt(n, l.width, l.height);
    return t.readRenderTargetPixels(l, 0, 0, l.width, l.height, c), l.dispose(), d.geometry.dispose(), d.material.dispose(), vr = c[0] !== 0, vr
};
class Ar {
    _renderer;
    _rendererIsDisposable = !1;
    _material;
    _scene;
    _camera;
    _quad;
    _renderTarget;
    _width;
    _height;
    _type;
    _colorSpace;
    _supportsReadPixels = !0;
    constructor(t) {
        this._width = t.width, this._height = t.height, this._type = t.type, this._colorSpace = t.colorSpace;
        const i = {
            format: or,
            depthBuffer: !1,
            stencilBuffer: !1,
            type: this._type,
            colorSpace: this._colorSpace,
            anisotropy: t.renderTargetOptions ? .anisotropy !== void 0 ? t.renderTargetOptions ? .anisotropy : 1,
            generateMipmaps: t.renderTargetOptions ? .generateMipmaps !== void 0 ? t.renderTargetOptions ? .generateMipmaps : !1,
            magFilter: t.renderTargetOptions ? .magFilter !== void 0 ? t.renderTargetOptions ? .magFilter : Ae,
            minFilter: t.renderTargetOptions ? .minFilter !== void 0 ? t.renderTargetOptions ? .minFilter : Ae,
            samples: t.renderTargetOptions ? .samples !== void 0 ? t.renderTargetOptions ? .samples : void 0,
            wrapS: t.renderTargetOptions ? .wrapS !== void 0 ? t.renderTargetOptions ? .wrapS : ke,
            wrapT: t.renderTargetOptions ? .wrapT !== void 0 ? t.renderTargetOptions ? .wrapT : ke
        };
        if (this._material = t.material, t.renderer ? this._renderer = t.renderer : (this._renderer = Ar.instantiateRenderer(), this._rendererIsDisposable = !0), this._scene = new Kr, this._camera = new $t, this._camera.position.set(0, 0, 10), this._camera.left = -.5, this._camera.right = .5, this._camera.top = .5, this._camera.bottom = -.5, this._camera.updateProjectionMatrix(), !Pa(this._type, this._renderer, this._camera, i)) {
            let s;
            this._type === Me && (s = this._renderer.extensions.has("EXT_color_buffer_float") ? Le : void 0), s !== void 0 ? (console.warn(`This browser does not support reading pixels from ${this._type} RenderTargets, switching to ${Le}`), this._type = s) : (this._supportsReadPixels = !1, console.warn("This browser dos not support toArray or toDataTexture, calls to those methods will result in an error thrown"))
        }
        this._quad = new br(new Qr, this._material), this._quad.geometry.computeBoundingBox(), this._scene.add(this._quad), this._renderTarget = new Jr(this.width, this.height, i), this._renderTarget.texture.mapping = t.renderTargetOptions ? .mapping !== void 0 ? t.renderTargetOptions ? .mapping : gr
    }
    static instantiateRenderer() {
        const t = new Xt;
        return t.setSize(128, 128), t
    }
    render = () => {
        this._renderer.setRenderTarget(this._renderTarget);
        try {
            this._renderer.render(this._scene, this._camera)
        } catch (t) {
            throw this._renderer.setRenderTarget(null), t
        }
        this._renderer.setRenderTarget(null)
    };
    toArray() {
        if (!this._supportsReadPixels) throw new Error("Can't read pixels in this browser");
        const t = lt(this._type, this._width, this._height);
        return this._renderer.readRenderTargetPixels(this._renderTarget, 0, 0, this._width, this._height, t), t
    }
    toDataTexture(t) {
        const i = new qt(this.toArray(), this.width, this.height, or, this._type, t ? .mapping || gr, t ? .wrapS || ke, t ? .wrapT || ke, t ? .magFilter || Ae, t ? .minFilter || Ae, t ? .anisotropy || 1, Cr);
        return i.generateMipmaps = t ? .generateMipmaps !== void 0 ? t ? .generateMipmaps : !1, i
    }
    disposeOnDemandRenderer() {
        this._renderer.setRenderTarget(null), this._rendererIsDisposable && (this._renderer.dispose(), this._renderer.forceContextLoss())
    }
    dispose(t) {
        this.disposeOnDemandRenderer(), t && this.renderTarget.dispose(), this.material instanceof Tr && Object.values(this.material.uniforms).forEach(i => {
            i.value instanceof Xe && i.value.dispose()
        }), Object.values(this.material).forEach(i => {
            i instanceof Xe && i.dispose()
        }), this.material.dispose(), this._quad.geometry.dispose()
    }
    get width() {
        return this._width
    }
    set width(t) {
        this._width = t, this._renderTarget.setSize(this._width, this._height)
    }
    get height() {
        return this._height
    }
    set height(t) {
        this._height = t, this._renderTarget.setSize(this._width, this._height)
    }
    get renderer() {
        return this._renderer
    }
    get renderTarget() {
        return this._renderTarget
    }
    set renderTarget(t) {
        this._renderTarget = t, this._width = t.width, this._height = t.height
    }
    get material() {
        return this._material
    }
    get type() {
        return this._type
    }
    get colorSpace() {
        return this._colorSpace
    }
}
const Ha = "urn:iso:std:iso:ts:21496:-1\0",
    za = 128,
    Ga = 8,
    Za = 4,
    Wa = n => {
        const t = new DataView(n.buffer, n.byteOffset, n.byteLength);
        let i = 0;
        const s = () => {
                const z = t.getUint16(i);
                return i += 2, z
            },
            l = () => {
                const z = t.getUint32(i);
                return i += 4, z
            },
            d = () => {
                const z = t.getInt32(i);
                return i += 4, z
            },
            c = s();
        if (c !== 0) throw new Error(`Unsupported ISO 21496-1 minimum_version ${c}`);
        s();
        const v = t.getUint8(i++);
        if (v & Za) throw new Error("ISO 21496-1 metadata with HDR base image is not supported");
        const p = v & za ? 3 : 1,
            f = v & Ga ? l() : void 0,
            b = z => {
                const ue = z ? d() : l(),
                    H = f ? ? l();
                if (H === 0) throw new Error("Invalid ISO 21496-1 fraction with zero denominator");
                return ue / H
            },
            I = b(!1),
            T = b(!1);
        if (I > T) throw new Error("ISO 21496-1 metadata with HDR base image is not supported");
        const A = [],
            N = [],
            Q = [],
            W = [],
            ne = [];
        for (let z = 0; z < p; z++) A.push(b(!0)), N.push(b(!0)), Q.push(b(!1)), W.push(b(!0)), ne.push(b(!0));
        const X = z => p === 3 ? z : [z[0], z[0], z[0]];
        return {
            gainMapMin: X(A),
            gainMapMax: X(N),
            gamma: X(Q),
            offsetSdr: X(W),
            offsetHdr: X(ne),
            hdrCapacityMin: I,
            hdrCapacityMax: T
        }
    };
class ct extends Error {}
class ut extends Error {}
const Xr = Array.from(Ha, n => n.charCodeAt(0)),
    ja = n => {
        const t = new DataView(n.buffer, n.byteOffset, n.byteLength),
            i = 4 + Xr.length;
        for (let s = 0; s + i < n.length; s++) {
            if (n[s] !== 255 || n[s + 1] !== 226 || !Xr.every((d, c) => n[s + 4 + c] === d)) continue;
            const l = Math.min(n.length, s + 2 + t.getUint16(s + 2));
            if (!(l - (s + i) <= 4)) try {
                return Wa(n.subarray(s + i, l))
            } catch {
                return
            }
        }
    },
    ir = (n, t, i) => {
        const s = new RegExp(`${t}="([^"]*)"`, "i").exec(n);
        if (s) return s[1];
        const l = new RegExp(`<${t}[^>]*>([\\s\\S]*?)</${t}>`, "i").exec(n);
        if (l) {
            const d = l[1].match(/<rdf:li>([^<]*)<\/rdf:li>/g);
            return d && d.length === 3 ? d.map(c => c.replace(/<\/?rdf:li>/g, "")) : l[1].trim()
        }
        if (i !== void 0) return i;
        throw new Error(`Can't find ${t} in gainmap metadata`)
    },
    Ya = n => {
        let t;
        typeof TextDecoder < "u" ? t = new TextDecoder().decode(n) : t = n.toString();
        let i = t.indexOf("<x:xmpmeta");
        for (; i !== -1;) {
            const s = t.indexOf("x:xmpmeta>", i),
                l = t.slice(i, s + 10);
            try {
                const d = ir(l, "hdrgm:GainMapMin", "0"),
                    c = ir(l, "hdrgm:GainMapMax"),
                    v = ir(l, "hdrgm:Gamma", "1"),
                    p = ir(l, "hdrgm:OffsetSDR", "0.015625"),
                    f = ir(l, "hdrgm:OffsetHDR", "0.015625"),
                    b = /hdrgm:HDRCapacityMin="([^"]*)"/.exec(l),
                    I = b ? b[1] : "0",
                    T = /hdrgm:HDRCapacityMax="([^"]*)"/.exec(l);
                if (!T) throw new Error("Incomplete gainmap metadata");
                const A = T[1];
                return {
                    gainMapMin: Array.isArray(d) ? d.map(N => parseFloat(N)) : [parseFloat(d), parseFloat(d), parseFloat(d)],
                    gainMapMax: Array.isArray(c) ? c.map(N => parseFloat(N)) : [parseFloat(c), parseFloat(c), parseFloat(c)],
                    gamma: Array.isArray(v) ? v.map(N => parseFloat(N)) : [parseFloat(v), parseFloat(v), parseFloat(v)],
                    offsetSdr: Array.isArray(p) ? p.map(N => parseFloat(N)) : [parseFloat(p), parseFloat(p), parseFloat(p)],
                    offsetHdr: Array.isArray(f) ? f.map(N => parseFloat(N)) : [parseFloat(f), parseFloat(f), parseFloat(f)],
                    hdrCapacityMin: parseFloat(I),
                    hdrCapacityMax: parseFloat(A)
                }
            } catch {}
            i = t.indexOf("<x:xmpmeta", s)
        }
    };
class $a {
    options;
    constructor(t) {
        this.options = {
            debug: t && t.debug !== void 0 ? t.debug : !1,
            extractFII: t && t.extractFII !== void 0 ? t.extractFII : !0,
            extractNonFII: t && t.extractNonFII !== void 0 ? t.extractNonFII : !0
        }
    }
    extract(t) {
        return new Promise((i, s) => {
            const l = this.options.debug,
                d = new DataView(t.buffer);
            if (d.getUint16(0) !== 65496) {
                s(new Error("Not a valid jpeg"));
                return
            }
            const c = d.byteLength;
            let v = 2,
                p = 0,
                f;
            for (; v < c;) {
                if (++p > 250) {
                    s(new Error(`Found no marker after ${p} loops 😵`));
                    return
                }
                if (d.getUint8(v) !== 255) {
                    s(new Error(`Not a valid marker at offset 0x${v.toString(16)}, found: 0x${d.getUint8(v).toString(16)}`));
                    return
                }
                if (f = d.getUint8(v + 1), l && console.log(`Marker: ${f.toString(16)}`), f === 226) {
                    l && console.log("Found APP2 marker (0xffe2)");
                    const b = v + 4;
                    if (d.getUint32(b) === 1297106432) {
                        const I = b + 4;
                        let T;
                        if (d.getUint16(I) === 18761) T = !1;
                        else if (d.getUint16(I) === 19789) T = !0;
                        else {
                            s(new Error("No valid endianness marker found in TIFF header"));
                            return
                        }
                        if (d.getUint16(I + 2, !T) !== 42) {
                            s(new Error("Not valid TIFF data! (no 0x002A marker)"));
                            return
                        }
                        const A = d.getUint32(I + 4, !T);
                        if (A < 8) {
                            s(new Error("Not valid TIFF data! (First offset less than 8)"));
                            return
                        }
                        const N = I + A,
                            Q = d.getUint16(N, !T),
                            W = N + 2;
                        let ne = 0;
                        for (let H = W; H < W + 12 * Q; H += 12) d.getUint16(H, !T) === 45057 && (ne = d.getUint32(H + 8, !T));
                        const z = N + 2 + Q * 12 + 4,
                            ue = [];
                        for (let H = z; H < z + ne * 16; H += 16) {
                            const k = {
                                MPType: d.getUint32(H, !T),
                                size: d.getUint32(H + 4, !T),
                                dataOffset: d.getUint32(H + 8, !T),
                                dependantImages: d.getUint32(H + 12, !T),
                                start: -1,
                                end: -1,
                                isFII: !1
                            };
                            k.dataOffset ? (k.start = I + k.dataOffset, k.isFII = !1) : (k.start = 0, k.isFII = !0), k.end = k.start + k.size, ue.push(k)
                        }
                        if (this.options.extractNonFII && ue.length) {
                            const H = new Blob([d]),
                                k = [];
                            for (const ie of ue) {
                                if (ie.isFII && !this.options.extractFII) continue;
                                const S = H.slice(ie.start, ie.end + 1, "image/jpeg");
                                k.push(S)
                            }
                            i(k)
                        }
                    }
                }
                v += 2 + d.getUint16(v + 2)
            }
        })
    }
}
const Xa = async n => {
        const t = ja(n) ? ? Ya(n);
        if (!t) throw new ut("Gain map XMP metadata not found");
        const s = await new $a({
            extractFII: !0,
            extractNonFII: !0
        }).extract(n);
        if (s.length !== 2) throw new ct("Gain map recovery image not found");
        return {
            sdr: new Uint8Array(await s[0].arrayBuffer()),
            gainMap: new Uint8Array(await s[1].arrayBuffer()),
            metadata: t
        }
    },
    qr = n => new Promise((t, i) => {
        const s = document.createElement("img");
        s.onload = () => {
            t(s)
        }, s.onerror = l => {
            i(l)
        }, s.src = URL.createObjectURL(n)
    }),
    qa = async (n, t, i) => {
        const s = t ? new Blob([t], {
                type: "image/jpeg"
            }) : void 0,
            l = new Blob([n], {
                type: "image/jpeg"
            });
        let d, c, v = !1;
        if (typeof createImageBitmap > "u") {
            const p = await Promise.all([s ? qr(s) : Promise.resolve(void 0), qr(l)]);
            c = p[0], d = p[1], v = i === "flipY"
        } else {
            const p = await Promise.all([s ? createImageBitmap(s, {
                imageOrientation: i || "flipY"
            }) : Promise.resolve(void 0), createImageBitmap(l, {
                imageOrientation: i || "flipY"
            })]);
            c = p[0], d = p[1]
        }
        return {
            sdrImage: d,
            gainMapImage: c,
            needsFlip: v
        }
    },
    Va = (n, t, i) => {
        const s = new Xe(t || new ImageData(2, 2), gr, ke, ke, Ae, jr, or, Ir, 1, Cr);
        s.flipY = i, s.needsUpdate = !0;
        const l = new Xe(n, gr, ke, ke, Ae, jr, or, Ir, 1, aa);
        return l.flipY = i, l.needsUpdate = !0, {
            gainMap: s,
            sdr: l
        }
    };
class Ka extends ra {
    _renderer;
    _renderTargetOptions;
    _internalLoadingManager;
    _config;
    constructor(t, i) {
        super(i), this._config = t, t.renderer && (this._renderer = t.renderer), this._internalLoadingManager = new ta
    }
    setRenderer(t) {
        return this._renderer = t, this
    }
    setRenderTargetOptions(t) {
        return this._renderTargetOptions = t, this
    }
    prepareQuadRenderer() {
        this._renderer || console.warn("WARNING: A Renderer was not passed to this Loader constructor or in setRenderer, the result of this Loader will need to be converted to a Data Texture with toDataTexture() before you can use it in your renderer.");
        const t = this._config.createMaterial({
            gainMapMax: [1, 1, 1],
            gainMapMin: [0, 0, 0],
            gamma: [1, 1, 1],
            offsetHdr: [1, 1, 1],
            offsetSdr: [1, 1, 1],
            hdrCapacityMax: 1,
            hdrCapacityMin: 0,
            maxDisplayBoost: 1,
            gainMap: new Xe,
            sdr: new Xe
        });
        return this._config.createQuadRenderer({
            width: 16,
            height: 16,
            type: Me,
            colorSpace: Cr,
            material: t,
            renderer: this._renderer,
            renderTargetOptions: this._renderTargetOptions
        })
    }
    processImages(t, i, s) {
        return qa(t, i, s)
    }
    createTextures(t, i, s) {
        return Va(t, i, s)
    }
    updateQuadRenderer(t, i, s, l, d) {
        t.width = i.width, t.height = i.height, t.material.gainMap = s, t.material.sdr = l, t.material.gainMapMin = d.gainMapMin, t.material.gainMapMax = d.gainMapMax, t.material.offsetHdr = d.offsetHdr, t.material.offsetSdr = d.offsetSdr, t.material.gamma = d.gamma, t.material.hdrCapacityMin = d.hdrCapacityMin, t.material.hdrCapacityMax = d.hdrCapacityMax, t.material.maxDisplayBoost = Math.pow(2, d.hdrCapacityMax), t.material.needsUpdate = !0
    }
}
const Qa = `
varying vec2 vUv;

void main() {
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`,
    Ja = `
// min half float value
#define HALF_FLOAT_MIN vec3( -65504, -65504, -65504 )
// max half float value
#define HALF_FLOAT_MAX vec3( 65504, 65504, 65504 )

uniform sampler2D sdr;
uniform sampler2D gainMap;
uniform vec3 gamma;
uniform vec3 offsetHdr;
uniform vec3 offsetSdr;
uniform vec3 gainMapMin;
uniform vec3 gainMapMax;
uniform float weightFactor;

varying vec2 vUv;

void main() {
  vec3 rgb = texture2D( sdr, vUv ).rgb;
  vec3 recovery = texture2D( gainMap, vUv ).rgb;
  vec3 logRecovery = pow( recovery, gamma );
  vec3 logBoost = gainMapMin * ( 1.0 - logRecovery ) + gainMapMax * logRecovery;
  vec3 hdrColor = (rgb + offsetSdr) * exp2( logBoost * weightFactor ) - offsetHdr;
  vec3 clampedHdrColor = max( HALF_FLOAT_MIN, min( HALF_FLOAT_MAX, hdrColor ));
  gl_FragColor = vec4( clampedHdrColor , 1.0 );
}
`;
class en extends Tr {
    _maxDisplayBoost;
    _hdrCapacityMin;
    _hdrCapacityMax;
    constructor({
        gamma: t,
        offsetHdr: i,
        offsetSdr: s,
        gainMapMin: l,
        gainMapMax: d,
        maxDisplayBoost: c,
        hdrCapacityMin: v,
        hdrCapacityMax: p,
        sdr: f,
        gainMap: b
    }) {
        super({
            name: "GainMapDecoderMaterial",
            vertexShader: Qa,
            fragmentShader: Ja,
            uniforms: {
                sdr: {
                    value: f
                },
                gainMap: {
                    value: b
                },
                gamma: {
                    value: new Ze(1 / t[0], 1 / t[1], 1 / t[2])
                },
                offsetHdr: {
                    value: new Ze().fromArray(i)
                },
                offsetSdr: {
                    value: new Ze().fromArray(s)
                },
                gainMapMin: {
                    value: new Ze().fromArray(l)
                },
                gainMapMax: {
                    value: new Ze().fromArray(d)
                },
                weightFactor: {
                    value: (Math.log2(c) - v) / (p - v)
                }
            },
            blending: na,
            depthTest: !1,
            depthWrite: !1
        }), this._maxDisplayBoost = c, this._hdrCapacityMin = v, this._hdrCapacityMax = p, this.needsUpdate = !0, this.uniformsNeedUpdate = !0
    }
    get sdr() {
        return this.uniforms.sdr.value
    }
    set sdr(t) {
        this.uniforms.sdr.value = t
    }
    get gainMap() {
        return this.uniforms.gainMap.value
    }
    set gainMap(t) {
        this.uniforms.gainMap.value = t
    }
    get offsetHdr() {
        return this.uniforms.offsetHdr.value.toArray()
    }
    set offsetHdr(t) {
        this.uniforms.offsetHdr.value.fromArray(t)
    }
    get offsetSdr() {
        return this.uniforms.offsetSdr.value.toArray()
    }
    set offsetSdr(t) {
        this.uniforms.offsetSdr.value.fromArray(t)
    }
    get gainMapMin() {
        return this.uniforms.gainMapMin.value.toArray()
    }
    set gainMapMin(t) {
        this.uniforms.gainMapMin.value.fromArray(t)
    }
    get gainMapMax() {
        return this.uniforms.gainMapMax.value.toArray()
    }
    set gainMapMax(t) {
        this.uniforms.gainMapMax.value.fromArray(t)
    }
    get gamma() {
        const t = this.uniforms.gamma.value;
        return [1 / t.x, 1 / t.y, 1 / t.z]
    }
    set gamma(t) {
        const i = this.uniforms.gamma.value;
        i.x = 1 / t[0], i.y = 1 / t[1], i.z = 1 / t[2]
    }
    get hdrCapacityMin() {
        return this._hdrCapacityMin
    }
    set hdrCapacityMin(t) {
        this._hdrCapacityMin = t, this.calculateWeight()
    }
    get hdrCapacityMax() {
        return this._hdrCapacityMax
    }
    set hdrCapacityMax(t) {
        this._hdrCapacityMax = t, this.calculateWeight()
    }
    get maxDisplayBoost() {
        return this._maxDisplayBoost
    }
    set maxDisplayBoost(t) {
        this._maxDisplayBoost = Math.max(1, Math.min(65504, t)), this.calculateWeight()
    }
    calculateWeight() {
        const t = (Math.log2(this._maxDisplayBoost) - this._hdrCapacityMin) / (this._hdrCapacityMax - this._hdrCapacityMin);
        this.uniforms.weightFactor.value = Math.max(0, Math.min(1, t))
    }
}
class ht extends Ka {
    constructor(t, i) {
        super({
            renderer: t,
            createMaterial: s => new en(s),
            createQuadRenderer: s => new Ar(s)
        }, i)
    }
    async render(t, i, s, l) {
        const {
            sdrImage: d,
            gainMapImage: c,
            needsFlip: v
        } = await this.processImages(s, l, "flipY"), {
            gainMap: p,
            sdr: f
        } = this.createTextures(d, c, v);
        this.updateQuadRenderer(t, d, p, f, i), t.render()
    }
}
class rn extends ht {
    load([t, i, s], l, d, c) {
        const v = this.prepareQuadRenderer();
        let p, f, b;
        const I = async () => {
            if (p && f && b) {
                try {
                    await this.render(v, b, p, f)
                } catch (x) {
                    this.manager.itemError(t), this.manager.itemError(i), this.manager.itemError(s), typeof c == "function" && c(x), v.disposeOnDemandRenderer();
                    return
                }
                typeof l == "function" && l(v), this.manager.itemEnd(t), this.manager.itemEnd(i), this.manager.itemEnd(s), v.disposeOnDemandRenderer()
            }
        };
        let T = !0,
            A = 0,
            N = 0,
            Q = !0,
            W = 0,
            ne = 0,
            X = !0,
            z = 0,
            ue = 0;
        const H = () => {
            if (typeof d == "function") {
                const x = A + W + z,
                    Z = N + ne + ue,
                    $ = T && Q && X;
                d(new ProgressEvent("progress", {
                    lengthComputable: $,
                    loaded: Z,
                    total: x
                }))
            }
        };
        this.manager.itemStart(t), this.manager.itemStart(i), this.manager.itemStart(s);
        const k = new mr(this._internalLoadingManager);
        k.setResponseType("arraybuffer"), k.setRequestHeader(this.requestHeader), k.setPath(this.path), k.setWithCredentials(this.withCredentials), k.load(t, async x => {
            if (typeof x == "string") throw new Error("Invalid sdr buffer");
            p = x, await I()
        }, x => {
            T = x.lengthComputable, N = x.loaded, A = x.total, H()
        }, x => {
            this.manager.itemError(t), typeof c == "function" && c(x)
        });
        const ie = new mr(this._internalLoadingManager);
        ie.setResponseType("arraybuffer"), ie.setRequestHeader(this.requestHeader), ie.setPath(this.path), ie.setWithCredentials(this.withCredentials), ie.load(i, async x => {
            if (typeof x == "string") throw new Error("Invalid gainmap buffer");
            f = x, await I()
        }, x => {
            Q = x.lengthComputable, ne = x.loaded, W = x.total, H()
        }, x => {
            this.manager.itemError(i), typeof c == "function" && c(x)
        });
        const S = new mr(this._internalLoadingManager);
        return S.setRequestHeader(this.requestHeader), S.setPath(this.path), S.setWithCredentials(this.withCredentials), S.load(s, async x => {
            if (typeof x != "string") throw new Error("Invalid metadata string");
            b = JSON.parse(x), await I()
        }, x => {
            X = x.lengthComputable, ue = x.loaded, z = x.total, H()
        }, x => {
            this.manager.itemError(s), typeof c == "function" && c(x)
        }), v
    }
}
class tn extends ht {
    load(t, i, s, l) {
        const d = this.prepareQuadRenderer(),
            c = new mr(this._internalLoadingManager);
        return c.setResponseType("arraybuffer"), c.setRequestHeader(this.requestHeader), c.setPath(this.path), c.setWithCredentials(this.withCredentials), this.manager.itemStart(t), c.load(t, async v => {
            if (typeof v == "string") throw new Error("Invalid buffer, received [string], was expecting [ArrayBuffer]");
            const p = new Uint8Array(v);
            let f, b, I;
            try {
                const T = await Xa(p);
                f = T.sdr, b = T.gainMap, I = T.metadata
            } catch (T) {
                if (T instanceof ut || T instanceof ct) console.warn(`Failure to reconstruct an HDR image from ${t}: Gain map metadata not found in the file, HDRJPGLoader will render the SDR jpeg`), I = {
                    gainMapMin: [0, 0, 0],
                    gainMapMax: [1, 1, 1],
                    gamma: [1, 1, 1],
                    hdrCapacityMin: 0,
                    hdrCapacityMax: 1,
                    offsetHdr: [0, 0, 0],
                    offsetSdr: [0, 0, 0]
                }, f = p;
                else throw T
            }
            try {
                await this.render(d, I, f.buffer, b ? .buffer)
            } catch (T) {
                this.manager.itemError(t), typeof l == "function" && l(T), d.disposeOnDemandRenderer();
                return
            }
            typeof i == "function" && i(d), this.manager.itemEnd(t), d.disposeOnDemandRenderer()
        }, s, v => {
            this.manager.itemError(t), typeof l == "function" && l(v)
        }), d
    }
}
const lr = {
        apartment: "lebombo_1k.hdr",
        city: "potsdamer_platz_1k.hdr",
        dawn: "kiara_1_dawn_1k.hdr",
        forest: "forest_slope_1k.hdr",
        lobby: "st_fagans_interior_1k.hdr",
        night: "dikhololo_night_1k.hdr",
        park: "rooitou_park_1k.hdr",
        studio: "studio_small_03_1k.hdr",
        sunset: "venice_sunset_1k.hdr",
        warehouse: "empty_warehouse_01_1k.hdr"
    },
    dt = "https://raw.githack.com/pmndrs/drei-assets/456060a26bbeb8fdf79326f224b6d99b8bcce736/hdri/",
    $e = n => Array.isArray(n),
    Fr = ["/px.png", "/nx.png", "/py.png", "/ny.png", "/pz.png", "/nz.png"];

function wr({
    files: n = Fr,
    path: t = "",
    preset: i = void 0,
    encoding: s = void 0,
    extensions: l
} = {}) {
    let d = null,
        c = !1;
    i && (Ur(i), n = lr[i], t = dt), c = $e(n);
    const {
        extension: v,
        isCubemap: p
    } = Or(n);
    if (d = Lr(v), !d) throw new Error("useEnvironment: Unrecognized file extension: " + n);
    const f = qe(A => A.gl);
    L.useLayoutEffect(() => {
        if (v !== "webp" && v !== "jpg" && v !== "jpeg") return;

        function A() {
            _r.clear(d, c ? [n] : n)
        }
        f.domElement.addEventListener("webglcontextlost", A, {
            once: !0
        })
    }, [n, f.domElement]);
    const b = _r(d, c ? [n] : n, A => {
        (v === "webp" || v === "jpg" || v === "jpeg") && A.setRenderer(f), A.setPath == null || A.setPath(t), l && l(A)
    });
    let I = c ? b[0] : b;
    if (v === "jpg" || v === "jpeg" || v === "webp") {
        var T;
        I = (T = I.renderTarget) == null ? void 0 : T.texture
    }
    return I.mapping = p ? ia : sa, "colorSpace" in I ? I.colorSpace = s ? ? p ? "srgb" : "srgb-linear" : I.encoding = s ? ? p ? wa : ya, I
}
const an = {
    files: Fr,
    path: "",
    preset: void 0,
    extensions: void 0
};
wr.preload = n => {
    const t = { ...an,
        ...n
    };
    let {
        files: i,
        path: s = ""
    } = t;
    const {
        preset: l,
        extensions: d
    } = t;
    l && (Ur(l), i = lr[l], s = dt);
    const {
        extension: c
    } = Or(i);
    if (c === "webp" || c === "jpg" || c === "jpeg") throw new Error("useEnvironment: Preloading gainmaps is not supported");
    const v = Lr(c);
    if (!v) throw new Error("useEnvironment: Unrecognized file extension: " + i);
    _r.preload(v, $e(i) ? [i] : i, p => {
        p.setPath == null || p.setPath(s), d && d(p)
    })
};
const nn = {
    files: Fr,
    preset: void 0
};
wr.clear = n => {
    const t = { ...nn,
        ...n
    };
    let {
        files: i
    } = t;
    const {
        preset: s
    } = t;
    s && (Ur(s), i = lr[s]);
    const {
        extension: l
    } = Or(i), d = Lr(l);
    if (!d) throw new Error("useEnvironment: Unrecognized file extension: " + i);
    _r.clear(d, $e(i) ? [i] : i)
};

function Ur(n) {
    if (!(n in lr)) throw new Error("Preset must be one of: " + Object.keys(lr).join(", "))
}

function Or(n) {
    var t;
    const i = $e(n) && n.length === 6,
        s = $e(n) && n.length === 3 && n.some(c => c.endsWith("json")),
        l = $e(n) ? n[0] : n;
    return {
        extension: i ? "cube" : s ? "webp" : l.startsWith("data:application/exr") ? "exr" : l.startsWith("data:application/hdr") ? "hdr" : l.startsWith("data:image/jpeg") ? "jpg" : (t = l.split(".").pop()) == null || (t = t.split("?")) == null || (t = t.shift()) == null ? void 0 : t.toLowerCase(),
        isCubemap: i,
        isGainmap: s
    }
}

function Lr(n) {
    return n === "cube" ? oa : n === "hdr" ? Ba : n === "exr" ? ka : n === "jpg" || n === "jpeg" ? tn : n === "webp" ? rn : null
}
const sn = n => n.current && n.current.isScene,
    on = n => sn(n) ? n.current : n;

function Dr(n, t, i, s, l = {}) {
    var d, c, v, p;
    l = {
        backgroundBlurriness: 0,
        backgroundIntensity: 1,
        backgroundRotation: [0, 0, 0],
        environmentIntensity: 1,
        environmentRotation: [0, 0, 0],
        ...l
    };
    const f = on(t || i),
        b = f.background,
        I = f.environment,
        T = {
            backgroundBlurriness: f.backgroundBlurriness,
            backgroundIntensity: f.backgroundIntensity,
            backgroundRotation: (d = (c = f.backgroundRotation) == null || c.clone == null ? void 0 : c.clone()) !== null && d !== void 0 ? d : [0, 0, 0],
            environmentIntensity: f.environmentIntensity,
            environmentRotation: (v = (p = f.environmentRotation) == null || p.clone == null ? void 0 : p.clone()) !== null && v !== void 0 ? v : [0, 0, 0]
        };
    return n !== "only" && (f.environment = s), n && (f.background = s), Yr(f, l), () => {
        n !== "only" && (f.environment = I), n && (f.background = b), Yr(f, T)
    }
}

function Nr({
    scene: n,
    background: t = !1,
    map: i,
    ...s
}) {
    const l = qe(d => d.scene);
    return L.useLayoutEffect(() => {
        if (i) return Dr(t, n, l, i, s)
    }), null
}

function pt({
    background: n = !1,
    scene: t,
    blur: i,
    backgroundBlurriness: s,
    backgroundIntensity: l,
    backgroundRotation: d,
    environmentIntensity: c,
    environmentRotation: v,
    ...p
}) {
    const f = wr(p),
        b = qe(I => I.scene);
    return L.useLayoutEffect(() => Dr(n, t, b, f, {
        backgroundBlurriness: i ? ? s,
        backgroundIntensity: l,
        backgroundRotation: d,
        environmentIntensity: c,
        environmentRotation: v
    })), L.useEffect(() => () => {
        f.dispose()
    }, [f]), null
}

function ln({
    children: n,
    near: t = .1,
    far: i = 1e3,
    resolution: s = 256,
    frames: l = 1,
    map: d,
    background: c = !1,
    blur: v,
    backgroundBlurriness: p,
    backgroundIntensity: f,
    backgroundRotation: b,
    environmentIntensity: I,
    environmentRotation: T,
    scene: A,
    files: N,
    path: Q,
    preset: W = void 0,
    extensions: ne
}) {
    const X = qe(S => S.gl),
        z = qe(S => S.scene),
        ue = L.useRef(null),
        [H] = L.useState(() => new Kr),
        k = L.useMemo(() => {
            const S = new ca(s);
            return S.texture.type = Me, S
        }, [s]);
    L.useEffect(() => () => {
        k.dispose()
    }, [k]), L.useLayoutEffect(() => {
        if (l === 1) {
            const S = X.autoClear;
            X.autoClear = !0, ue.current.update(X, H), X.autoClear = S
        }
        return Dr(c, A, z, k.texture, {
            backgroundBlurriness: v ? ? p,
            backgroundIntensity: f,
            backgroundRotation: b,
            environmentIntensity: I,
            environmentRotation: T
        })
    }, [n, H, k.texture, A, z, c, l, X]);
    let ie = 1;
    return Rr(() => {
        if (l === 1 / 0 || ie < l) {
            const S = X.autoClear;
            X.autoClear = !0, ue.current.update(X, H), X.autoClear = S, ie++
        }
    }), L.createElement(L.Fragment, null, ua(L.createElement(L.Fragment, null, n, L.createElement("cubeCamera", {
        ref: ue,
        args: [t, i, k]
    }), N || W ? L.createElement(pt, {
        background: !0,
        files: N,
        preset: W,
        path: Q,
        extensions: ne
    }) : d ? L.createElement(Nr, {
        background: !0,
        map: d,
        extensions: ne
    }) : null), H))
}

function cn(n) {
    var t, i, s, l;
    const d = wr(n),
        c = n.map || d;
    L.useMemo(() => la({
        GroundProjectedEnvImpl: Na
    }), []), L.useEffect(() => () => {
        d.dispose()
    }, [d]);
    const v = L.useMemo(() => [c], [c]),
        p = (t = n.ground) == null ? void 0 : t.height,
        f = (i = n.ground) == null ? void 0 : i.radius,
        b = (s = (l = n.ground) == null ? void 0 : l.scale) !== null && s !== void 0 ? s : 1e3;
    return L.createElement(L.Fragment, null, L.createElement(Nr, da({}, n, {
        map: c
    })), L.createElement("groundProjectedEnvImpl", {
        args: v,
        scale: b,
        height: p,
        radius: f
    }))
}

function un(n) {
    return n.ground ? L.createElement(cn, n) : n.map ? L.createElement(Nr, n) : n.children ? L.createElement(ln, n) : L.createElement(pt, n)
}
const hn = () => {
        const {
            mobile: n
        } = fe.getState(), t = ga(), i = L.useRef(t), s = L.useRef(null), l = n ? new Ze(-20, 8, -43) : new Ze(-20, 8, -43), d = 10;
        return L.useEffect(() => fe.subscribe(c => c.country, c => {
            const v = [document.querySelector(".fr-text-content"), ...document.querySelectorAll(".fr-description")];
            ha() ? v.forEach(p => p.classList.remove("active")) : ([...document.querySelectorAll(".fr-description")].forEach(f => f.classList.add("active")), c === "frlux" ? document.querySelector(".fr-text-content").classList.add("active") : document.querySelector(".fr-text-content").classList.remove("active"))
        }), []), L.useEffect(() => Ye.subscribe(c => c.scroll, c => {
            const {
                country: v
            } = fe.getState(), p = document.querySelector(".fr-text-content");
            if (v === "fr" && c >= .95 && !p.classList.contains("active") && p.classList.add("active"), v === "frlux") {
                if (c > 0) {
                    const f = document.querySelector(".fr-text-content>div");
                    if (!f) return;
                    if (n) {
                        const b = 480 - c * 15e3;
                        f.style.transform = `translateY(${b}px)`
                    } else {
                        const b = 410 - c * 15e3;
                        f.style.transform = `perspective(250px) translateY(${b}px) rotateX(0deg) rotateY(0deg)`
                    }
                }
            } else {
                const f = document.querySelector(".fr-text-content>div");
                if (!f) return;
                n ? f.style.transform = "translateY(480px)" : f.style.transform = "perspective(250px) translateY(410px) rotateX(0deg) rotateY(0deg)"
            }
        }), []), Rr(() => {
            const {
                scroll: c
            } = Ye.getState(), {
                country: v
            } = fe.getState(), p = document.querySelector(".fr-description.a .span"), f = document.querySelector(".fr-description.b .span"), b = document.querySelector(".fr-description.c .span"), I = document.querySelector(".fr-description.d .span");
            if (v === "fr" ? (c > .15 && p ? .classList.add("active"), c > .2 && f ? .classList.add("active"), c > .25 && b ? .classList.add("active"), c > .3 && I ? .classList.add("active"), c < .1 && (p ? .classList.remove("active"), f ? .classList.remove("active"), b ? .classList.remove("active"), I ? .classList.remove("active"))) : (p ? .classList.remove("active"), f ? .classList.remove("active"), b ? .classList.remove("active"), I ? .classList.remove("active")), v === "frlux") {
                const T = document.querySelector(".fr-text-content > div");
                if (n) {
                    const A = 480 - c * 15e3;
                    T.style.transform = `translateY(${A}px)`
                } else {
                    const A = 410 - c * 15e3;
                    T.style.transform = `perspective(800px) translateY(${A}px) rotateX(${-i.current.y*4}deg) rotateY(${i.current.x*4}deg)`
                }
            }
        }), U.jsxs(U.Fragment, {
            children: [U.jsx(tr, {
                follow: !0,
                position: [-12, 8, -1],
                children: U.jsx(ar, {
                    transform: !0,
                    wrapperClass: "__html fr-description active a",
                    children: U.jsx(pr, {
                        arrayOfString: ["Welcome"],
                        className: "span",
                        transitionDelay: 120
                    })
                })
            }), U.jsx(tr, {
                follow: !0,
                position: [-16, 8, -3],
                children: U.jsx(ar, {
                    transform: !0,
                    wrapperClass: "__html fr-description active b",
                    children: U.jsx(pr, {
                        arrayOfString: ["to"],
                        className: "span",
                        transitionDelay: 260
                    })
                })
            }), U.jsx(tr, {
                follow: !0,
                position: [-18, 8, -5.5],
                children: U.jsx(ar, {
                    transform: !0,
                    wrapperClass: "__html fr-description active c",
                    children: U.jsx(pr, {
                        arrayOfString: ["my"],
                        className: "span",
                        transitionDelay: 260
                    })
                })
            }), U.jsx(tr, {
                follow: !0,
                position: [-22, 8, -2],
                children: U.jsx(ar, {
                    transform: !0,
                    wrapperClass: "__html fr-description active d",
                    children: U.jsx(pr, {
                        arrayOfString: ["World"],
                        className: "span",
                        transitionDelay: 120
                    })
                })
            }), U.jsx(tr, {
                follow: !0,
                ref: s,
                position: l,
                children: U.jsx(ar, {
                    transform: !0,
                    distanceFactor: d,
                    wrapperClass: "__html fr-text",
                    children: U.jsxs("div", {
                        className: "fr-text-content",
                        children: [U.jsx("div", {
                            children: U.jsxs("div", {
                                className: "scroller",
                                children: [U.jsx("h1", {
                                    children: "Hi!"
                                }), U.jsx("p", {
                                    children: `I'm Sébastien Lempens, a french "Gen X" Web Engineer. Throughout my career, I have worked on multiple sized projects in various roles, including Project Manager, Designer and Front/Back-end Developer.`
                                }), U.jsx("p", {
                                    children: "I'm entirely self-taught, I haven't attended a specialized school or completed a bootcamp. I learned on the job and with over 20 years experience I'm proud to say I'm still as passionate as ever."
                                }), U.jsx("p", {
                                    children: "Through this website, I wanted to leverage what I have learned in recent years, particularly in terms of 3D. You will also find a overview of my most important projects."
                                }), U.jsx("p", {
                                    children: "Let's keep scrolling to discover the rest :)"
                                })]
                            })
                        }), U.jsx("div", {
                            children: U.jsxs("div", {
                                className: "scroller",
                                children: [U.jsx("h1", {
                                    children: "Hi!"
                                }), U.jsx("p", {
                                    children: `I'm Sébastien Lempens, a french "Gen X" Web Engineer. Throughout my career, I have worked on multiple sized projects in various roles, including Project Manager, Designer and Front/Back-end Developer.`
                                }), U.jsx("p", {
                                    children: "I'm entirely self-taught, I haven't attended a specialized school or completed a bootcamp. I learned on the job and with over 20 years experience I'm proud to say I'm still as passionate as ever."
                                }), U.jsx("p", {
                                    children: "Through this website, I wanted to leverage what I have learned in recent years, particularly in terms of 3D. You will also find a overview of my most important projects."
                                }), U.jsx("p", {
                                    children: "Let's keep scrolling to discover the rest :)"
                                })]
                            })
                        })]
                    })
                })
            })]
        })
    },
    dn = L.lazy(() => He(() =>
        import ("./Buildings-BKYUSQmL.js"), __vite__mapDeps([0, 1, 2, 3]))),
    pn = L.lazy(() => He(() =>
        import ("./Bridges-TUHD1og8.js"), __vite__mapDeps([4, 1, 2, 3]))),
    fn = L.lazy(() => He(() =>
        import ("./BigWheel-CFdhQiU-.js"), __vite__mapDeps([5, 1, 2, 3, 6, 7]))),
    vn = L.lazy(() => He(() =>
        import ("./EiffelTower-YKGT_MbS.js"), __vite__mapDeps([8, 1, 2, 3]))),
    mn = L.lazy(() => He(() =>
        import ("./Floor-YVn1hsyq.js"), __vite__mapDeps([9, 1, 2, 3]))),
    gn = L.lazy(() => He(() =>
        import ("./Lights-CsIaKWVG.js"), __vite__mapDeps([10, 1, 2]))),
    _n = L.lazy(() => He(() =>
        import ("./River-Do6bCd_6.js"), __vite__mapDeps([11, 1, 2, 3]))),
    wn = L.lazy(() => He(() =>
        import ("./HtmlTitle-BnxYPVZT.js"), __vite__mapDeps([12, 1, 2, 13, 3, 14]))),
    yn = () => {
        const {
            isMobile: n
        } = rt(), t = qe(I => I.scene), {
            currentCamera: i,
            fr_cameras_animations: s
        } = fe.getState(), l = i, [d] = s ? .filter(({
            name: I
        }) => I === "cameraFrance"), [c, v] = _a("cameraFrance", l, d), {
            scrollHandler: p,
            lerpAmountInit: f
        } = Ye.getState();
        L.useEffect(() => fe.subscribe(I => I.country, I => {
            const {
                lu_component_preload: T,
                mobile: A
            } = fe.getState();
            if (I === "fr") dr(!1), va(t, ["countryFrance"], ["countryBelgium", "countryLuxembourg"]), A && fe.setState({
                mobileJoystickActive: !0
            }), p.lerpAmount = f, c.reset().play().paused = !0, !T && fe.setState({
                lu_component_preload: !0
            });
            else {
                const N = l.position.clone(),
                    Q = l.rotation.clone();
                c.stop(), l.position.set(...N.toArray()), l.rotation.set(Q.x, Q.y, Q.z)
            }
        }, {
            fireImmediately: !0
        }), []), L.useEffect(() => fe.subscribe(I => I.teleportation, I => {
            const {
                country: T
            } = fe.getState();
            I && T === "fr" && (dr(!1), ma(t, "sunrise"))
        }), []), L.useEffect(() => Ye.subscribe(I => I.scroll, I => {
            const {
                country: T
            } = fe.getState(), {
                scrollHandler: A,
                lerpAmount: N,
                scroll_path_length: Q
            } = Ye.getState();
            T === "fr" ? (I > .05 && dr(), I >= .8 && (n || (A.lerpAmount = N + .02, A.active = !1, A.goTo(Q)), dr(!1)), I >= .99 && n && A.goTo(Q)) : A.lerpAmount = f
        }), []);
        let b = !1;
        return Rr((I, T) => {
            const {
                country: A
            } = fe.getState(), {
                scroll: N
            } = Ye.getState();
            A === "fr" ? b ? (c.time = c.getClip().duration * N, v && v.update(T)) : b = !0 : b = !1
        }), null
    },
    An = () => {
        const {
            isMobile: n
        } = rt(), {
            animations: t
        } = pa(fe.getState().fr_glb_path), i = fe(l => l.fr_component_loaded), s = $r.useRef(null);
        return $r.useEffect(() => {
            fe.setState({
                fr_cameras_animations: t
            }), fe.setState({
                country: "fr",
                fr_component_loaded: !0
            }), console.log("%c France Component Loaded", fa.log)
        }, []), U.jsxs("group", {
            name: "countryFrance",
            children: [U.jsx(wn, {}), U.jsx(hn, {}), U.jsx(fn, {}), U.jsx(pn, {}), U.jsx(dn, {}), U.jsx(vn, {}), U.jsx(mn, {}), U.jsx(gn, {}), U.jsx(_n, {}), U.jsx(un, {
                frames: 1,
                path: n ? "hdri/sunrise/mobile" : "hdri/sunrise",
                background: !0,
                blur: .035
            }), U.jsx(Ea, {
                ref: s,
                args: [300, 200, 1, 1],
                rotation: [-.5 * Math.PI, 0, 0],
                position: [80, .01, -30],
                receiveShadow: !0,
                children: U.jsx("shadowMaterial", {
                    opacity: .6,
                    color: "hsl(342,40%,20%)"
                })
            }), i && U.jsx(yn, {})]
        })
    };
export {
    An as
    default
};