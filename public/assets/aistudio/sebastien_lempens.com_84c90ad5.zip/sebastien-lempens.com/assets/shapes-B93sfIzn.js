import {
    _ as m
} from "./Scene-CdCGEhkU.js";
import {
    ab as e
} from "./index-DjXkBzPf.js";

function a(n, t) {
    const o = n + "Geometry";
    return e.forwardRef(({
        args: s,
        children: c,
        ...u
    }, l) => {
        const r = e.useRef(null);
        return e.useImperativeHandle(l, () => r.current), e.useLayoutEffect(() => {
            t ? .(r.current)
        }), e.createElement("mesh", m({
            ref: r
        }, u), e.createElement(o, {
            attach: "geometry",
            args: s
        }), c)
    })
}
const i = a("sphere"),
    d = a("plane");
export {
    d as P, i as S
};