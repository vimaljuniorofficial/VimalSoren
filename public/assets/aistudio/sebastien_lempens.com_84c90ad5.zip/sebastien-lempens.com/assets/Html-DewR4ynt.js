import {
    _ as ge
} from "./Scene-CdCGEhkU.js";
import {
    ab as n,
    ac as Me,
    bn as be,
    am as Pe,
    a as H,
    v as we,
    V as Se,
    W as ee,
    Y as te
} from "./index-DjXkBzPf.js";
const C = new H,
    I = new H,
    Ee = new H,
    X = new Se;

function We(e, t, s) {
    const o = C.setFromMatrixPosition(e.matrixWorld);
    o.project(t);
    const i = s.width / 2,
        a = s.height / 2;
    return [o.x * i + i, -(o.y * a) + a]
}

function je(e, t) {
    const s = C.setFromMatrixPosition(e.matrixWorld),
        o = I.setFromMatrixPosition(t.matrixWorld),
        i = s.sub(o),
        a = t.getWorldDirection(Ee);
    return i.angleTo(a) > Math.PI / 2
}

function Ce(e, t, s, o) {
    const i = C.setFromMatrixPosition(e.matrixWorld),
        a = i.clone();
    a.project(t), X.set(a.x, a.y), s.setFromCamera(X, t);
    const x = s.intersectObjects(o, !0);
    if (x.length) {
        const P = x[0].distance;
        return i.distanceTo(s.ray.origin) < P
    }
    return !0
}

function Re(e, t) {
    if (t instanceof te) return t.zoom;
    if (t instanceof ee) {
        const s = C.setFromMatrixPosition(e.matrixWorld),
            o = I.setFromMatrixPosition(t.matrixWorld),
            i = t.fov * Math.PI / 180,
            a = s.distanceTo(o);
        return 1 / (2 * Math.tan(i / 2) * a)
    } else return 1
}

function $e(e, t, s) {
    if (t instanceof ee || t instanceof te) {
        const o = C.setFromMatrixPosition(e.matrixWorld),
            i = I.setFromMatrixPosition(t.matrixWorld),
            a = o.distanceTo(i),
            x = (s[1] - s[0]) / (t.far - t.near),
            P = s[1] - x * t.far;
        return Math.round(x * a + P)
    }
}
const k = e => Math.abs(e) < 1e-10 ? 0 : e;

function ne(e, t, s = "") {
    let o = "matrix3d(";
    for (let i = 0; i !== 16; i++) o += k(t[i] * e.elements[i]) + (i !== 15 ? "," : ")");
    return s + o
}
const Oe = (e => t => ne(t, e))([1, -1, 1, 1, 1, -1, 1, 1, 1, -1, 1, 1, 1, -1, 1, 1]),
    Te = (e => (t, s) => ne(t, e(s), "translate(-50%,-50%)"))(e => [1 / e, 1 / e, 1 / e, 1, -1 / e, -1 / e, -1 / e, -1, 1 / e, 1 / e, 1 / e, 1, 1, 1, 1, 1]);

function Fe(e) {
    return e && typeof e == "object" && "current" in e
}
const ze = n.forwardRef(({
    children: e,
    eps: t = .001,
    style: s,
    className: o,
    prepend: i,
    center: a,
    fullscreen: x,
    portal: P,
    distanceFactor: E,
    sprite: re = !1,
    transform: h = !1,
    occlude: c,
    onOcclude: L,
    castShadow: se,
    receiveShadow: ie,
    material: oe,
    geometry: N,
    zIndexRange: R = [16777271, 0],
    calculatePosition: B = We,
    as: ae = "div",
    wrapperClass: V,
    pointerEvents: Z = "auto",
    ...v
}, _) => {
    const {
        gl: G,
        camera: l,
        scene: Y,
        size: f,
        raycaster: ce,
        events: le,
        viewport: ue
    } = Me(), [u] = n.useState(() => document.createElement(ae)), z = n.useRef(), m = n.useRef(null), q = n.useRef(0), $ = n.useRef([0, 0]), W = n.useRef(null), A = n.useRef(null), w = P ? .current || le.connected || G.domElement.parentNode, p = n.useRef(null), O = n.useRef(!1), T = n.useMemo(() => c && c !== "blending" || Array.isArray(c) && c.length && Fe(c[0]), [c]);
    n.useLayoutEffect(() => {
        const d = G.domElement;
        c && c === "blending" ? (d.style.zIndex = `${Math.floor(R[0]/2)}`, d.style.position = "absolute", d.style.pointerEvents = "none") : (d.style.zIndex = null, d.style.position = null, d.style.pointerEvents = null)
    }, [c]), n.useLayoutEffect(() => {
        if (m.current) {
            const d = z.current = be.createRoot(u);
            if (Y.updateMatrixWorld(), h) u.style.cssText = "position:absolute;top:0;left:0;pointer-events:none;overflow:hidden;";
            else {
                const r = B(m.current, l, f);
                u.style.cssText = `position:absolute;top:0;left:0;transform:translate3d(${r[0]}px,${r[1]}px,0);transform-origin:0 0;`
            }
            return w && (i ? w.prepend(u) : w.appendChild(u)), () => {
                w && w.removeChild(u), d.unmount()
            }
        }
    }, [w, h]), n.useLayoutEffect(() => {
        V && (u.className = V)
    }, [V]);
    const J = n.useMemo(() => h ? {
            position: "absolute",
            top: 0,
            left: 0,
            width: f.width,
            height: f.height,
            transformStyle: "preserve-3d",
            pointerEvents: "none"
        } : {
            position: "absolute",
            transform: a ? "translate3d(-50%,-50%,0)" : "none",
            ...x && {
                top: -f.height / 2,
                left: -f.width / 2,
                width: f.width,
                height: f.height
            },
            ...s
        }, [s, a, x, f, h]),
        fe = n.useMemo(() => ({
            position: "absolute",
            pointerEvents: Z
        }), [Z]);
    n.useLayoutEffect(() => {
        if (O.current = !1, h) {
            var d;
            (d = z.current) == null || d.render(n.createElement("div", {
                ref: W,
                style: J
            }, n.createElement("div", {
                ref: A,
                style: fe
            }, n.createElement("div", {
                ref: _,
                className: o,
                style: s,
                children: e
            }))))
        } else {
            var r;
            (r = z.current) == null || r.render(n.createElement("div", {
                ref: _,
                style: J,
                className: o,
                children: e
            }))
        }
    });
    const S = n.useRef(!0);
    Pe(d => {
        if (m.current) {
            l.updateMatrixWorld(), m.current.updateWorldMatrix(!0, !1);
            const r = h ? $.current : B(m.current, l, f);
            if (h || Math.abs(q.current - l.zoom) > t || Math.abs($.current[0] - r[0]) > t || Math.abs($.current[1] - r[1]) > t) {
                const g = je(m.current, l);
                let y = !1;
                T && (Array.isArray(c) ? y = c.map(M => M.current) : c !== "blending" && (y = [Y]));
                const j = S.current;
                if (y) {
                    const M = Ce(m.current, l, ce, y);
                    S.current = M && !g
                } else S.current = !g;
                j !== S.current && (L ? L(!S.current) : u.style.display = S.current ? "block" : "none");
                const F = Math.floor(R[0] / 2),
                    de = c ? T ? [R[0], F] : [F - 1, 0] : R;
                if (u.style.zIndex = `${$e(m.current,l,de)}`, h) {
                    const [M, Q] = [f.width / 2, f.height / 2], D = l.projectionMatrix.elements[5] * Q, {
                        isOrthographicCamera: U,
                        top: me,
                        left: he,
                        bottom: xe,
                        right: ve
                    } = l, ye = Oe(l.matrixWorldInverse), pe = U ? `scale(${D})translate(${k(-(ve+he)/2)}px,${k((me+xe)/2)}px)` : `translateZ(${D}px)`;
                    let b = m.current.matrixWorld;
                    re && (b = l.matrixWorldInverse.clone().transpose().copyPosition(b).scale(m.current.scale), b.elements[3] = b.elements[7] = b.elements[11] = 0, b.elements[15] = 1), u.style.width = f.width + "px", u.style.height = f.height + "px", u.style.perspective = U ? "" : `${D}px`, W.current && A.current && (W.current.style.transform = `${pe}${ye}translate(${M}px,${Q}px)`, A.current.style.transform = Te(b, 1 / ((E || 10) / 400)))
                } else {
                    const M = E === void 0 ? 1 : Re(m.current, l) * E;
                    u.style.transform = `translate3d(${r[0]}px,${r[1]}px,0) scale(${M})`
                }
                $.current = r, q.current = l.zoom
            }
        }
        if (!T && p.current && !O.current)
            if (h) {
                if (W.current) {
                    const r = W.current.children[0];
                    if (r != null && r.clientWidth && r != null && r.clientHeight) {
                        const {
                            isOrthographicCamera: g
                        } = l;
                        if (g || N) v.scale && (Array.isArray(v.scale) ? v.scale instanceof H ? p.current.scale.copy(v.scale.clone().divideScalar(1)) : p.current.scale.set(1 / v.scale[0], 1 / v.scale[1], 1 / v.scale[2]) : p.current.scale.setScalar(1 / v.scale));
                        else {
                            const y = (E || 10) / 400,
                                j = r.clientWidth * y,
                                F = r.clientHeight * y;
                            p.current.scale.set(j, F, 1)
                        }
                        O.current = !0
                    }
                }
            } else {
                const r = u.children[0];
                if (r != null && r.clientWidth && r != null && r.clientHeight) {
                    const g = 1 / ue.factor,
                        y = r.clientWidth * g,
                        j = r.clientHeight * g;
                    p.current.scale.set(y, j, 1), O.current = !0
                }
                p.current.lookAt(d.camera.position)
            }
    });
    const K = n.useMemo(() => ({
        vertexShader: h ? void 0 : `
          /*
            This shader is from the THREE's SpriteMaterial.
            We need to turn the backing plane into a Sprite
            (make it always face the camera) if "transfrom"
            is false.
          */
          #include <common>

          void main() {
            vec2 center = vec2(0., 1.);
            float rotation = 0.0;

            // This is somewhat arbitrary, but it seems to work well
            // Need to figure out how to derive this dynamically if it even matters
            float size = 0.03;

            vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
            vec2 scale;
            scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
            scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );

            bool isPerspective = isPerspectiveMatrix( projectionMatrix );
            if ( isPerspective ) scale *= - mvPosition.z;

            vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale * size;
            vec2 rotatedPosition;
            rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
            rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
            mvPosition.xy += rotatedPosition;

            gl_Position = projectionMatrix * mvPosition;
          }
      `,
        fragmentShader: `
        void main() {
          gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);
        }
      `
    }), [h]);
    return n.createElement("group", ge({}, v, {
        ref: m
    }), c && !T && n.createElement("mesh", {
        castShadow: se,
        receiveShadow: ie,
        ref: p
    }, N || n.createElement("planeGeometry", null), oe || n.createElement("shaderMaterial", {
        side: we,
        vertexShader: K.vertexShader,
        fragmentShader: K.fragmentShader
    })))
});
export {
    ze as H
};