import {
    j as V,
    _ as F
} from "./Scene-CdCGEhkU.js";
import {
    ab as t,
    bd as $,
    aq as j,
    a as x,
    am as G,
    e as P,
    Q as S,
    be as z,
    R as H,
    C as N,
    ba as J
} from "./index-DjXkBzPf.js";
import {
    a as L
} from "./deprecated-yOBBLatR.js";
const K = "https://rawcdn.githack.com/pmndrs/drei-assets/9225a9f1fbd449d9411125c2f419b843d0308c9f/cloud.png",
    B = new P,
    U = new x,
    D = new S,
    T = new x,
    W = new S,
    O = new x,
    q = t.createContext(null),
    X = t.forwardRef(({
        children: h,
        material: s = $,
        texture: C = K,
        range: l,
        limit: c = 200,
        frustumCulled: R,
        ...b
    }, I) => {
        var y, M;
        const E = t.useMemo(() => class extends s {
            constructor() {
                super();
                const o = parseInt(H.replace(/\D+/g, "")) >= 154 ? "opaque_fragment" : "output_fragment";
                this.onBeforeCompile = i => {
                    i.vertexShader = `attribute float cloudOpacity;
               varying float vOpacity;
              ` + i.vertexShader.replace("#include <fog_vertex>", `#include <fog_vertex>
                 vOpacity = cloudOpacity;
                `), i.fragmentShader = `varying float vOpacity;
              ` + i.fragmentShader.replace(`#include <${o}>`, `#include <${o}>
                 gl_FragColor = vec4(outgoingLight, diffuseColor.a * vOpacity);
                `)
                }
            }
        }, [s]);
        j({
            CloudMaterial: E
        });
        const n = t.useRef(null),
            f = t.useRef([]),
            _ = t.useMemo(() => new Float32Array(Array.from({
                length: c
            }, () => 1)), [c]),
            d = t.useMemo(() => new Float32Array(Array.from({
                length: c
            }, () => [1, 1, 1]).flat()), [c]),
            m = V(C);
        let v = 0,
            a = 0,
            r;
        const e = new S,
            p = new x(0, 0, 1),
            g = new x;
        G((o, i) => {
            for (v = o.clock.elapsedTime, B.copy(n.current.matrixWorld).invert(), o.camera.matrixWorld.decompose(T, W, O), a = 0; a < f.current.length; a++) r = f.current[a], r.ref.current.matrixWorld.decompose(U, D, O), U.add(g.copy(r.position).applyQuaternion(D).multiply(O)), D.copy(W).multiply(e.setFromAxisAngle(p, r.rotation += i * r.rotationFactor)), O.multiplyScalar(r.volume + (1 + Math.sin(v * r.density * r.speed)) / 2 * r.growth), r.matrix.compose(U, D, O).premultiply(B), r.dist = U.distanceTo(T);
            for (f.current.sort((A, Q) => Q.dist - A.dist), a = 0; a < f.current.length; a++) r = f.current[a], _[a] = r.opacity * (r.dist < r.fade - 1 ? r.dist / r.fade : 1), n.current.setMatrixAt(a, r.matrix), n.current.setColorAt(a, r.color);
            n.current.geometry.attributes.cloudOpacity.needsUpdate = !0, n.current.instanceMatrix.needsUpdate = !0, n.current.instanceColor && (n.current.instanceColor.needsUpdate = !0)
        }), t.useLayoutEffect(() => {
            const o = Math.min(c, l !== void 0 ? l : c, f.current.length);
            n.current.count = o, L(n.current.instanceMatrix, {
                offset: 0,
                count: o * 16
            }), n.current.instanceColor && L(n.current.instanceColor, {
                offset: 0,
                count: o * 3
            }), L(n.current.geometry.attributes.cloudOpacity, {
                offset: 0,
                count: o
            })
        });
        let u = [(y = m.image.width) !== null && y !== void 0 ? y : 1, (M = m.image.height) !== null && M !== void 0 ? M : 1];
        const w = Math.max(u[0], u[1]);
        return u = [u[0] / w, u[1] / w], t.createElement("group", F({
            ref: I
        }, b), t.createElement(q.Provider, {
            value: f
        }, h, t.createElement("instancedMesh", {
            matrixAutoUpdate: !1,
            ref: n,
            args: [null, null, c],
            frustumCulled: R
        }, t.createElement("instancedBufferAttribute", {
            usage: z,
            attach: "instanceColor",
            args: [d, 3]
        }), t.createElement("planeGeometry", {
            args: [...u]
        }, t.createElement("instancedBufferAttribute", {
            usage: z,
            attach: "attributes-cloudOpacity",
            args: [_, 1]
        })), t.createElement("cloudMaterial", {
            key: s.name,
            map: m,
            transparent: !0,
            depthWrite: !1
        }))))
    }),
    k = t.forwardRef(({
        opacity: h = 1,
        speed: s = 0,
        bounds: C = [5, 1, 1],
        segments: l = 20,
        color: c = "#ffffff",
        fade: R = 10,
        volume: b = 6,
        smallestVolume: I = .25,
        distribute: y = null,
        growth: M = 4,
        concentrate: E = "inside",
        seed: n = Math.random(),
        ...f
    }, _) => {
        function d() {
            const e = Math.sin(n++) * 1e4;
            return e - Math.floor(e)
        }
        const m = t.useContext(q),
            v = t.useRef(null),
            a = t.useId(),
            r = t.useMemo(() => [...new Array(l)].map((e, p) => ({
                segments: l,
                bounds: new x(1, 1, 1),
                position: new x,
                uuid: a,
                index: p,
                ref: v,
                dist: 0,
                matrix: new P,
                color: new N,
                rotation: p * (Math.PI / l)
            })), [l, a]);
        return t.useLayoutEffect(() => {
            r.forEach((e, p) => {
                J(e, {
                    volume: b,
                    color: c,
                    speed: s,
                    growth: M,
                    opacity: h,
                    fade: R,
                    bounds: C,
                    density: Math.max(.5, d()),
                    rotationFactor: Math.max(.2, .5 * d()) * s
                });
                const g = y ? .(e, p);
                if (g || l > 1) {
                    var u;
                    e.position.copy(e.bounds).multiply((u = g ? .point) !== null && u !== void 0 ? u : {
                        x: d() * 2 - 1,
                        y: d() * 2 - 1,
                        z: d() * 2 - 1
                    })
                }
                const w = Math.abs(e.position.x),
                    o = Math.abs(e.position.y),
                    i = Math.abs(e.position.z),
                    A = Math.max(w, o, i);
                e.length = 1, w === A && (e.length -= w / e.bounds.x), o === A && (e.length -= o / e.bounds.y), i === A && (e.length -= i / e.bounds.z), e.volume = (g ? .volume !== void 0 ? g.volume : Math.max(Math.max(0, I), E === "random" ? d() : E === "inside" ? e.length : 1 - e.length)) * b
            })
        }, [E, C, R, c, h, M, b, n, l, s]), t.useLayoutEffect(() => {
            const e = r;
            return m.current = [...m.current, ...e], () => {
                m.current = m.current.filter(p => p.uuid !== a)
            }
        }, [r]), t.useImperativeHandle(_, () => v.current, []), t.createElement("group", F({
            ref: v
        }, f))
    }),
    et = t.forwardRef((h, s) => t.useContext(q) ? t.createElement(k, F({
        ref: s
    }, h)) : t.createElement(X, null, t.createElement(k, F({
        ref: s
    }, h))));
export {
    X as C, et as a
};