import {
    _ as d
} from "./Scene-CdCGEhkU.js";
import {
    ab as t,
    am as m,
    Q as x
} from "./index-DjXkBzPf.js";
const b = t.forwardRef(function({
    children: a,
    follow: u = !0,
    lockX: i = !1,
    lockY: l = !1,
    lockZ: c = !1,
    ...s
}, f) {
    const r = t.useRef(null),
        e = t.useRef(null),
        o = new x;
    return m(({
        camera: p
    }) => {
        if (!u || !e.current) return;
        const n = r.current.rotation.clone();
        e.current.updateMatrix(), e.current.updateWorldMatrix(!1, !1), e.current.getWorldQuaternion(o), p.getWorldQuaternion(r.current.quaternion).premultiply(o.invert()), i && (r.current.rotation.x = n.x), l && (r.current.rotation.y = n.y), c && (r.current.rotation.z = n.z)
    }), t.useImperativeHandle(f, () => e.current, []), t.createElement("group", d({
        ref: e
    }, s), t.createElement("group", {
        ref: r
    }, a))
});
export {
    b as B
};