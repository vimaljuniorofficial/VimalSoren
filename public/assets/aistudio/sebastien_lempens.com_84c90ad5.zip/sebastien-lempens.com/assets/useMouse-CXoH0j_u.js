import {
    ab as n
} from "./index-DjXkBzPf.js";
const s = () => {
    const e = {
            x: 0,
            y: 0
        },
        t = o => {
            e.x = o.clientX / window.innerWidth * 2 - 1, e.y = o.clientY / window.innerHeight * 2 - 1
        };
    return n.useEffect(() => {
        window.addEventListener("mousemove", t)
    }, []), e
};
export {
    s as u
};